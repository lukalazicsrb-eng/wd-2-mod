// WD2 Enhanced 0.37 Direct3D 11 pixel-shader adaptation of Intel XeGTAO.
// Portions copyright (C) 2016-2021 Intel Corporation. MIT license in DOCS.
// Upstream: GameTechDev/XeGTAO, commit a5b1686c7ea37788eeb3576b5be47f7c03db532c.
// Retains the horizon integral, Hilbert/R2 sampling, depth-derived normal and
// symmetric spatial denoise. Uses WD2-specific depth validation, point-sampled
// coherent MIPs and half-resolution reconstruction. No frame history is used.

Texture2D Scene : register(t0);
Texture2D Overlay : register(t1);
Texture2D<float> DepthInput : register(t2);
Texture2DMS<float> DepthMSInput : register(t3);
Texture2D<float4> AOResult : register(t4);
Texture2D<float4> XEDepth : register(t5);
Texture2D<float4> AORaw : register(t6);
SamplerState Sample0 : register(s0);

cbuffer CB : register(b0) {
    float2 InvSize;
    float Sharp;
    float Sat;
    float Contrast;
    float Bright;
    float Gamma;
    float Fx;
    float Menu;
    float3 Pad;
    float4 AOParams;        // mode, intensity, view-space radius slider, quality
    float4 CameraParams;    // depth B, depth A, inverse projection X and Y scale
    float4 DepthInfo;       // sample count, source dimensions, HUD guard
    float4 AOExtra;         // contact boost, edge guard, linear color, input readiness
    float4 ProjectionExtra; // NDC offsets X/Y, observed depth clear value, reserved
};

struct VOUT {
    float4 pos : SV_Position;
    float2 uv : TEXCOORD0;
};

VOUT VSMain(uint id : SV_VertexID) {
    VOUT o;
    o.uv = float2((id << 1) & 2, id & 2);
    o.pos = float4(o.uv * float2(2, -2) + float2(-1, 1), 0, 1);
    return o;
}

static const float Pi = 3.14159265359;
static const float HalfPi = 1.57079632679;
static const float Falloff = 0.615;
static const uint Valid = 0;
static const uint ClearDepth = 1;
static const uint InvalidRaw = 2;
static const uint MixedMsaa = 3;
static const uint InvalidProjection = 4;
static const uint MixedFootprint = 5;
static const uint MissingNormal = 6;
static const uint MissingSurface = 7;
static const uint MissingCamera = 8;
static const uint MissingPipeline = 9;
static const uint MissingInput = 10;

struct DepthSample {
    float raw;
    float z;
    float minZ;
    float maxZ;
    float coverage;
    uint reason;
};

float EffectRadius() {
    return 1.457 * clamp(0.15 + AOParams.z * 0.025, 0.20, 1.35);
}

float ViewZ(float raw) {
    float denominator = raw - CameraParams.y;
    if (abs(denominator) < 1e-12)
        return 0.0;
    float z = CameraParams.x / denominator;
    return z > 0.0 && z < 1e7 ? z : 0.0;
}

float3 ViewPosition(float2 uv, float z) {
    float2 ndc = uv * float2(2, -2) + float2(-1, 1);
    return float3((ndc - ProjectionExtra.xy) * CameraParams.zw * z, z);
}

float2 PixelUV(int2 p, int2 dim) {
    return (float2(p) + 0.5) / float2(dim);
}

bool InBounds(int2 p, int2 dim) {
    return all(p >= 0) && all(p < dim);
}

uint RawReason(float raw) {
    // Explicit comparisons also reject NaN, infinities and out-of-range reads.
    if (!(raw >= 0.0 && raw <= 1.0))
        return InvalidRaw;
    return abs(raw - ProjectionExtra.z) <= 3e-8 ? ClearDepth : Valid;
}

float LoadSampleZero(int2 p) {
    float raw = 0.0;
    [branch] if (DepthInfo.x == 1.0)
        raw = DepthInput.Load(int3(p, 0));
    else
        raw = DepthMSInput.Load(p, 0);
    return raw;
}

DepthSample ResolveDepth(int2 p) {
    DepthSample s;
    s.raw = 0.0;
    s.z = 0.0;
    s.minZ = 0.0;
    s.maxZ = 0.0;
    s.coverage = 0.0;
    s.reason = InvalidRaw;
    int count = int(DepthInfo.x);
    bool calibrated = CameraParams.z > 0.0;

    [branch] if (count == 1) {
        s.raw = DepthInput.Load(int3(p, 0));
        s.reason = RawReason(s.raw);
        s.coverage = s.reason == Valid ? 1.0 : 0.0;
        if (s.reason == Valid && calibrated) {
            s.z = ViewZ(s.raw);
            s.minZ = s.z;
            s.maxZ = s.z;
            if (s.z <= 0.0)
                s.reason = InvalidProjection;
        }
    } else if (count == 2 || count == 4 || count == 8) {
        float rawSum = 0.0;
        float minZ = 1e7;
        float maxZ = 0.0;
        int validCount = 0;
        int clearCount = 0;
        bool badProjection = false;
        [loop] for (int sampleIndex = 0; sampleIndex < count; ++sampleIndex) {
            float raw = DepthMSInput.Load(p, sampleIndex);
            uint reason = RawReason(raw);
            validCount += reason == Valid ? 1 : 0;
            clearCount += reason == ClearDepth ? 1 : 0;
            if (reason == Valid) {
                rawSum += raw;
                if (calibrated) {
                    float z = ViewZ(raw);
                    badProjection = badProjection || z <= 0.0;
                    minZ = min(minZ, z);
                    maxZ = max(maxZ, z);
                }
            }
        }
        s.coverage = float(validCount) / float(count);
        if (validCount != count) {
            s.reason = validCount > 0 ? MixedMsaa : clearCount == count ? ClearDepth : InvalidRaw;
        } else if (!calibrated) {
            s.reason = Valid;
        } else if (badProjection) {
            s.reason = InvalidProjection;
        } else {
            float tolerance = max(0.004, min(0.020 * minZ, 0.16 * EffectRadius()));
            if (maxZ - minZ > tolerance) {
                s.reason = MixedMsaa;
            } else {
                s.raw = rawSum / float(count);
                s.z = ViewZ(s.raw);
                s.minZ = minZ;
                s.maxZ = maxZ;
                s.reason = s.z > 0.0 ? Valid : InvalidProjection;
            }
        }
    }
    return s;
}

float CoherentRange(float minZ) {
    return max(0.004, min(0.025 * minZ, 0.20 * EffectRadius()));
}

// Depth storage: R positive view Z, G valid raw coverage, B/A conservative
// nearest/farthest Z. A rejected value has R=0 and its reason encoded in B.
float4 RejectedDepth(float coverage, uint reason) {
    return float4(0.0, coverage, float(reason), 0.0);
}

// At a grazing angle, two pixels on one plane may differ greatly in view Z.
// Confirm their affine raw-depth slope against a third texel on either side.
// A depth step has no such continuation and remains rejected.
bool PlanarRun(int2 a, int2 b, int2 dim, float depthA, float depthB) {
    int2 distance = b - a;
    float rawSlope = depthB - depthA;
    float tolerance = max(1.5e-7, 0.10 * abs(rawSlope));
    int2 before = a - distance;
    int2 after = b + distance;
    bool followsPlane = false;
    if (InBounds(before, dim)) {
        float sampleBefore = DepthInput.Load(int3(before, 0));
        followsPlane = RawReason(sampleBefore) == Valid &&
                       abs(depthA - sampleBefore - rawSlope) <= tolerance;
    }
    if (!followsPlane && InBounds(after, dim)) {
        float sampleAfter = DepthInput.Load(int3(after, 0));
        followsPlane = RawReason(sampleAfter) == Valid &&
                       abs(sampleAfter - depthB - rawSlope) <= tolerance;
    }
    return followsPlane;
}

bool PlanarFootprint(int2 origin, int2 dim, float2 blend, float4 taps) {
    int2 first = int2(0, 0);
    int2 last = int2(blend.x > 0.0, blend.y > 0.0);
    float a = taps[first.x + 2 * first.y];
    float b = taps[last.x + 2 * first.y];
    float c = taps[first.x + 2 * last.y];
    float d = taps[last.x + 2 * last.y];
    float gx = max(abs(b - a), abs(d - c));
    float gy = max(abs(c - a), abs(d - b));
    if (abs(a - b - c + d) > max(1.5e-7, 0.10 * max(gx, gy)))
        return false;

    int2 tl = clamp(origin + first, int2(0, 0), dim - 1);
    int2 br = clamp(origin + last, int2(0, 0), dim - 1);
    int2 tr = int2(br.x, tl.y);
    int2 bl = int2(tl.x, br.y);
    if (gx > 0.15 * gy && tl.x != br.x &&
        (!PlanarRun(tl, tr, dim, a, b) || !PlanarRun(bl, br, dim, c, d)))
        return false;
    if (gy > 0.15 * gx && tl.y != br.y &&
        (!PlanarRun(tl, bl, dim, a, c) || !PlanarRun(tr, br, dim, b, d)))
        return false;
    return gx > 0.0 || gy > 0.0;
}

float4 PSPrepare(VOUT i) : SV_Target {
    int2 sourceDim = int2(DepthInfo.yz);
    int2 aoDim = int2((uint2(round(1.0 / InvSize)) + 1u) >> 1u);
    int2 targetPixel = int2(i.pos.xy);
    float2 coord = PixelUV(targetPixel, aoDim) * float2(sourceDim) - 0.5;
    if (sourceDim.x == aoDim.x) coord.x = float(targetPixel.x);
    if (sourceDim.y == aoDim.y) coord.y = float(targetPixel.y);
    int2 origin = int2(floor(coord));
    float2 blend = frac(coord);
    float raw = 0.0;
    float4 taps = 0.0;
    float coverage = 0.0;
    float minZ = 1e7;
    float maxZ = 0.0;
    uint reason = Valid;

    // Hardware depth is affine in screen XY for a planar triangle. Interpolate
    // it at the AO texel center after validating the contributing samples.
    [unroll] for (int y = 0; y < 2; ++y) {
        [unroll] for (int x = 0; x < 2; ++x) {
            float weight = (x == 0 ? 1.0 - blend.x : blend.x)
                         * (y == 0 ? 1.0 - blend.y : blend.y);
            if (weight > 0.0) {
                int2 p = clamp(origin + int2(x, y), int2(0, 0), sourceDim - 1);
                DepthSample s = ResolveDepth(p);
                coverage += s.coverage * weight;
                if (s.reason == Valid) {
                    raw += s.raw * weight;
                    taps[x + y * 2] = s.raw;
                    minZ = min(minZ, s.minZ);
                    maxZ = max(maxZ, s.maxZ);
                } else {
                    reason = max(reason, s.reason);
                }
            }
        }
    }
    if (reason != Valid)
        return RejectedDepth(coverage, coverage > 0.0 && reason == ClearDepth ? MixedFootprint : reason);
    if (maxZ - minZ > CoherentRange(minZ)) {
        if (DepthInfo.x != 1.0 || maxZ - minZ > 0.22 * minZ ||
            !PlanarFootprint(origin, sourceDim, blend, taps))
            return RejectedDepth(coverage, MixedFootprint);
    }
    float z = ViewZ(raw);
    return z > 0.0 ? float4(z, coverage, minZ, maxZ) : RejectedDepth(coverage, InvalidProjection);
}

float4 PSDownsample(VOUT i) : SV_Target {
    uint w, h;
    XEDepth.GetDimensions(w, h);
    int2 sourceDim = int2(w, h);
    int2 targetDim = max(sourceDim >> 1, int2(1, 1));
    float2 scale = float2(sourceDim) / float2(targetDim);
    float2 lower = floor(i.pos.xy) * scale;
    float2 upper = lower + scale;
    int2 origin = int2(floor(lower));
    float minZ = 1e7;
    float maxZ = 0.0;
    float area = 0.0;
    float inverseZ = 0.0;
    float coverage = 0.0;
    bool coherent = true;

    // Area weights include the last source texel at odd dimensions (e.g. 5->2).
    // Min/max span is inherited, so a disjoint surface cannot reappear at LOD4.
    [unroll] for (int y = 0; y < 3; ++y) {
        [unroll] for (int x = 0; x < 3; ++x) {
            int2 p = origin + int2(x, y);
            float2 span = max(0.0, min(upper, float2(p + 1)) - max(lower, float2(p)));
            float weight = span.x * span.y;
            if (weight > 1e-5 && InBounds(p, sourceDim)) {
                float4 d = XEDepth.Load(int3(p, 0));
                coverage += d.g * weight;
                area += weight;
                coherent = coherent && d.r > 0.0;
                if (d.r > 0.0) {
                    minZ = min(minZ, d.b);
                    maxZ = max(maxZ, d.a);
                    inverseZ += weight / d.r;
                }
            }
        }
    }
    coverage /= max(area, 1e-5);
    if (!coherent || maxZ - minZ > CoherentRange(minZ) || inverseZ <= 0.0)
        return RejectedDepth(coverage, MixedFootprint);
    return float4(area / inverseZ, coverage, minZ, maxZ);
}

float4 DepthAt(int2 p, int2 dim) {
    if (!InBounds(p, dim))
        return 0.0;
    return XEDepth.Load(int3(p, 0));
}

int2 DepthDimensions() {
    uint w, h;
    XEDepth.GetDimensions(w, h);
    return int2(w, h);
}

float3 NormalizeOrZero(float3 v) {
    return v * rsqrt(max(dot(v, v), 1e-16));
}

// Intel XeGTAO slope-adjusted continuity and four triangular normal estimates.
// Invalid neighbors contribute neither an edge nor a fabricated depth.
bool DepthNormal(int2 p, int2 dim, float z, out float3 normal, out float4 edges) {
    float4 l = DepthAt(p + int2(-1, 0), dim);
    float4 r = DepthAt(p + int2(1, 0), dim);
    float4 t = DepthAt(p + int2(0, -1), dim);
    float4 b = DepthAt(p + int2(0, 1), dim);
    float4 neighborZ = float4(l.r, r.r, t.r, b.r);
    bool4 hasDepth = neighborZ > 0.0;
    float4 delta = neighborZ - z;
    float slopeX = hasDepth.x && hasDepth.y ? (delta.y - delta.x) * 0.5 : 0.0;
    float slopeY = hasDepth.z && hasDepth.w ? (delta.w - delta.z) * 0.5 : 0.0;
    float4 residual = min(abs(delta), abs(delta + float4(slopeX, -slopeX, slopeY, -slopeY)));
    // Retain the direct edge test when both axial neighbors make the slope
    // estimate ambiguous at a wide depth jump.
    residual = max(residual, max(0.0, abs(delta) - 0.070 * z));
    float edgeWidth = z * lerp(0.014, 0.008, saturate(AOExtra.y * 0.5));
    edges = saturate(1.25 - residual / edgeWidth) * float4(hasDepth);

    float3 c = ViewPosition(PixelUV(p, dim), z);
    float3 vl = NormalizeOrZero(ViewPosition(PixelUV(p + int2(-1, 0), dim), l.r) - c);
    float3 vr = NormalizeOrZero(ViewPosition(PixelUV(p + int2(1, 0), dim), r.r) - c);
    float3 vt = NormalizeOrZero(ViewPosition(PixelUV(p + int2(0, -1), dim), t.r) - c);
    float3 vb = NormalizeOrZero(ViewPosition(PixelUV(p + int2(0, 1), dim), b.r) - c);
    float3 n = edges.x * edges.z * cross(vl, vt)
             + edges.z * edges.y * cross(vt, vr)
             + edges.y * edges.w * cross(vr, vb)
             + edges.w * edges.x * cross(vb, vl);
    normal = NormalizeOrZero(n);
    return dot(n, n) > 1e-5 && dot(normal, NormalizeOrZero(-c)) > 0.001;
}

float PackEdges(float4 edges) {
    return dot(round(saturate(edges) * 2.9), float4(64, 16, 4, 1)) / 255.0;
}

float4 UnpackEdges(float packed) {
    uint bits = uint(round(packed * 255.0));
    return float4((bits >> 6) & 3u, (bits >> 4) & 3u, (bits >> 2) & 3u, bits & 3u) / 3.0;
}

// Intel XeGTAO's Hilbert-driven R2 sequence with a fixed temporal index.
float2 SpatialNoise(uint2 p) {
    p &= 63u;
    uint index = 0u;
    [unroll] for (uint stride = 32u; stride > 0u; stride >>= 1u) {
        uint rx = (p.x & stride) != 0u ? 1u : 0u;
        uint ry = (p.y & stride) != 0u ? 1u : 0u;
        index += stride * stride * ((3u * rx) ^ ry);
        if (ry == 0u) {
            if (rx == 1u)
                p = 63u - p;
            p = p.yx;
        }
    }
    return frac(0.5 + float(index) * float2(0.7548776662466927, 0.5698402909980532));
}

float3 DepthPositionAtMip(int2 basePixel, int2 dim, int requestedMip) {
    float2 uv = PixelUV(basePixel, dim);
    // Reject incoherent coarse tiles and retry at the next finer exact texel.
    [loop] for (int mip = requestedMip; mip >= 0; --mip) {
        int2 mipDim = max(dim >> mip, int2(1, 1));
        int2 p = min(int2(uv * mipDim), mipDim - 1);
        float z = XEDepth.Load(int3(p, mip)).r;
        if (z > 0.0)
            return ViewPosition(PixelUV(p, mipDim), z);
    }
    return 0.0;
}

float UpdateHorizon(float horizon, float noOccluder, float3 samplePosition,
                    float3 center, float3 viewVec, float3 normal,
                    float radius, float planeBias) {
    if (samplePosition.z <= 0.0)
        return horizon;
    float3 delta = samplePosition - center;
    // An occluder has to cross the tangent plane. Scale the tolerance by
    // the reconstructed pixel footprint to handle depth quantization.
    float above = dot(delta, normal);
    if (above <= planeBias)
        return horizon;
    float3 biasedDelta = delta + center * 0.00001;
    float distanceToSample = length(biasedDelta);
    if (distanceToSample <= 1e-5)
        return horizon;
    float falloff = saturate((radius - distanceToSample) / (Falloff * radius));
    falloff *= smoothstep(planeBias, 3.0 * planeBias, above);
    float horizonCos = dot(biasedDelta / distanceToSample, viewVec);
    return max(horizon, lerp(noOccluder, horizonCos, falloff));
}

float ArcIntegral(float h, float n, float cosN, float sinN) {
    return (cosN + 2.0 * h * sinN - cos(2.0 * h - n)) * 0.25;
}

float HorizonVisibility(int2 p, int2 dim, float z, float3 normal) {
    float2 pixelSpan = 2.0 * z * CameraParams.zw / float2(dim);
    float radius = EffectRadius();
    float2 screenRadius = min(radius / max(pixelSpan, 1e-5), 96.0);
    float screenFade = smoothstep(1.3, 2.5, min(screenRadius.x, screenRadius.y));
    if (screenFade <= 0.0)
        return 1.0;

    float3 center = ViewPosition(PixelUV(p, dim), z);
    float3 viewVec = normalize(-center);
    float2 noise = SpatialNoise(uint2(p));
    int rays = AOParams.w < 0.5 ? 3 : AOParams.w < 1.5 ? 4 : 6;
    int steps = AOParams.w < 0.5 ? 2 : AOParams.w < 1.5 ? 3 : 4;
    float planeBias = max(0.002, min(pixelSpan.x, pixelSpan.y) * (0.20 + 0.15 * AOExtra.y));
    float unoccluded = 0.0;
    float visibility = 0.0;

    [loop] for (int slice = 0; slice < rays; ++slice) {
        float phi = Pi * (float(slice) + noise.x) / float(rays);
        float s, c;
        sincos(phi, s, c);
        float3 direction = float3(c, s, 0.0);
        float3 orthogonal = direction - viewVec * dot(direction, viewVec);
        float3 axis = NormalizeOrZero(cross(orthogonal, viewVec));
        float3 projectedNormal = normal - axis * dot(normal, axis);
        float projectedLength = length(projectedNormal);
        if (projectedLength < 1e-5)
            continue;

        float cosN = saturate(dot(projectedNormal, viewVec) / projectedLength);
        float n = (dot(orthogonal, projectedNormal) < 0.0 ? -1.0 : 1.0) * acos(cosN);
        float sinN = sin(n);
        float low0 = -sinN;
        float low1 = sinN;
        float hcos0 = low0;
        float hcos1 = low1;
        float2 omega = float2(c, -s) * screenRadius;
        float minStep = 1.3 / max(length(omega), 1e-5);

        [loop] for (int step = 0; step < steps; ++step) {
            float sampleNoise = frac(noise.y + float(slice + step * (rays + 1)) * 0.61803398875);
            float fraction = (float(step) + sampleNoise) / float(steps);
            float2 offset = omega * (fraction * fraction + minStep);
            float distanceInPixels = length(offset);
            int mip = int(clamp(round(log2(distanceInPixels) - 3.30), 0.0, 4.0));
            int2 sampleOffset = int2(round(offset));
            int2 a = p + sampleOffset;
            int2 b = p - sampleOffset;
            if (InBounds(a, dim))
                hcos0 = UpdateHorizon(hcos0, low0, DepthPositionAtMip(a, dim, mip), center, viewVec, normal, radius, planeBias);
            if (InBounds(b, dim))
                hcos1 = UpdateHorizon(hcos1, low1, DepthPositionAtMip(b, dim, mip), center, viewVec, normal, radius, planeBias);
        }

        float h0 = n + clamp(-acos(clamp(hcos1, -1.0, 1.0)) - n, -HalfPi, HalfPi);
        float h1 = n + clamp( acos(clamp(hcos0, -1.0, 1.0)) - n, -HalfPi, HalfPi);
        float sliceVisibility = ArcIntegral(h0, n, cosN, sinN) + ArcIntegral(h1, n, cosN, sinN);
        float sliceUnoccluded = cosN + n * sinN;
        visibility += projectedLength * max(0.0, sliceVisibility);
        unoccluded += projectedLength * sliceUnoccluded;
    }
    // Normalize against the same unobstructed quadrature to avoid treating an
    // inclined plane as occluded when it is integrated with a few directions.
    float ratio = unoccluded > 1e-5 ? saturate(visibility / unoccluded) : 1.0;
    return lerp(1.0, max(0.03, pow(ratio, 2.2 + 0.6 * saturate(AOExtra.x))), screenFade);
}

float4 PSAO(VOUT i) : SV_Target {
    int2 p = int2(i.pos.xy);
    int2 dim = DepthDimensions();
    float z = DepthAt(p, dim).r;
    if (z <= 0.0)
        return float4(1, 0, 0, 0);
    float3 normal;
    float4 edges;
    if (!DepthNormal(p, dim, z, normal, edges))
        return float4(1, PackEdges(edges), 0, 0);
    return float4(HorizonVisibility(p, dim, z, normal), PackEdges(edges), 1, 0);
}

float4 WorkingAO(int2 p, int2 dim) {
    if (!InBounds(p, dim))
        return float4(1, 0, 0, 0);
    return AOResult.Load(int3(p, 0));
}

void AddVisible(float4 tap, float weight, inout float value, inout float totalWeight) {
    weight *= tap.b;
    value += tap.r * weight;
    totalWeight += weight;
}

float4 PSAODenoise(VOUT i) : SV_Target {
    uint w, h;
    AOResult.GetDimensions(w, h);
    int2 dim = int2(w, h);
    int2 p = int2(i.pos.xy);
    float4 center = WorkingAO(p, dim);
    if (center.b < 0.5)
        return center;

    float4 l = WorkingAO(p + int2(-1, 0), dim);
    float4 r = WorkingAO(p + int2(1, 0), dim);
    float4 t = WorkingAO(p + int2(0, -1), dim);
    float4 b = WorkingAO(p + int2(0, 1), dim);
    float4 edgeL = UnpackEdges(l.g) * l.b;
    float4 edgeR = UnpackEdges(r.g) * r.b;
    float4 edgeT = UnpackEdges(t.g) * t.b;
    float4 edgeB = UnpackEdges(b.g) * b.b;
    float4 e = UnpackEdges(center.g) * float4(edgeL.y, edgeR.x, edgeT.w, edgeB.z);
    float4 tl = WorkingAO(p + int2(-1, -1), dim);
    float4 tr = WorkingAO(p + int2(1, -1), dim);
    float4 bl = WorkingAO(p + int2(-1, 1), dim);
    float4 br = WorkingAO(p + int2(1, 1), dim);
    float4 edgeTL = UnpackEdges(tl.g);
    float4 edgeTR = UnpackEdges(tr.g);
    float4 edgeBL = UnpackEdges(bl.g);
    float4 edgeBR = UnpackEdges(br.g);

    // XeGTAO direct/diagonal paths, with reciprocal edges on each segment
    // and zero leakage through a depth discontinuity or invalid texel.
    float totalWeight = AOParams.w < 0.5 ? 1.25 : AOParams.w < 1.5 ? 2.50 : 4.0;
    float sum = center.r * totalWeight;
    AddVisible(l, e.x, sum, totalWeight);
    AddVisible(r, e.y, sum, totalWeight);
    AddVisible(t, e.z, sum, totalWeight);
    AddVisible(b, e.w, sum, totalWeight);
    AddVisible(tl, 0.425 * (e.x * edgeL.z * edgeTL.w + e.z * edgeT.x * edgeTL.y), sum, totalWeight);
    AddVisible(tr, 0.425 * (e.y * edgeR.z * edgeTR.w + e.z * edgeT.y * edgeTR.x), sum, totalWeight);
    AddVisible(bl, 0.425 * (e.x * edgeL.w * edgeBL.z + e.w * edgeB.x * edgeBL.y), sum, totalWeight);
    AddVisible(br, 0.425 * (e.y * edgeR.w * edgeBR.z + e.w * edgeB.y * edgeBR.x), sum, totalWeight);
    return float4(saturate(sum / totalWeight), center.g, center.b, 0);
}

float UpsampleVisibility(float2 uv, int2 dim, DepthSample surface, out bool supported) {
    supported = false;
    if (surface.reason != Valid)
        return 1.0;
    float2 q = uv * float2(dim) - 0.5;
    int2 origin = int2(floor(q));
    float2 blend = frac(q);
    float sum = 0.0;
    float total = 0.0;
    float radius = EffectRadius();
    [unroll] for (int y = 0; y < 2; ++y) {
        [unroll] for (int x = 0; x < 2; ++x) {
            int2 p = clamp(origin + int2(x, y), int2(0, 0), dim - 1);
            float4 prep = XEDepth.Load(int3(p, 0));
            float4 visibility = AOResult.Load(int3(p, 0));
            float footprint = (x == 0 ? 1.0 - blend.x : blend.x)
                            * (y == 0 ? 1.0 - blend.y : blend.y);
            if (prep.r > 0.0 && visibility.b > 0.5) {
                float threshold = max(0.006, min(0.014 * surface.z, 0.14 * radius));
                float delta = max(0.0, max(prep.b - surface.z, surface.z - prep.a));
                if (delta < threshold) {
                    float weight = footprint * (1.0 - smoothstep(0.0, threshold, delta));
                    total += weight;
                    sum += weight * visibility.r;
                }
            }
        }
    }
    // A tiny depth-weighted footprint should not stretch a neighbor into an
    // unsupported silhouette. Fade only on insufficient matching support.
    supported = total > 1e-4;
    return supported ? lerp(1.0, saturate(sum / total), smoothstep(0.06, 0.48, total)) : 1.0;
}

float HudWeight(float2 uv) {
    if (DepthInfo.w < 0.5)
        return 1.0;
    float left = (1.0 - smoothstep(0.16, 0.22, uv.x)) * smoothstep(0.60, 0.69, uv.y);
    float right = smoothstep(0.88, 0.95, uv.x) * smoothstep(0.77, 0.86, uv.y);
    return 1.0 - max(left, right);
}

float3 RejectionColor(uint reason) {
    if (reason == Valid) return float3(0.03, 0.80, 0.18);
    if (reason == ClearDepth) return float3(0.76, 0.08, 0.73);
    if (reason == InvalidRaw) return float3(0.95, 0.06, 0.08);
    if (reason == MixedMsaa) return float3(1.00, 0.54, 0.05);
    if (reason == InvalidProjection) return float3(0.48, 0.14, 0.93);
    if (reason == MixedFootprint) return float3(0.96, 0.87, 0.08);
    if (reason == MissingNormal) return float3(0.05, 0.80, 0.88);
    if (reason == MissingSurface) return float3(1.00, 0.38, 0.38);
    if (reason == MissingCamera) return float3(0.16, 0.38, 0.95);
    if (reason == MissingPipeline) return float3(0.38, 0.38, 0.38);
    return float3(0.04, 0.08, 0.28); // no depth input available
}

float DisplayZ(float z) {
    return saturate(log2(1.0 + max(z, 0.0)) / 11.0);
}

float SRGBToLinear(float v) {
    return v <= 0.04045 ? v / 12.92 : pow(max((v + 0.055) / 1.055, 0.0), 2.4);
}

float LinearToSRGB(float v) {
    return v <= 0.0031308 ? 12.92 * v : 1.055 * pow(max(v, 0.0), 1.0 / 2.4) - 0.055;
}

float3 MultiplyLinearVisibility(float3 signal, float visibility) {
    if (AOExtra.z > 0.5)
        return signal * visibility;
    float3 linearColor = float3(SRGBToLinear(signal.r), SRGBToLinear(signal.g), SRGBToLinear(signal.b));
    linearColor *= visibility;
    return float3(LinearToSRGB(linearColor.r), LinearToSRGB(linearColor.g), LinearToSRGB(linearColor.b));
}

float3 Diagnostic(float2 uv, int mode, DepthSample surface) {
    if (mode == 4)
        return DisplayZ(surface.z).xxx;
    if (mode == 5) {
        if (surface.reason != Valid)
            return RejectionColor(surface.reason);
        return RejectionColor(CameraParams.z > 0.0 ? Valid : MissingCamera);
    }
    if (AOExtra.w < 2.0) {
        if (mode == 6)
            return surface.coverage.xxx;
        if (mode == 15) {
            uint pending = CameraParams.z > 0.0 ? MissingPipeline : MissingCamera;
            return RejectionColor(surface.reason == Valid ? pending : surface.reason);
        }
        return mode == 2 ? 1.0 : 0.0;
    }

    int2 dim = DepthDimensions();
    int2 p = min(int2(uv * float2(dim)), dim - 1);
    float4 d = XEDepth.Load(int3(p, 0));
    if (mode == 6)
        return d.g.xxx;
    if (mode == 7) {
        float3 normal;
        float4 edges;
        if (d.r <= 0.0 || !DepthNormal(p, dim, d.r, normal, edges))
            return 0.0;
        return normal * 0.5 + 0.5;
    }
    if (mode >= 8 && mode <= 12) {
        int mip = mode - 8;
        int2 mdim = max(dim >> mip, int2(1, 1));
        float z = XEDepth.Load(int3(min(int2(uv * mdim), mdim - 1), mip)).r;
        return DisplayZ(z).xxx;
    }
    if (mode == 13)
        return AORaw.Load(int3(p, 0)).rrr;
    if (mode == 14)
        return AOResult.Load(int3(p, 0)).rrr;

    bool supported;
    float resolved = UpsampleVisibility(uv, dim, surface, supported);
    if (mode == 15) {
        uint reason = surface.reason;
        if (reason == Valid) {
            if (d.r <= 0.0)
                reason = uint(round(d.b));
            else if (AORaw.Load(int3(p, 0)).b < 0.5)
                reason = MissingNormal;
            else if (!supported)
                reason = MissingSurface;
        }
        return RejectionColor(reason);
    }
    float applied = lerp(1.0, resolved, saturate(AOParams.y * HudWeight(uv)));
    return applied.xxx;
}

float4 PSMain(VOUT i) : SV_Target {
    float4 color = Scene.SampleLevel(Sample0, i.uv, 0);
    float3 rgb = color.rgb;
    int mode = int(AOParams.x);
    if (mode == 1 && AOExtra.w >= 2.0) {
        int2 size = int2(DepthInfo.yz);
        DepthSample s = ResolveDepth(min(int2(i.uv * float2(size)), size - 1));
        bool supported;
        float visibility = UpsampleVisibility(i.uv, DepthDimensions(), s, supported);
        float applied = lerp(1.0, visibility, saturate(AOParams.y * HudWeight(i.uv)));
        if (applied < 1.0)
            rgb = MultiplyLinearVisibility(rgb, applied);
    }

    if (mode < 2 && Fx > 0.5) {
        float3 l = Scene.SampleLevel(Sample0, i.uv - float2(InvSize.x, 0), 0).rgb;
        float3 r = Scene.SampleLevel(Sample0, i.uv + float2(InvSize.x, 0), 0).rgb;
        float3 t = Scene.SampleLevel(Sample0, i.uv - float2(0, InvSize.y), 0).rgb;
        float3 b = Scene.SampleLevel(Sample0, i.uv + float2(0, InvSize.y), 0).rgb;
        rgb = saturate(rgb + Sharp * (color.rgb - (l + r + t + b) * 0.25));
        float luminance = dot(rgb, float3(0.2126, 0.7152, 0.0722));
        rgb = lerp(luminance.xxx, rgb, Sat);
        rgb = saturate((rgb - 0.5) * Contrast + 0.5 + Bright);
        rgb = pow(max(rgb, 0.00001), 1.0 / max(Gamma, 0.5));
    }
    if (mode >= 2) {
        if (AOExtra.w >= 1.0) {
            int2 size = int2(DepthInfo.yz);
            int2 p = min(int2(i.uv * float2(size)), size - 1);
            if (mode == 3)
                rgb = saturate(LoadSampleZero(p)).xxx;
            else
                rgb = Diagnostic(i.uv, mode, ResolveDepth(p));
        } else if (mode == 5 || mode == 15) {
            rgb = RejectionColor(MissingInput);
        } else {
            rgb = mode == 2 ? 1.0 : 0.0;
        }
    }
    if (Menu > 0.5) {
        int2 xy = int2(i.pos.xy) - int2(32, 32);
        if (all(xy >= 0) && xy.x < 600 && xy.y < 930) {
            float4 top = Overlay.Load(int3(xy, 0));
            rgb = lerp(rgb, top.rgb, top.a);
        }
    }
    return float4(saturate(rgb), color.a);
}
