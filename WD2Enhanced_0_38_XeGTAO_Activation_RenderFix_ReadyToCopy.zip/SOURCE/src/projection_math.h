#ifndef WD2_PROJECTION_MATH_H
#define WD2_PROJECTION_MATH_H

/* Canonical position uses right/up/forward axes, with positive view Z.
   For D3D depth d: d = depthA + depthB / z.
   NDC x and y include the projection's per-frame offsets. */
typedef struct {
 float scaleX, scaleY, offsetX, offsetY, depthA, depthB;
 unsigned int reverseZ;
} Projection_;

/* Compatibility profile inherited from 0.36. The clear endpoint is
   observed; FOV, clip planes and zero jitter are estimates. */
static inline int projection_wd2_clear_in_range(float clear)
{
 /* Allow small endpoint offsets while keeping the actual clear for sky masking. */
 return (clear>=0.0f && clear<=0.0001f) || (clear>=0.9999f && clear<=1.0f);
}

static inline int projection_estimate_wd2(unsigned int width, unsigned int height,
                                         float clearDepth, Projection_* out)
{
 if (!width || !height || !projection_wd2_clear_in_range(clearDepth))
  return 0;

 const float nearZ = 0.1f;
 const float farZ = 1000.0f;
 const float scaleY = 1.428148007f; /* cot(70 degrees / 2) */
 const float depthRange = farZ - nearZ;
 const float reverseA = -nearZ / depthRange;
 const float reverseB = nearZ * farZ / depthRange;
 const unsigned int reverseZ = clearDepth < 0.5f;
 const Projection_ estimate = {
  scaleY * ((float)height / (float)width), scaleY, 0.0f, 0.0f,
  reverseZ ? reverseA : 1.0f - reverseA,
  reverseZ ? reverseB : -reverseB,
  reverseZ
 };
 *out = estimate;
 return 1;
}

static float projection_abs(float v)
{
 return v < 0.0f ? -v : v;
}

static int projection_between(float v, float lower, float upper)
{
 return v >= lower && v <= upper;
}

static float projection_matrix_value(const float matrix[16], unsigned int row,
                                     unsigned int col, int transposed)
{
 return matrix[transposed ? 4 * col + row : 4 * row + col];
}

static int projection_decode(const float matrix[16], int transposed,
                             unsigned int width, unsigned int height,
                             float clearDepth, Projection_* result)
{
 const float zero = 0.00002f;
 if (!width || !height) return 0;

 float w = projection_matrix_value(matrix, 3, 2, transposed);
 if (!projection_between(projection_abs(w), 1.0f - zero, 1.0f + zero))
  return 0;

 for (unsigned int row = 0; row < 4; ++row) {
  for (unsigned int col = 0; col < 4; ++col) {
   float value = projection_matrix_value(matrix, row, col, transposed);
   int used = (row < 3 && row == col) || col == 2 || (row == 2 && col == 3);
   if (!projection_between(value, -100.0f, 100.0f)) return 0;
   if (!used && projection_abs(value) > zero) return 0;
  }
 }

 Projection_ p;
 p.scaleX = projection_matrix_value(matrix, 0, 0, transposed) / projection_abs(w);
 p.scaleY = projection_matrix_value(matrix, 1, 1, transposed) / projection_abs(w);
 p.offsetX = projection_matrix_value(matrix, 0, 2, transposed) / w;
 p.offsetY = projection_matrix_value(matrix, 1, 2, transposed) / w;
 p.depthA = projection_matrix_value(matrix, 2, 2, transposed) / w;
 p.depthB = projection_matrix_value(matrix, 2, 3, transposed) / projection_abs(w);
 if (!projection_between(p.scaleX, 0.12f, 8.0f) ||
     !projection_between(p.scaleY, 0.35f, 6.5f)) return 0;
 float aspect = (float)width / (float)height;
 if (projection_abs(p.scaleY / p.scaleX - aspect) > aspect * 0.018f)
  return 0;
 /* Support modest asymmetry, such as subpixel TAA jitter. Large lens
    shifts and non-centered viewport transforms need separate validation. */
 if (projection_abs(p.offsetX) > 8.0f / (float)width ||
     projection_abs(p.offsetY) > 8.0f / (float)height)
  return 0;

 float nearZ, inverseFar;
 if (projection_between(clearDepth, 0.0f, zero) &&
     p.depthA <= 0.0f && p.depthB > 0.0f) {
  p.reverseZ = 1;
  nearZ = p.depthB / (1.0f - p.depthA);
  inverseFar = -p.depthA / p.depthB;
 } else if (projection_between(clearDepth, 1.0f - zero, 1.0f) &&
            p.depthA >= 1.0f && p.depthB < 0.0f) {
  p.reverseZ = 0;
  nearZ = -p.depthB / p.depthA;
  inverseFar = (1.0f - p.depthA) / p.depthB;
 } else {
  return 0;
 }
 if (!projection_between(nearZ, 0.004f, 8.0f) ||
     !projection_between(inverseFar * nearZ, 0.0f, 1.0f / 24.0f))
  return 0;

 *result = p;
 return 1;
}

static int projection_matches(const Projection_* a, const Projection_* b,
                              unsigned int width, unsigned int height,
                              int sameFrame)
{
 float scaleTolerance = sameFrame ? 0.00005f : 0.003f;
 float depthTolerance = sameFrame ? 0.000002f : 0.003f;
 float depthATolerance = sameFrame ? 0.0000002f : 0.003f;
 if (a->reverseZ != b->reverseZ ||
     projection_abs(a->scaleX - b->scaleX) > a->scaleX * scaleTolerance ||
     projection_abs(a->scaleY - b->scaleY) > a->scaleY * scaleTolerance ||
     projection_abs(a->depthA - b->depthA) > depthATolerance ||
     projection_abs(a->depthB - b->depthB) > projection_abs(a->depthB) * depthTolerance)
  return 0;

 /* Distinct same-frame jitter (including jitter-free versus jittered
    constants) is ambiguous without knowing which matrix the VS uses. */
 if (sameFrame &&
     (projection_abs(a->offsetX - b->offsetX) > 0.04f / (float)width ||
      projection_abs(a->offsetY - b->offsetY) > 0.04f / (float)height))
  return 0;
 return 1;
}

#endif
