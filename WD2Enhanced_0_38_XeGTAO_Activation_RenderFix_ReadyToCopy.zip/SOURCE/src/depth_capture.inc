/* Depth capture on the immediate context. All histories are bounded and only
   the current target Present interval may supply a gameplay snapshot. */
#define CAPTURE_INVALID 0xffffffffu
#define CAPTURE_SNAPSHOTS 4
#define CAPTURE_COLORS 48
#define CAPTURE_INPUTS 32
#define CAPTURE_MAX_PASSES 96
enum { COMPAT_CLEAR_RANGE=1, COMPAT_PARTIAL=2, COMPAT_TRANSFER=4, COMPAT_DISCARD=8 };
#define KEEP_RTV_DSV 0xffffffffu

typedef struct {
 P texture,srv;
 TEX2D_DESC desc;
 U64 frame,epoch,write;
 U32 candidate,boundary,consumed;
 float clear;
} DEPTH_SNAPSHOT_;
typedef struct { P resource; U32 sources; } CAPTURE_COLOR_;
typedef struct { P view,resource; U32 width,height; } CAPTURE_RTV_;
typedef struct { U32 format,dimension,flags,mip,pad[2]; } CAPTURE_DSV_DESC_;
typedef struct { U32 format,dimension,mip,pad[2]; } CAPTURE_RTV_DESC_;
typedef struct {
 U32 depthEnable,depthWrite,depthFunc,stencilEnable,other[9];
} CAPTURE_DEPTH_STATE_;
typedef struct {
 U32 fill,cull,frontCCW;
 I32 depthBias;
 float depthBiasClamp,slopeBias;
 U32 depthClip,scissor,multisample,antialiasedLine;
} CAPTURE_RASTER_;
typedef struct { U32 left,top,front,right,bottom,back; } CAPTURE_BOX_;

static DEPTH_SNAPSHOT_ g_depthSnapshots[CAPTURE_SNAPSHOTS];
static DEPTH_SNAPSHOT_ g_compatDepth;
static U32 g_compatConflict,g_captureOpaque;
static U32 g_lastDepthStatus=DEPTH_WAITING;
static U32 g_depthAllocationFailed,g_depthSnapshotLogged;
static U64 g_depthAllocationRetry;
static CAPTURE_COLOR_ g_captureColors[CAPTURE_COLORS];
static CAPTURE_RTV_ g_captureRt[8];
static U64 g_captureFrame=~0ull;
static U32 g_captureColorCount,g_capturePasses,g_captureUnsafe,g_captureUncertain,g_captureFreshInputs;
static U32 g_captureBoundsLoaded,g_captureOutputsLoaded,g_captureViewportCount,g_captureScissorCount;
static U32 g_captureDepthEnabled,g_captureDepthWrite,g_captureScissorEnabled,g_captureComparison;
static U32 g_captureBlend[8],g_captureWriteMask[8];
static P g_captureDsv;
static U32 g_captureWritable;
static VIEWPORT_ g_captureViewport;
static RECT_ g_captureScissor;
static U32 g_lastDepthSelection=CAPTURE_INVALID;

static void (CALL *g_originalOM)(P,U32,P*,P);
static void (CALL *g_originalOMUAV)(P,U32,P*,P,U32,U32,P*,const U32*);
static void (CALL *g_originalClearDepth)(P,P,U32,float,U8);
static void (CALL *g_originalSetViewports)(P,U32,const VIEWPORT_*);
static void (CALL *g_originalSetScissors)(P,U32,const RECT_*);
static void (CALL *g_originalSetRaster)(P,P);
static void (CALL *g_originalSetDepth)(P,P,U32);
static void (CALL *g_originalSetBlend)(P,P,const float*,U32);
static void (CALL *g_originalClearRT)(P,P,const float*);
static void (CALL *g_originalCopy)(P,P,P);
static void (CALL *g_originalResolve)(P,P,U32,P,U32,U32);
static void (CALL *g_originalCopyRegion)(P,P,U32,U32,U32,U32,P,U32,const CAPTURE_BOX_*);
static void (CALL *g_originalClearState)(P);
static void (CALL *g_originalCopyRegion1)(P,P,U32,U32,U32,U32,P,U32,const CAPTURE_BOX_*,U32);
static void (CALL *g_originalDiscardResource)(P,P);
static void (CALL *g_originalDiscardView)(P,P);
static void (CALL *g_originalSwapState)(P,P,P*);
static void (CALL *g_originalClearView)(P,P,const float*,const RECT_*,U32);
static void (CALL *g_originalDiscardView1)(P,P,const RECT_*,U32);
static volatile U32 g_rawOMCalls,g_presentOMCalls,g_foreignOMCalls;

static U32 capture_srv_format(U32 format){
 switch(format){
  case 19: return 21; /* R32G8X24_TYPELESS -> R32_FLOAT_X8X24_TYPELESS */
  case 39: return 41; /* R32_TYPELESS -> R32_FLOAT */
  case 44: return 46; /* R24G8_TYPELESS -> R24_UNORM_X8_TYPELESS */
  case 53: return 56; /* R16_TYPELESS -> R16_UNORM */
  default: return 0;
 }
}
static void capture_release_selected(void){
 REL(g_aoDepthSrv);
 g_aoDepthIndex=CAPTURE_INVALID;
 g_aoDepthFrame=~0ull;
 g_aoDepthEpoch=0;
 g_aoDepthClear=0;
 g_aoDepthBoundary=DEPTH_BOUNDARY_NONE;
}
static void capture_release_frame_colors(void){
 for(U32 i=0;i<g_captureColorCount;i++){
  REL(g_captureColors[i].resource);
  g_captureColors[i].sources=0;
 }
 g_captureColorCount=0;
}
static void capture_release_bindings(void){
 for(U32 i=0;i<8;i++){
  REL(g_captureRt[i].view);
  REL(g_captureRt[i].resource);
 }
 REL(g_captureDsv);
 g_depthActive=CAPTURE_INVALID;
 g_captureWritable=0;
 g_captureBoundsLoaded=0;
 g_captureOutputsLoaded=0;
}
static void reset_depth_capture(void){
 capture_release_selected();
 capture_release_frame_colors();
 capture_release_bindings();
 for(U32 i=0;i<CAPTURE_SNAPSHOTS;i++){
  DEPTH_SNAPSHOT_ *s=&g_depthSnapshots[i];
  REL(s->srv);
  REL(s->texture);
  s->frame=~0ull;
 }
 REL(g_compatDepth.srv);
 REL(g_compatDepth.texture);
 g_compatDepth.frame=~0ull;
 g_compatConflict=g_captureOpaque=0;
 g_captureFrame=~0ull;
 g_depthSerial=0;
 g_lastDepthSelection=CAPTURE_INVALID;
 g_lastDepthStatus=DEPTH_WAITING;
 g_depthAllocationFailed=g_depthSnapshotLogged=0;
 g_depthAllocationRetry=0;
 g_aoDepthStatus=DEPTH_WAITING;
}
static void capture_begin_frame(void){
 if(g_captureFrame==g_frame)return;
 capture_release_frame_colors();
 g_captureFrame=g_frame;
 g_capturePasses=0;
 g_captureFreshInputs=0;
 g_compatConflict=g_captureOpaque=0;
 g_captureUnsafe=0;
 g_captureUncertain=0;
}
/* The private immediate context serializes ordinary calls. Contended
   observers abandon the interval rather than using uncertain observations. */
static int capture_enter(void){
 if(__sync_lock_test_and_set(&g_depthGuard,1)){
  __sync_lock_test_and_set(&g_captureUncertain,1);
  return 0;
 }
 capture_begin_frame();
 return 1;
}
static void capture_leave(void){
 __sync_lock_release(&g_depthGuard);
}
static int capture_observing(P ctx){
 return ctx==g_ctx && !g_presentBusy && !g_internalDrawActive &&
        (g_depthEnabled || g_depthDone);
}
static int capture_related_size(U32 width,U32 height){
 if(!g_width || !g_height || width<(g_width+1)/2 || height<(g_height+1)/2 ||
    width>g_width*2 || height>g_height*2)return 0;
 U64 a=(U64)width*g_height,b=(U64)height*g_width;
 U64 d=a>b?a-b:b-a;
 return d<=b/100;
}
static int capture_full_bounds(U32 width,U32 height){
 if(g_captureViewportCount!=1)return 0;
 const VIEWPORT_ *v=&g_captureViewport;
 if(!(v->TopLeftX>=-0.01f && v->TopLeftX<=0.01f &&
      v->TopLeftY>=-0.01f && v->TopLeftY<=0.01f &&
      v->Width>=width-0.01f && v->Width<=width+0.01f &&
      v->Height>=height-0.01f && v->Height<=height+0.01f &&
      v->MinDepth==0.0f && v->MaxDepth==1.0f))return 0;
 if(!g_captureScissorEnabled)return 1;
 const RECT_ *r=&g_captureScissor;
 return g_captureScissorCount==1 && r->left<=0 && r->top<=0 &&
        r->right>=(I32)width && r->bottom>=(I32)height;
}
static void capture_depth_state(P state){
 CAPTURE_DEPTH_STATE_ d={1,1,2,0,{0}}; /* Default D3D11 depth func LESS. */
 if(state)V(state,7,void(CALL*)(P,CAPTURE_DEPTH_STATE_*))(state,&d);
 g_captureDepthEnabled=d.depthEnable;
 g_captureDepthWrite=d.depthEnable && d.depthWrite;
 g_captureComparison=d.depthFunc;
}
static void capture_raster_state(P state){
 CAPTURE_RASTER_ d={0};
 if(state)V(state,7,void(CALL*)(P,CAPTURE_RASTER_*))(state,&d);
 g_captureScissorEnabled=d.scissor;
}
static void capture_blend_state(P state){
 BLEND_DESC_ d={0};
 d.Target[0].RenderTargetWriteMask=15;
 if(state)V(state,7,void(CALL*)(P,BLEND_DESC_*))(state,&d);
 for(U32 i=0;i<8;i++){
  const TARGET_BLEND_ *t=&d.Target[d.IndependentBlendEnable?i:0];
  g_captureBlend[i]=t->BlendEnable;
  g_captureWriteMask[i]=t->RenderTargetWriteMask;
 }
}
static void capture_load_bounds(P ctx){
 if(g_captureBoundsLoaded)return;
 P depth=0,raster=0,blend=0;
 V(ctx,92,void(CALL*)(P,P*,U32*))(ctx,&depth,0);
 V(ctx,94,void(CALL*)(P,P*))(ctx,&raster);
 V(ctx,91,void(CALL*)(P,P*,float*,U32*))(ctx,&blend,0,0);
 capture_depth_state(depth);
 capture_raster_state(raster);
 capture_blend_state(blend);
 REL(depth);
 REL(raster);
 REL(blend);
 U32 nv=0,ns=0;
 V(ctx,95,void(CALL*)(P,U32*,VIEWPORT_*))(ctx,&nv,0);
 V(ctx,96,void(CALL*)(P,U32*,RECT_*))(ctx,&ns,0);
 if(nv==1)V(ctx,95,void(CALL*)(P,U32*,VIEWPORT_*))(ctx,&nv,&g_captureViewport);
 if(ns==1)V(ctx,96,void(CALL*)(P,U32*,RECT_*))(ctx,&ns,&g_captureScissor);
 g_captureViewportCount=nv;
 g_captureScissorCount=ns;
 g_captureBoundsLoaded=1;
}
static U32 capture_color_index(P resource,int add){
 if(!resource)return CAPTURE_INVALID;
 for(U32 i=0;i<g_captureColorCount;i++)
  if(g_captureColors[i].resource==resource)return i;
 if(!add)return CAPTURE_INVALID;
 if(g_captureColorCount==CAPTURE_COLORS){
  g_captureUnsafe=1;
  return CAPTURE_INVALID;
 }
 U32 index=g_captureColorCount++;
 V(resource,1,U32(CALL*)(P))(resource);
 g_captureColors[index].resource=resource;
 g_captureColors[index].sources=0;
 return index;
}
static void capture_bind_color(U32 slot,P view){
 CAPTURE_RTV_ *r=&g_captureRt[slot];
 if(view==r->view)return;
 REL(r->view);
 REL(r->resource);
 r->width=r->height=0;
 if(!view)return;
 V(view,1,U32(CALL*)(P))(view);
 r->view=view;
 CAPTURE_RTV_DESC_ vd={0};
 V(view,8,void(CALL*)(P,CAPTURE_RTV_DESC_*))(view,&vd);
 if(vd.dimension!=6 && (vd.dimension!=4 || vd.mip!=0))return;
 P resource=0,tex=0;
 V(view,7,void(CALL*)(P,P*))(view,&resource);
 if(resource && SUCCEEDED_(V(resource,0,HRESULT_(CALL*)(P,const GUID_*,P*))(resource,&IID_TEXTURE2D,&tex)) && tex){
  TEX2D_DESC d={0};
  V(tex,10,void(CALL*)(P,TEX2D_DESC*))(tex,&d);
  if(d.ArraySize==1 && capture_related_size(d.Width,d.Height)){
   r->resource=resource;
   resource=0;
   r->width=d.Width;
   r->height=d.Height;
  }
 }
 REL(tex);
 REL(resource);
}
static U32 capture_find_depth(P resource){
 for(U32 i=0;i<g_depthCount;i++)
  if(g_depthRecords[i].resourceKey==resource)return i;
 return CAPTURE_INVALID;
}
static U32 capture_record_depth(P view,CAPTURE_DSV_DESC_ *vd){
 if(!view)return CAPTURE_INVALID;
 V(view,8,void(CALL*)(P,CAPTURE_DSV_DESC_*))(view,vd);
 if(vd->dimension!=5 && (vd->dimension!=3 || vd->mip!=0))return CAPTURE_INVALID;
 P resource=0,tex=0;
 V(view,7,void(CALL*)(P,P*))(view,&resource);
 U32 index=capture_find_depth(resource);
 if(index==CAPTURE_INVALID && resource && g_depthCount<MAX_DEPTH_CANDIDATES &&
    SUCCEEDED_(V(resource,0,HRESULT_(CALL*)(P,const GUID_*,P*))(resource,&IID_TEXTURE2D,&tex)) && tex){
  TEX2D_DESC d={0};
  V(tex,10,void(CALL*)(P,TEX2D_DESC*))(tex,&d);
  if(capture_related_size(d.Width,d.Height) && d.ArraySize==1 && d.MipLevels==1 &&
     d.Usage==D3D11_USAGE_DEFAULT && capture_srv_format(d.Format) &&
     (d.SampleDesc.Count==1 || d.SampleDesc.Count==2 ||
      d.SampleDesc.Count==4 || d.SampleDesc.Count==8)){
   index=g_depthCount++;
   DEPTH_REC *r=&g_depthRecords[index];
   memset(r,0,sizeof(*r));
   r->resourceKey=resource;
   r->width=d.Width;
   r->height=d.Height;
   r->format=d.Format;
   r->bindFlags=d.BindFlags;
   r->msaa=d.SampleDesc.Count;
   r->sampleQuality=d.SampleDesc.Quality;
   r->lastDepthClearFrame=~0ull;
   g_depthTexture[index]=tex;
   tex=0;
  }
 }
 if(index<g_depthCount)g_depthRecords[index].latestViewKey=view;
 REL(tex);
 REL(resource);
 return index;
}
static int capture_eligible(const DEPTH_REC *r){
 return r->lastDepthClearFrame==g_frame && r->lastDrawFrame==g_frame &&
        r->lastWriteSerial>r->lastDepthClearSerial && r->sceneWrites &&
        !r->partialWrites && !r->epochRejected;
}
static U32 capture_snapshot_index(U32 candidate,U64 epoch){
 for(U32 i=0;i<CAPTURE_SNAPSHOTS;i++){
  const DEPTH_SNAPSHOT_ *s=&g_depthSnapshots[i];
  if(s->frame==g_frame && s->candidate==candidate && s->epoch==epoch)return i;
 }
 return CAPTURE_INVALID;
}
static int capture_requested(void){
 return g_ao || (g_menu && g_advancedMenu && g_aoDebug);
}
static void capture_consume(U32 sources){
 for(U32 i=0;i<CAPTURE_SNAPSHOTS;i++){
  if(sources&(1u<<i))g_depthSnapshots[i].consumed=1;
 }
}
static void capture_tag_outputs(const DEPTH_REC *r,U32 slot){
 for(U32 i=0;i<g_captureColorCount;i++){
  if(r->colorTargets&(1ull<<i))g_captureColors[i].sources|=1u<<slot;
 }
}
static int capture_copy_snapshot(P ctx,DEPTH_SNAPSHOT_ *s,U32 candidate){
 const DEPTH_REC *r=&g_depthRecords[candidate];
 const TEX2D_DESC *cached=&s->desc;
 if(!s->srv || cached->Width!=r->width || cached->Height!=r->height ||
    cached->Format!=r->format || cached->SampleDesc.Count!=r->msaa ||
    cached->SampleDesc.Quality!=r->sampleQuality){
  if(g_depthAllocationRetry && GetTickCount64()<g_depthAllocationRetry)return 0;
  REL(s->srv);
  REL(s->texture);
  TEX2D_DESC d={r->width,r->height,1,1,r->format,{r->msaa,r->sampleQuality},D3D11_USAGE_DEFAULT,BIND_SRV,0,0};
  HRESULT_ hr=dev_tex(g_device,&d,0,&s->texture);
  if(SUCCEEDED_(hr) && s->texture)
   hr=dev_depth_srv(g_device,s->texture,capture_srv_format(r->format),r->msaa,&s->srv);
  if(!SUCCEEDED_(hr) || !s->srv){
   REL(s->srv);
   REL(s->texture);
   if(!g_depthAllocationFailed)log_hex("AO SNAPSHOT CREATE FAILED",(U32)hr);
   g_depthAllocationFailed=1;
   g_depthAllocationRetry=GetTickCount64()+250;
   return 0;
  }
  s->desc=d;
  g_depthAllocationFailed=0;g_depthAllocationRetry=0;
 }
 /* Both resources are DEFAULT Texture2D with the identical sample
    descriptor and format. The destination has never been a game binding;
    it is unbound after the mod's previous Present. No depth resolve. */
 g_originalCopy(ctx,s->texture,g_depthTexture[candidate]);
 return 1;
}
/* WD2 also writes a full-size D32S8 depth image with a screen draw.
   The lineage path remains preferred; this route never ranks by draw count. */
static int capture_compat_shape(const DEPTH_REC *r){
 return r->width==g_width && r->height==g_height && r->format==19 &&
        r->msaa==1 && (r->bindFlags&BIND_SRV);
}
static int capture_compat_eligible(const DEPTH_REC *r){
 return capture_compat_shape(r) && !r->compatInvalid &&
        r->lastDepthClearFrame==g_frame && r->lastDrawFrame==g_frame &&
        r->compatWriteSerial>r->lastDepthClearSerial;
}
static void capture_compat_snapshot(P ctx,U32 candidate,U32 boundary){
 const DEPTH_REC *r=&g_depthRecords[candidate];
 if(!capture_requested() || g_captureOpaque || g_captureUncertain || g_compatConflict ||
    !capture_compat_eligible(r) ||
    (g_aoSourceChoice && candidate!=g_aoSourceChoice-1))return;
 DEPTH_SNAPSHOT_ *s=&g_compatDepth;
 if(s->srv && s->frame==g_frame){
  if(s->candidate!=candidate){g_compatConflict=1;return;}
  if(s->write==r->compatWriteSerial){
   if(boundary==DEPTH_BOUNDARY_MUTATION)s->boundary=boundary;
   return;
  }
 }
 if(!capture_copy_snapshot(ctx,s,candidate))return;
 s->frame=g_frame;
 s->epoch=r->lastDepthClearSerial;
 s->write=r->compatWriteSerial;
 s->candidate=candidate;
 s->boundary=boundary;
 s->clear=r->lastClearDepth;
}
static int capture_make_snapshot(P ctx,U32 candidate,U32 boundary){
 if(!capture_requested() || candidate>=g_depthCount)return 0;
 capture_compat_snapshot(ctx,candidate,boundary);
 if(g_captureUnsafe)return 0;
 const DEPTH_REC *r=&g_depthRecords[candidate];
 if(!capture_eligible(r))return 0;
 U32 slot=capture_snapshot_index(candidate,r->lastDepthClearSerial);
 if(slot<CAPTURE_SNAPSHOTS && g_depthSnapshots[slot].write==r->lastWriteSerial){
  capture_tag_outputs(r,slot);
  return 1;
 }
 if(slot<CAPTURE_SNAPSHOTS && g_depthSnapshots[slot].consumed){
  /* Earlier color already used this phase's previous contents. Replacing
     its snapshot now would silently relabel a different depth image. */
  g_captureUnsafe=1;
  return 0;
 }
 if(slot==CAPTURE_INVALID){
  for(U32 i=0;i<CAPTURE_SNAPSHOTS;i++){
   if(!g_depthSnapshots[i].srv || g_depthSnapshots[i].frame!=g_frame){slot=i;break;}
  }
 }
 if(slot==CAPTURE_INVALID){g_captureUnsafe=1;return 0;}
 DEPTH_SNAPSHOT_ *s=&g_depthSnapshots[slot];
 if(!capture_copy_snapshot(ctx,s,candidate)){g_captureUnsafe=1;return 0;}
 s->frame=g_frame;
 s->epoch=r->lastDepthClearSerial;
 s->write=r->lastWriteSerial;
 s->candidate=candidate;
 s->boundary=boundary;
 s->clear=r->lastClearDepth;
 s->consumed=0;
 capture_tag_outputs(r,slot);
 return 1;
}
static void capture_bind_outputs(P ctx,U32 count,P *views,P dsv){
 g_captureOutputsLoaded=1;
 U32 previous=g_depthActive;
 U32 wasWritable=g_captureWritable;
 if(dsv!=g_captureDsv){
  CAPTURE_DSV_DESC_ vd={0};
  g_depthActive=capture_record_depth(dsv,&vd);
  g_captureWritable=dsv && !(vd.flags&1u); /* D3D11_DSV_READ_ONLY_DEPTH */
  REL(g_captureDsv);
  if(dsv){
   V(dsv,1,U32(CALL*)(P))(dsv);
   g_captureDsv=dsv;
  }
 }
 if(previous<g_depthCount && (previous!=g_depthActive || (wasWritable && !g_captureWritable)))
  capture_make_snapshot(ctx,previous,DEPTH_BOUNDARY_UNBIND);
 if(g_depthActive<g_depthCount){
  DEPTH_REC *r=&g_depthRecords[g_depthActive];
  ++r->bindings;
  r->lastBindFrame=g_frame;
 }
 for(U32 i=0;i<8;i++)capture_bind_color(i,i<count && views?views[i]:0);
}
static void capture_load_outputs(P ctx){
 if(g_captureOutputsLoaded)return;
 P views[8]={0},dsv=0;
 V(ctx,89,void(CALL*)(P,U32,P*,P*))(ctx,8,views,&dsv);
 capture_bind_outputs(ctx,8,views,dsv);
 for(U32 i=0;i<8;i++)REL(views[i]);
 REL(dsv);
}
static void capture_note_ps_inputs(P ctx,U32 start,U32 count){
 if(start>=CAPTURE_INPUTS || !count || !capture_requested() ||
    !capture_observing(ctx) || !capture_enter())return;
 U32 n=CAPTURE_INPUTS-start;
 if(count<n)n=count;
 U32 bits=n==32?0xffffffffu:(1u<<n)-1;
 g_captureFreshInputs|=bits<<start;
 capture_leave();
}
static void capture_draw_color(P ctx,U32 fullscreen){
 if(!fullscreen || (g_captureDsv && g_captureDepthWrite && g_captureWritable))return;
 U32 destinations[8],count=0;
 for(U32 i=0;i<8;i++){
  const CAPTURE_RTV_ *r=&g_captureRt[i];
  if(r->resource && g_captureWriteMask[i] && capture_full_bounds(r->width,r->height))
   destinations[count++]=i;
 }
 if(!count)return;
 if(++g_capturePasses>CAPTURE_MAX_PASSES){g_captureUnsafe=1;return;}
 P srv[CAPTURE_INPUTS]={0};
 V(ctx,73,void(CALL*)(P,U32,U32,P*))(ctx,0,CAPTURE_INPUTS,srv);
 U32 sources=0;
 for(U32 i=0;i<CAPTURE_INPUTS;i++){
  if(!srv[i])continue;
  P resource=0;
  V(srv[i],7,void(CALL*)(P,P*))(srv[i],&resource);
  U32 index=capture_color_index(resource,0);
  U32 depth=capture_find_depth(resource);
  if((g_captureFreshInputs&(1u<<i)) && (index<CAPTURE_COLORS || depth<g_depthCount)){
   TEX_SRV_DESC_ desc={0};
   V(srv[i],8,void(CALL*)(P,TEX_SRV_DESC_*))(srv[i],&desc);
   if(desc.Dimension==6 || (desc.Dimension==4 && desc.MostDetailedMip==0)){
    if(index<CAPTURE_COLORS)sources|=g_captureColors[index].sources;
    if(depth<g_depthCount){
     const DEPTH_REC *d=&g_depthRecords[depth];
     U32 slot=capture_snapshot_index(depth,d->lastDepthClearSerial);
     if(slot<CAPTURE_SNAPSHOTS && capture_eligible(d) &&
        g_depthSnapshots[slot].write==d->lastWriteSerial)sources|=1u<<slot;
    }
   }
  }
  REL(resource);
  REL(srv[i]);
 }
 capture_consume(sources);
 for(U32 i=0;i<count;i++){
  U32 target=destinations[i];
  U32 dst=capture_color_index(g_captureRt[target].resource,sources!=0);
  if(dst>=CAPTURE_COLORS)continue;
  if(!g_captureBlend[target] && (g_captureWriteMask[target]&7u)==7u &&
     (!g_captureDsv || !g_captureDepthEnabled)){
   g_captureColors[dst].sources=0;
   for(U32 j=0;j<g_depthCount;j++)g_depthRecords[j].colorTargets&=~(1ull<<dst);
  }
  g_captureColors[dst].sources|=sources;
 }
}
static void capture_observe_draw(P ctx,U32 geometry,U32 fullscreen){
 if(!capture_enter())return;
 capture_load_outputs(ctx);
 capture_load_bounds(ctx);
 if(g_depthActive<g_depthCount){
  DEPTH_REC *r=&g_depthRecords[g_depthActive];
  ++r->draws;
  r->lastDrawFrame=g_frame;
  r->lastDrawSerial=++g_depthSerial;
  ++r->drawsSinceClear;
  int full=capture_full_bounds(r->width,r->height);
  if(full)++r->fullViewportDraws;
  else ++r->partialViewportDraws;
  if(r->lastDepthClearFrame==g_frame && g_captureWritable &&
     g_captureDepthWrite && (geometry||fullscreen)){
   if(capture_compat_shape(r) && g_captureComparison>1){
    if(!full){r->compatInvalid|=COMPAT_PARTIAL;r->compatSeenReasons|=COMPAT_PARTIAL;}
    else if(g_captureComparison==6 || g_captureComparison==8 ||
            (r->lastClearDepth<0.5f && (g_captureComparison==5 || g_captureComparison==7)) ||
            (r->lastClearDepth>=0.5f && (g_captureComparison==2 || g_captureComparison==4))){
     /* A screen overwrite reinitializes a discarded phase. Ordinary draws
        can resume after a copy, whose destination contents remain defined. */
     r->compatInvalid&=~COMPAT_TRANSFER;
     if(fullscreen && !geometry && g_captureComparison==8)
      r->compatInvalid&=~(COMPAT_DISCARD|COMPAT_PARTIAL);
     r->compatWriteSerial=r->lastDrawSerial;
    }
   }
   /* Clear/horizon and write-draw depth comparison must agree. Stage
      changes to ALWAYS are treated as unrelated overwrites. */
   U32 func=g_captureComparison;
   int expected=r->lastClearDepth<0.5f?(func==5||func==7):(func==2||func==4);
   if(!expected && func!=1 && func!=3)r->epochRejected=1;
   if(expected){
    r->lastWriteSerial=r->lastDrawSerial;
    if(!full)++r->partialWrites;
    else if(geometry){
     ++r->sceneWrites;
     if(capture_requested())camera_observe_draw(ctx,g_depthTexture[g_depthActive],g_frame,
                    r->lastDepthClearSerial,r->width,r->height,r->lastClearDepth,r->sceneWrites);
    }
   }
  }
  if(geometry && full && r->lastDepthClearFrame==g_frame && r->sceneWrites){
   for(U32 i=0;i<8;i++){
    const CAPTURE_RTV_ *c=&g_captureRt[i];
    if(c->width!=r->width || c->height!=r->height || !c->resource || !g_captureWriteMask[i])continue;
    U32 target=capture_color_index(c->resource,1);
    if(target<CAPTURE_COLORS)r->colorTargets|=1ull<<target;
   }
   U32 slot=capture_snapshot_index(g_depthActive,r->lastDepthClearSerial);
   if(slot<CAPTURE_SNAPSHOTS && capture_eligible(r) &&
      g_depthSnapshots[slot].write==r->lastWriteSerial)capture_tag_outputs(r,slot);
  }
 }
 if(capture_requested() && fullscreen)capture_draw_color(ctx,fullscreen);
 if(geometry || fullscreen)g_captureFreshInputs=0;
 capture_leave();
}
static void capture_depth_at_present(void){
 if(!g_ctx || !capture_requested() || (!g_depthEnabled && !g_depthDone) ||
    !g_depthHookSessionReady || !capture_enter())return;
 capture_make_snapshot(g_ctx,g_depthActive,DEPTH_BOUNDARY_PRESENT);
 capture_leave();
}
static U32 capture_unique(U32 mask){
 U32 slot=CAPTURE_INVALID;
 for(U32 i=0;i<CAPTURE_SNAPSHOTS;i++){
  if(!(mask&(1u<<i)))continue;
  if(slot!=CAPTURE_INVALID)return CAPTURE_INVALID;
  slot=i;
 }
 return slot;
}
static U32 capture_backbuffer_color(void){
 U32 direct=capture_color_index(g_back,0);
 if(direct<CAPTURE_COLORS || !g_captureColorCount)return direct;
 /* GetBuffer returned ID3D11Texture2D; the view returns ID3D11Resource.
    Some runtimes use distinct interface pointers for the same object. */
 static const GUID_ iidIUnknown={0,0,0,{0xc0,0,0,0,0,0,0,0x46}};
 P backIdentity=0;
 if(!SUCCEEDED_(V(g_back,0,HRESULT_(CALL*)(P,const GUID_*,P*))(g_back,&iidIUnknown,&backIdentity)) ||
    !backIdentity)return CAPTURE_INVALID;
 U32 result=CAPTURE_INVALID;
 for(U32 i=0;i<g_captureColorCount;i++){
  P identity=0,resource=g_captureColors[i].resource;
  if(!g_captureColors[i].sources)continue;
  V(resource,0,HRESULT_(CALL*)(P,const GUID_*,P*))(resource,&iidIUnknown,&identity);
  if(identity==backIdentity)result=i;
  REL(identity);
  if(result<CAPTURE_COLORS)break;
 }
 REL(backIdentity);
 return result;
}
static int capture_compat_ready(void){
 const DEPTH_SNAPSHOT_ *s=&g_compatDepth;
 if(g_compatConflict || !s->srv || s->frame!=g_frame || s->candidate>=g_depthCount ||
    (g_aoSourceChoice && s->candidate!=g_aoSourceChoice-1))return 0;
 const DEPTH_REC *r=&g_depthRecords[s->candidate];
 /* A snapshot taken at a phase boundary survives its subsequent clear.
    Writes within the same epoch must match the snapshot we would present. */
 return r->lastDepthClearSerial!=s->epoch ||
        (s->boundary==DEPTH_BOUNDARY_MUTATION && r->compatMutationSerial>s->write &&
         r->compatWriteSerial==s->write) ||
        (!r->compatInvalid && r->compatWriteSerial==s->write);
}
static int setup_ao_depth_input(void){
 capture_release_selected();
 g_aoDepthStatus=DEPTH_WAITING;
 g_aoDepthReason="WAITING FOR DEPTH OBSERVER";
 if(!g_ctx || !g_back || !g_depthHookSessionReady || g_captureFrame!=g_frame)return 0;
 if(g_captureOpaque || g_captureUncertain || !g_depthHooked || g_hookLossObserved ||
    *(P**)g_ctx!=g_depthPatchedTable){
  g_aoDepthStatus=DEPTH_UNSAFE;
  g_aoDepthReason="DEPTH OBSERVER STATE UNSAFE";
  return 0;
 }
 U32 mask=0;
 for(U32 i=0;i<CAPTURE_SNAPSHOTS;i++){
  const DEPTH_SNAPSHOT_ *s=&g_depthSnapshots[i];
  if(s->frame!=g_frame || !s->srv)continue;
  if(g_aoSourceChoice && s->candidate!=g_aoSourceChoice-1)continue;
  mask|=1u<<i;
 }
 U32 back=mask&&!g_captureUnsafe?capture_backbuffer_color():CAPTURE_INVALID;
 U32 linked=back<CAPTURE_COLORS?g_captureColors[back].sources:0;
 /* A direct scene draw or an observed depth/color dependency must reach
    the actual presenting target. Manual selection cannot override this. */
 U32 proven=capture_unique(mask&linked);
 const DEPTH_SNAPSHOT_ *s=0;
 if(proven<CAPTURE_SNAPSHOTS){
  s=&g_depthSnapshots[proven];
  g_aoDepthStatus=DEPTH_READY;
 }else if(capture_compat_ready()){
  s=&g_compatDepth;
  g_aoDepthStatus=DEPTH_COMPATIBLE;
 }else if(mask || g_compatConflict || g_captureUnsafe){
  U32 slot=g_captureUnsafe?CAPTURE_INVALID:capture_unique(mask);
  g_aoDepthStatus=DEPTH_UNSAFE;
  if(slot<CAPTURE_SNAPSHOTS)s=&g_depthSnapshots[slot];
 }
 if(!s){
  if(g_depthAllocationFailed)g_aoDepthReason="SNAPSHOT ALLOCATION FAILED";
  else if(g_compatConflict)g_aoDepthReason="AMBIGUOUS SCENE DEPTH";
  else if(g_captureUnsafe)g_aoDepthReason="DEPTH LINEAGE INCOMPLETE";
  else {
   g_aoDepthReason=g_depthCount?"NO CURRENT SCENE SNAPSHOT":"DISCOVERING DEPTH FORMATS";
   for(U32 i=0;i<g_depthCount;i++){
    const DEPTH_REC *r=&g_depthRecords[i];
    if(!capture_compat_shape(r) || r->lastDepthClearFrame!=g_frame)continue;
    if(r->compatInvalid&COMPAT_CLEAR_RANGE)g_aoDepthReason="CLEAR OUTSIDE CAMERA RANGE";
    else if(r->compatInvalid&COMPAT_DISCARD)g_aoDepthReason="DEPTH DISCARDED BEFORE CAPTURE";
    else if(r->compatInvalid&COMPAT_TRANSFER)g_aoDepthReason="DEPTH REPLACED BEFORE CAPTURE";
    else if(r->compatInvalid&COMPAT_PARTIAL)g_aoDepthReason="PARTIAL DEPTH WRITES";
    else if(!r->compatWriteSerial)g_aoDepthReason="WAITING FOR SCENE DEPTH WRITES";
   }
  }
  return 0;
 }
 if(g_aoDepthStatus==DEPTH_UNSAFE)g_aoDepthReason="SNAPSHOT COLOR LINK UNCONFIRMED";
 g_aoDepthSrv=s->srv;
 V(g_aoDepthSrv,1,U32(CALL*)(P))(g_aoDepthSrv);
 g_aoDepthIndex=s->candidate;
 g_aoDepthFrame=s->frame;
 g_aoDepthEpoch=s->epoch;
 g_aoDepthClear=s->clear;
 g_aoDepthBoundary=s->boundary;
 if(g_aoDepthIndex!=g_lastDepthSelection || g_aoDepthStatus!=g_lastDepthStatus){
  g_lastDepthSelection=g_aoDepthIndex;
  g_lastDepthStatus=g_aoDepthStatus;
  if(g_aoDepthStatus==DEPTH_COMPATIBLE)
   log_msg("AO DEPTH: WD2 SAME-FRAME COMPATIBILITY SNAPSHOT\r\n");
  log_hex("AO DEPTH SNAPSHOT CANDIDATE",g_aoDepthIndex);
  log_hex("AO DEPTH SNAPSHOT BOUNDARY (1 UNBIND, 2 CLEAR, 3 PRESENT, 4 MUTATION)",g_aoDepthBoundary);
  const DEPTH_REC *selected=&g_depthRecords[s->candidate];
  U32 clearBits=0;memcpy(&clearBits,&s->clear,sizeof(clearBits));
  log_hex("AO DEPTH FORMAT",selected->format);
  log_hex("AO DEPTH WIDTH",selected->width);log_hex("AO DEPTH HEIGHT",selected->height);
  log_hex("AO SNAPSHOT FRAME",(U32)s->frame);log_hex("AO SNAPSHOT EPOCH",(U32)s->epoch);
  log_hex("AO SNAPSHOT CLEAR FLOAT BITS",clearBits);
  if(g_aoDepthStatus!=DEPTH_UNSAFE && !g_depthSnapshotLogged){
   log_msg("AO SCENE SNAPSHOT AVAILABLE\r\n");
   g_depthSnapshotLogged=1;
  }
 }
 return 1;
}
static int depth_source_live(void){
 return (g_aoDepthStatus==DEPTH_READY || g_aoDepthStatus==DEPTH_COMPATIBLE) &&
        g_aoDepthSrv && g_aoDepthFrame==g_frame;
}
static void CALL depth_set_viewports(P ctx,U32 count,const VIEWPORT_ *v){
 g_originalSetViewports(ctx,count,v);
 if(!capture_observing(ctx) || !capture_enter())return;
 g_captureViewportCount=count;
 if(count==1 && v)g_captureViewport=*v;
 capture_leave();
}
static void CALL capture_set_scissors(P ctx,U32 count,const RECT_ *rects){
 g_originalSetScissors(ctx,count,rects);
 if(!capture_observing(ctx) || !capture_enter())return;
 g_captureScissorCount=count;
 if(count==1 && rects)g_captureScissor=*rects;
 capture_leave();
}
static void CALL capture_set_raster(P ctx,P state){
 g_originalSetRaster(ctx,state);
 if(!capture_observing(ctx) || !capture_enter())return;
 capture_raster_state(state);
 capture_leave();
}
static void CALL capture_set_depth(P ctx,P state,U32 stencil){
 g_originalSetDepth(ctx,state,stencil);
 if(!capture_observing(ctx) || !capture_enter())return;
 capture_depth_state(state);
 capture_leave();
}
static void CALL capture_set_blend(P ctx,P state,const float *factors,U32 mask){
 g_originalSetBlend(ctx,state,factors,mask);
 if(!capture_observing(ctx) || !capture_enter())return;
 capture_blend_state(state);
 capture_leave();
}
static void capture_observe_om(P ctx,U32 count,P *views,P dsv){
 if(g_depthEnabled && !g_depthDone){
  __sync_fetch_and_add(&g_rawOMCalls,1);
  if(ctx!=g_ctx)__sync_fetch_and_add(&g_foreignOMCalls,1);
  else if(g_presentBusy)__sync_fetch_and_add(&g_presentOMCalls,1);
 }
 if(!capture_observing(ctx) || !capture_enter())return;
 capture_bind_outputs(ctx,count,views,dsv);
 capture_leave();
}
static void CALL depth_om(P ctx,U32 n,P *views,P dsv){
 g_originalOM(ctx,n,views,dsv);
 capture_observe_om(ctx,n,views,dsv);
}
static void CALL depth_omuav(P ctx,U32 n,P *views,P dsv,U32 start,U32 count,P *uavs,const U32 *initial){
 g_originalOMUAV(ctx,n,views,dsv,start,count,uavs,initial);
 if(n!=KEEP_RTV_DSV)capture_observe_om(ctx,n,views,dsv);
}
static void CALL depth_clear(P ctx,P view,U32 flags,float z,U8 stencil){
 if(capture_observing(ctx) && (flags&1u) && capture_enter()){
  CAPTURE_DSV_DESC_ vd={0};
  U32 i=capture_record_depth(view,&vd);
  if(i<g_depthCount && !(vd.flags&1u)){
   DEPTH_REC *r=&g_depthRecords[i];
   capture_make_snapshot(ctx,i,DEPTH_BOUNDARY_CLEAR);
   r->lastClearFrame=r->lastDepthClearFrame=g_frame;
   r->lastClearSerial=r->lastDepthClearSerial=++g_depthSerial;
   r->lastClearFlags=flags;
   r->lastClearDepth=z;
   ++r->clearCount;
   r->drawsSinceClear=r->sceneWrites=r->partialWrites=0;
   r->epochRejected=!(z==0.0f || z==1.0f);
   r->compatInvalid=projection_wd2_clear_in_range(z)?0:COMPAT_CLEAR_RANGE;
   r->compatMutationSerial=0;
   r->compatSeenReasons=r->compatInvalid;
   r->compatWriteSerial=0;
   r->colorTargets=0;
  }
  capture_leave();
 }
 g_originalClearDepth(ctx,view,flags,z,stencil);
}
static void CALL capture_clear_target(P ctx,P view,const float *rgba){
 g_originalClearRT(ctx,view,rgba);
 if(!view || !capture_observing(ctx) || !capture_enter())return;
 P resource=0;
 V(view,7,void(CALL*)(P,P*))(view,&resource);
 U32 i=capture_color_index(resource,0);
 if(i<CAPTURE_COLORS){
  g_captureColors[i].sources=0;
  for(U32 j=0;j<g_depthCount;j++)g_depthRecords[j].colorTargets&=~(1ull<<i);
 }
 REL(resource);
 capture_leave();
}
/* Record changes before submitting them. The snapshot has its own resource,
   so later commands against the game's DSV cannot change the captured bytes. */
static void capture_before_depth_change(P ctx,P resource,U32 reason){
 if(!resource || !capture_observing(ctx) || !capture_enter())return;
 U32 i=capture_find_depth(resource);
 if(i<g_depthCount){
  DEPTH_REC *r=&g_depthRecords[i];
  if(capture_compat_shape(r)){
   capture_compat_snapshot(ctx,i,DEPTH_BOUNDARY_MUTATION);
   r->compatInvalid|=reason;
   r->compatSeenReasons|=reason;
   r->compatMutationSerial=++g_depthSerial;
  }
  r->epochRejected=1;
 }
 capture_leave();
}
static void capture_transfer(P ctx,P dst,P src,int entire){
 if(!capture_observing(ctx) || !capture_enter())return;
 U32 depth=capture_find_depth(dst);
 if(depth<g_depthCount)g_depthRecords[depth].epochRejected=1;
 U32 source=capture_color_index(src,0);
 U32 mask=source<CAPTURE_COLORS?g_captureColors[source].sources:0;
 if(entire)capture_consume(mask);
 U32 target=capture_color_index(dst,mask!=0);
 if(target<CAPTURE_COLORS){
  g_captureColors[target].sources=entire?mask:0;
  for(U32 i=0;i<g_depthCount;i++)g_depthRecords[i].colorTargets&=~(1ull<<target);
 }
 capture_leave();
}
static void CALL capture_copy(P ctx,P dst,P src){
 capture_before_depth_change(ctx,dst,COMPAT_TRANSFER);
 g_originalCopy(ctx,dst,src);
 capture_transfer(ctx,dst,src,1);
}
static void CALL capture_resolve(P ctx,P dst,U32 di,P src,U32 si,U32 format){
 if(di==0)capture_before_depth_change(ctx,dst,COMPAT_TRANSFER);
 g_originalResolve(ctx,dst,di,src,si,format);
 if(di==0)capture_transfer(ctx,dst,src,si==0);
}
static void CALL capture_copy_region(P ctx,P dst,U32 di,U32 x,U32 y,U32 z,P src,U32 si,const CAPTURE_BOX_ *box){
 if(di==0)capture_before_depth_change(ctx,dst,COMPAT_TRANSFER);
 g_originalCopyRegion(ctx,dst,di,x,y,z,src,si,box);
 if(di==0)capture_transfer(ctx,dst,src,!box && !si && !x && !y && !z);
}
static void capture_opaque_commands(void){
 if(!capture_enter())return;
 g_captureUnsafe=g_captureOpaque=1;
 capture_release_bindings();
 capture_leave();
}
static void CALL capture_clear_state(P ctx){
 g_originalClearState(ctx);
 if(capture_observing(ctx) && capture_enter()){
  capture_make_snapshot(ctx,g_depthActive,DEPTH_BOUNDARY_UNBIND);
  capture_release_bindings();
  capture_leave();
 }
}
static void capture_before_depth_view_change(P ctx,P view){
 if(!view || !capture_observing(ctx))return;
 P resource=0;
 V(view,7,void(CALL*)(P,P*))(view,&resource);
 capture_before_depth_change(ctx,resource,COMPAT_DISCARD);
 REL(resource);
}
static void capture_invalidate_view(P ctx,P view){
 if(!view || !capture_observing(ctx))return;
 P resource=0;
 V(view,7,void(CALL*)(P,P*))(view,&resource);
 if(resource)capture_transfer(ctx,resource,0,0);
 REL(resource);
}
static void CALL capture_copy_region1(P ctx,P dst,U32 di,U32 x,U32 y,U32 z,P src,U32 si,const CAPTURE_BOX_ *box,U32 flags){
 if(di==0)capture_before_depth_change(ctx,dst,COMPAT_TRANSFER);
 g_originalCopyRegion1(ctx,dst,di,x,y,z,src,si,box,flags);
 if(di==0)capture_transfer(ctx,dst,src,!box && !si && !x && !y && !z);
}
static void CALL capture_discard_resource(P ctx,P resource){
 capture_before_depth_change(ctx,resource,COMPAT_DISCARD);
 g_originalDiscardResource(ctx,resource);
 if(resource)capture_transfer(ctx,resource,0,0);
}
static void CALL capture_discard_view(P ctx,P view){
 capture_before_depth_view_change(ctx,view);
 g_originalDiscardView(ctx,view);
 capture_invalidate_view(ctx,view);
}
static void CALL capture_swap_state(P ctx,P state,P *previous){
 g_originalSwapState(ctx,state,previous);
 if(capture_observing(ctx))capture_opaque_commands();
}
static void CALL capture_clear_view(P ctx,P view,const float *values,const RECT_ *rects,U32 count){
 capture_before_depth_view_change(ctx,view);
 g_originalClearView(ctx,view,values,rects,count);
 capture_invalidate_view(ctx,view);
}
static void CALL capture_discard_view1(P ctx,P view,const RECT_ *rects,U32 count){
 capture_before_depth_view_change(ctx,view);
 g_originalDiscardView1(ctx,view,rects,count);
 capture_invalidate_view(ctx,view);
}
static int capture_attach_hooks(P *shared,P *private,U32 slots){
 const U32 required[]={8,12,13,20,21,33,34,35,36,38,39,40,43,44,45,46,47,50,53,57,58,110};
 for(U32 i=0;i<sizeof(required)/sizeof(required[0]);i++){
  if(!shared[required[i]])return 0;
 }
 g_originalOM=(void*)shared[33];private[33]=(P)depth_om;
 g_originalOMUAV=(void*)shared[34];private[34]=(P)depth_omuav;
 g_originalSetBlend=(void*)shared[35];private[35]=(P)capture_set_blend;
 g_originalSetDepth=(void*)shared[36];private[36]=(P)capture_set_depth;
 g_originalSetRaster=(void*)shared[43];private[43]=(P)capture_set_raster;
 g_originalSetViewports=(void*)shared[44];private[44]=(P)depth_set_viewports;
 g_originalSetScissors=(void*)shared[45];private[45]=(P)capture_set_scissors;
 g_originalCopyRegion=(void*)shared[46];private[46]=(P)capture_copy_region;
 g_originalCopy=(void*)shared[47];private[47]=(P)capture_copy;
 g_originalClearRT=(void*)shared[50];private[50]=(P)capture_clear_target;
 g_originalClearDepth=(void*)shared[53];private[53]=(P)depth_clear;
 g_originalResolve=(void*)shared[57];private[57]=(P)capture_resolve;
 g_originalClearState=(void*)shared[110];private[110]=(P)capture_clear_state;
 if(slots>=134){
  const U32 required1[]={115,117,118,131,132,133};
  for(U32 i=0;i<sizeof(required1)/sizeof(required1[0]);i++){
   if(!shared[required1[i]])return 0;
  }
  g_originalCopyRegion1=(void*)shared[115];private[115]=(P)capture_copy_region1;
  g_originalDiscardResource=(void*)shared[117];private[117]=(P)capture_discard_resource;
  g_originalDiscardView=(void*)shared[118];private[118]=(P)capture_discard_view;
  g_originalSwapState=(void*)shared[131];private[131]=(P)capture_swap_state;
  g_originalClearView=(void*)shared[132];private[132]=(P)capture_clear_view;
  g_originalDiscardView1=(void*)shared[133];private[133]=(P)capture_discard_view1;
 }
 return 1;
}
