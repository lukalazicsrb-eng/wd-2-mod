/* WD2 Enhanced 0.37. Native DX11 post-processing and DirectInput forwarding
   for offline single-player. Minimal Win32 declarations allow a freestanding build. */
#define API __declspec(dllimport)
#define CALL __stdcall
#define STDCALL __stdcall
#define EX __declspec(dllexport)
typedef unsigned char U8;
typedef unsigned short WCHAR;
typedef unsigned int U32;
typedef int I32;
typedef unsigned long long U64;
typedef long HRESULT_;
typedef void* P;
typedef U32 BOOL_;
typedef unsigned long long SIZE_T_;
typedef struct {U32 d1;unsigned short d2,d3;U8 d4[8];} GUID_;
typedef struct {U32 numerator,denominator;} RATIONAL_;
typedef struct {U32 Count,Quality;} SAMPLE_;
typedef struct {U32 Width,Height;RATIONAL_ RefreshRate;U32 Format,ScanlineOrdering,Scaling;} MODE_;
typedef struct {MODE_ BufferDesc;SAMPLE_ SampleDesc;U32 BufferUsage,BufferCount;P OutputWindow;I32 Windowed;U32 SwapEffect,Flags;} SWAP_DESC;
typedef struct {U32 Width,Height,MipLevels,ArraySize,Format; SAMPLE_ SampleDesc;U32 Usage,BindFlags,CPUAccessFlags,MiscFlags;} TEX2D_DESC;
typedef char assert_swap_desc_size[sizeof(SWAP_DESC)==72?1:-1];
typedef char assert_tex_desc_size[sizeof(TEX2D_DESC)==44?1:-1];
typedef struct {U32 ByteWidth,Usage,BindFlags,CPUAccessFlags,MiscFlags,StructureByteStride;} BUFFER_DESC;
typedef struct {const void* pSysMem;U32 SysMemPitch,SysMemSlicePitch;} SUB_DATA;
typedef struct {U32 Filter,AddressU,AddressV,AddressW;float MipLODBias;U32 MaxAnisotropy,ComparisonFunc;float BorderColor[4],MinLOD,MaxLOD;} SAMPLER_DESC;
typedef struct {float TopLeftX,TopLeftY,Width,Height,MinDepth,MaxDepth;} VIEWPORT_;
/* ID3D11ShaderResourceViewDesc: DXGI_FORMAT, D3D11_SRV_DIMENSION_TEXTURE2D=4,
   followed by a 16-byte union (Texture2D.MostDetailedMip, Texture2D.MipLevels).
   RTV descriptor likewise contains Format, D3D11_RTV_DIMENSION_TEXTURE2D=4,
   then a 12-byte union whose first DWORD is Texture2D.MipSlice. */
typedef struct {U32 Format,Dimension,MostDetailedMip,MipLevels,UnusedA,UnusedB;} TEX_SRV_DESC_;
typedef struct {U32 Format,Dimension,MipSlice,UnusedA,UnusedB;} TEX_RTV_DESC_;
typedef char assert_srv_desc_size[sizeof(TEX_SRV_DESC_)==24?1:-1];
typedef char assert_rtv_desc_size[sizeof(TEX_RTV_DESC_)==20?1:-1];
typedef struct {U32 BlendEnable,SrcBlend,DestBlend,BlendOp,SrcBlendAlpha,DestBlendAlpha,BlendOpAlpha;U8 RenderTargetWriteMask;U8 padding[3];} TARGET_BLEND_;
typedef struct {U32 AlphaToCoverageEnable,IndependentBlendEnable;TARGET_BLEND_ Target[8];} BLEND_DESC_;
typedef char assert_blend_desc_size[sizeof(BLEND_DESC_)==264?1:-1];

typedef struct {I32 left,top,right,bottom;} RECT_;
typedef struct {P hwnd;U32 flags;} DUMMY;
typedef struct {P Ptr;} INIT_ONCE_;
#define WINAPI CALL
#define V(obj,i,t) ((t)((*(void***)(obj))[i]))
#define REL(p) do {if(p){V(p,2,U32(CALL*)(P))(p);(p)=0;}}while(0)
#define SUCCEEDED_(x) (((I32)(x))>=0)
#define VK_TAB 0x09
#define VK_F8 0x77
#define VK_F9 0x78
#define VK_F10 0x79
#define VK_F11 0x7A
#define VK_F12 0x7B
#define VK_UP 0x26
#define VK_DOWN 0x28
#define VK_LEFT 0x25
#define VK_RIGHT 0x27
#define VK_RETURN 0x0D
#define GENERIC_WRITE_ 0x40000000u
#define OPEN_ALWAYS_ 4
#define FILE_END_ 2
#define MAX_CLASSES 32
#define MAX_DEPTH_CANDIDATES 24
#define MAX_RG_CANDIDATES 16
#define MENU_W 600
#define MENU_H 930
#define WINDOW_STYLE_POPUP 0x80000000u
#define BIND_RTV 0x20
#define BIND_SRV 0x8
#define D3D11_USAGE_DEFAULT 0
#define D3D11_SDK_VERSION 7
#define D3D11_DRIVER_HARDWARE 1
#define D3D11_DRIVER_WARP 5
#define DXGI_FORMAT_RGBA8 28
#define DXGI_FORMAT_RGBA16F 10
#define DXGI_FORMAT_RGBA32F 2
#define DXGI_FORMAT_BGRA8 87
#define D3D11_FILTER_MIN_MAG_MIP_LINEAR 0x15
#define D3D11_TEXTURE_ADDRESS_CLAMP 3
#define D3D11_COMPARISON_NEVER 1
#define TRIANGLELIST 4

extern API P CALL LoadLibraryW(const WCHAR*);
extern API P CALL GetModuleHandleW(const WCHAR*);
extern API BOOL_ CALL GetModuleHandleExW(U32,const WCHAR*,P*);
extern API P CALL GetProcAddress(P,const char*);
extern API U32 CALL GetSystemDirectoryW(WCHAR*,U32);
extern API U32 CALL GetModuleFileNameW(P,WCHAR*,U32);
extern API P CALL CreateFileW(const WCHAR*,U32,U32,P,U32,U32,P);
extern API U32 CALL WriteFile(P,const void*,U32,U32*,P);
extern API U32 CALL CloseHandle(P);
extern API U32 CALL DisableThreadLibraryCalls(P);
extern API BOOL_ CALL InitOnceExecuteOnce(INIT_ONCE_*,BOOL_ (CALL*)(INIT_ONCE_*,void*,void**),void*,void**);
extern API P CALL CreateThread(P,SIZE_T_,U32(CALL*)(P),P,U32,U32*);
extern API void CALL Sleep(U32);
extern API U32 CALL GetCurrentProcessId(void);
extern API U64 CALL GetTickCount64(void);
extern API U32 CALL VirtualProtect(P,SIZE_T_,U32,U32*);
extern API P CALL GetForegroundWindow(void);
extern API short CALL GetAsyncKeyState(I32);
extern API P CALL CreateWindowExW(U32,const WCHAR*,const WCHAR*,U32,I32,I32,I32,I32,P,P,P,P);
extern API U32 CALL DestroyWindow(P);
extern API P CALL GetAncestor(P,U32);
extern API U32 CALL IsWindow(P);
extern API U32 CALL SetFilePointer(P,I32,I32*,U32);
extern API U32 CALL GetPrivateProfileIntW(const WCHAR*,const WCHAR*,I32,const WCHAR*);
extern API U32 CALL WritePrivateProfileStringW(const WCHAR*,const WCHAR*,const WCHAR*,const WCHAR*);
extern API void CALL OutputDebugStringA(const char*);

static const GUID_ IID_D3D11_DEVICE={0xdb6f6ddb,0xac77,0x4e88,{0x82,0x53,0x81,0x9d,0xf9,0xbb,0xf1,0x40}};
static const GUID_ IID_TEXTURE2D={0x6f15aaf2,0xd208,0x4e89,{0x9a,0xb4,0x48,0x95,0x35,0xd3,0x4f,0x9c}};
static const WCHAR kSystemDll[]={'\\','d','i','n','p','u','t','8','.','d','l','l',0};
static const WCHAR kLogName[]={'W','D','2','E','n','h','a','n','c','e','d','_','0','_','3','8','.','l','o','g',0};
static const WCHAR kConfigName[]={'W','D','2','E','n','h','a','n','c','e','d','.','i','n','i',0};
static const WCHAR kCore[]={'G','r','a','p','h','i','c','s',0};
static const WCHAR kFxKey[]={'E','f','f','e','c','t','E','n','a','b','l','e','d',0};
static const WCHAR kSharpKey[]={'S','h','a','r','p','e','n',0};
static const WCHAR kSatKey[]={'S','a','t','u','r','a','t','i','o','n',0};
static const WCHAR kContrastKey[]={'C','o','n','t','r','a','s','t',0};
static const WCHAR kBrightKey[]={'B','r','i','g','h','t','n','e','s','s',0};
static const WCHAR kGammaKey[]={'G','a','m','m','a',0};
static const WCHAR kAOSection[]={'A','O','P','r','o','t','o','t','y','p','e',0};
static const WCHAR kAOEnable[]={'E','n','a','b','l','e','d',0};
static const WCHAR kAOStrength[]={'S','t','r','e','n','g','t','h',0};
static const WCHAR kAORadius[]={'R','a','d','i','u','s','P','x',0};
static const WCHAR kAOQuality[]={'Q','u','a','l','i','t','y',0};
static const WCHAR kAOPreset[]={'P','r','e','s','e','t',0};
static const WCHAR kAOContactBoost[]={'C','o','n','t','a','c','t','B','o','o','s','t',0};
static const WCHAR kAOEdgeGuard[]={'E','d','g','e','G','u','a','r','d',0};
static const WCHAR kAOHudGuard[]={'H','u','d','G','u','a','r','d',0};
static const WCHAR kAOSource[]={'D','e','p','t','h','S','o','u','r','c','e',0};
static const WCHAR kDiag[]={'D','i','a','g','n','o','s','t','i','c','s',0};
static const WCHAR kHookKey[]={'H','o','o','k','E','n','a','b','l','e','d',0};
static const WCHAR kDelayKey[]={'S','t','a','r','t','u','p','D','e','l','a','y','M','s',0};
static const WCHAR kFramesKey[]={'P','a','s','s','t','h','r','o','u','g','h','F','r','a','m','e','s',0};
static const WCHAR kPreviewModeKey[]={'P','r','e','v','i','e','w','M','o','d','e',0};
static const WCHAR kPreviewCenterKey[]={'P','r','e','v','i','e','w','C','e','n','t','e','r',0};
static const WCHAR kPreviewWidthKey[]={'P','r','e','v','i','e','w','W','i','d','t','h',0};
static const WCHAR kPreviewFovKey[]={'P','r','e','v','i','e','w','F','o','v',0};
static const WCHAR kD3D11Dll[]={'d','3','d','1','1','.','d','l','l',0};
static const WCHAR kCompilerDll[]={'d','3','d','c','o','m','p','i','l','e','r','_','4','7','.','d','l','l',0};
static const WCHAR kStatic[]={'S','T','A','T','I','C',0};
static const WCHAR kBlank[]={0};
static P g_self, g_system, g_d3d11, g_compiler;
static INIT_ONCE_ g_once={0};
static WCHAR g_logPath[520],g_iniPath[520];
static volatile I32 g_started=0, g_hooked=0, g_seen=0, g_firstPresent=0, g_firstReturned=0, g_resizeHooked=0;
static U64 g_frame=0;
static U32 g_probeDelayMs=30000, g_passthroughFrames=120;
static U32 g_hookEnabled=1;
static U32 g_menu=0,g_fx=0,g_selected=0,g_advancedMenu=0, g_input[11]={0};
static U32 g_ao=1,g_aoDebug=0,g_aoQuality=2,g_aoSourceChoice=0,g_aoHudGuard=1,g_aoEdgeGuard=1;
static I32 g_aoStrength=38,g_aoRadius=14,g_aoContactBoost=15;
static U32 g_aoPreset=1; /* 0 natural, 1 balanced, 2 strong, 3 custom */
enum AO_STATE {
 AO_OFF, AO_REQUESTED, AO_WAITING_DEPTH, AO_WAITING_CAMERA,
 AO_UNSAFE, AO_SHADER_FAILURE, AO_PIPELINE_FAILURE, AO_ACTIVE, AO_ACTIVE_ESTIMATE, AO_DEBUG,
 AO_STATE_COUNT
};
#define AO_DEBUG_COUNT 15
static enum AO_STATE g_aoState=AO_OFF, g_aoLoggedState=AO_STATE_COUNT;
static enum AO_STATE g_aoSetupFailure=AO_PIPELINE_FAILURE;
static enum AO_STATE g_fxSetupFailure=AO_PIPELINE_FAILURE;
static U64 g_aoStateSince=0, g_nextAoAttempt=0;
static const char *g_projectionDetail="UNAVAILABLE";
static U32 g_sceneFormat=0;
static P g_fxOutput=0,g_fxOutputRTV=0;
static U64 g_aoAutoProbeAfter=0;
typedef struct {
 P resourceKey,latestViewKey;
 U32 width,height,format,bindFlags,msaa,sampleQuality,bindings,draws;
 U64 lastBindFrame,lastDrawFrame,lastClearFrame,lastClearSerial,lastDepthClearSerial,lastDrawSerial;
 U64 lastDepthClearFrame,lastWriteSerial,colorTargets,compatWriteSerial,compatMutationSerial;
 U32 sceneWrites,partialWrites,epochRejected,compatInvalid,compatSeenReasons;
 U32 clearCount,drawsSinceClear,fullViewportDraws,partialViewportDraws;
 U32 lastClearFlags;
 float lastClearDepth;
} DEPTH_REC;
static U64 g_depthSerial=0;

static DEPTH_REC g_depthRecords[MAX_DEPTH_CANDIDATES];
static DEPTH_REC g_rgRecords[MAX_RG_CANDIDATES];
static U32 g_depthCount=0,g_depthActive=0xffffffffu;
static P g_depthTexture[MAX_DEPTH_CANDIDATES]={0};
static P g_previewPS=0,g_previewSrv=0,g_previewCB=0;
static P g_aoDepthSrv=0;
static U32 g_aoDepthIndex=0xffffffffu;
static U64 g_aoDepthFrame=~0ull,g_aoDepthEpoch=0;
static float g_aoDepthClear=0.0f;
enum { DEPTH_WAITING, DEPTH_UNSAFE, DEPTH_READY, DEPTH_COMPATIBLE };
enum { DEPTH_BOUNDARY_NONE, DEPTH_BOUNDARY_UNBIND, DEPTH_BOUNDARY_CLEAR, DEPTH_BOUNDARY_PRESENT, DEPTH_BOUNDARY_MUTATION };
static const char *g_aoDepthReason="WAITING FOR DEPTH OBSERVER";
static const char *g_aoReasonLogged;
static U64 g_lastAoReasonTick;
static U32 g_aoPassesLogged;
static U32 g_aoDepthStatus=DEPTH_WAITING,g_aoDepthBoundary=DEPTH_BOUNDARY_NONE;
static P g_aoPS=0,g_aoTex=0,g_aoRTV=0,g_aoOutputSRV=0;
static P g_aoDenoisePS=0,g_aoDenoiseTex=0,g_aoDenoiseRTV=0,g_aoDenoiseSRV=0;
static P g_xePreparePS=0,g_xeDownsamplePS=0,g_xeDepthTex=0,g_xeDepthRTV=0,g_xeDepthSRV=0;
#define XE_DEPTH_MIP_LEVELS 5
static P g_xeMipSRV[XE_DEPTH_MIP_LEVELS]={0};
static P g_xeMipRTV[XE_DEPTH_MIP_LEVELS]={0}; /* index 0 unused; g_xeDepthRTV writes mip 0 */
static U32 g_aoOutputW=0,g_aoOutputH=0;
static U32 g_previewIndex=0,g_previewLoadedIndex=0xffffffffu,g_previewOn=0,g_previewDrawLogged=0;
/* Preview modes: 0=false color, 1=raw, 2=inverted, 3=window, 4=inverted window,
   5=estimated forward perspective, 6=estimated reverse perspective. Last two are NOT calibrated. */
#define PREVIEW_MODE_COUNT 11
#define MENU_ROWS 23
#define PLAYER_ROWS 12
static U32 g_previewMode=1;
static I32 g_previewCenter=50,g_previewWidth=20; /* percent of 0..1 depth range */
static I32 g_previewFov=70; /* uncalibrated estimate in degrees; NOT actual game FOV */
static volatile I32 g_depthGuard=0;
static U32 g_previewFailReported=0;
static volatile U32 g_depthEnabled=0, g_depthDone=0;
/* A capture may check/install the observer once, not every Present frame. */
static U32 g_depthHooked=0,g_depthHookWarned=0,g_depthHookSessionChecked=0;
static U32 g_depthHookSessionReady=0;
/* Capture-only, read-only check. Do not re-patch unknown code. */
static U32 g_hookLossObserved=0, g_unfocusedPresents=0, g_resizesWhileCapturing=0;
static U32 g_monitorSamples=0;
/* Identify the exact COM vtable and context we patched. Never re-use stored
   forwarding pointers against an unrelated context's vtable. */
static P* g_depthPatchedTable=0;
static P g_depthPatchedContext=0;
/* ID3D11DeviceContext (base interface) exposes 115 slots, ending with
   FinishCommandList at 114. Use an INSTANCE-local clone so other runtime
   contexts do not share the modified draw slots. Reserve space for the
   latest known extension if QueryInterface returns this same pointer. */
#define D3D11_BASE_CONTEXT_SLOTS 115
#define D3D11_CONTEXT_VTABLE_SLOTS 149
static P g_privateContextVtable[D3D11_CONTEXT_VTABLE_SLOTS];
static P* g_sharedContextVtable=0;
static U32 g_privateVtablePublished=0;
static volatile U32 g_selfTestExecuted=0, g_selfTestPassed=0;
static volatile U32 g_selfTestRawBefore=0, g_selfTestRawAfter=0;
static U64 g_depthStartFrame=0;
static I32 g_values[6]={30,100,100,0,100,0};
static U32 g_dirty=1;
static volatile I32 g_presentBusy=0,g_surfaceBusy=0,g_resizing=0;
static U32 g_hadFocus=0;
static P g_backOwner=0;
static P g_device,g_ctx,g_back,g_source,g_rtv,g_srv,g_uiTex,g_uiSrv,g_vs,g_ps,g_sampler,g_constants,g_overlayPS,g_overlayBlend;
static volatile U32 g_internalDrawActive=0; /* Identify our own overlay/postfx Draw calls. */
static U32 g_width,g_height;
static U8 g_menuPixels[MENU_W*MENU_H*4];
#include "font.inc"

/* Freestanding CRT intrinsics; no libc dependency. */
void* memcpy(void* d,const void* s,U64 n){U8* a=(U8*)d;const U8* b=(const U8*)s;for(U64 i=0;i<n;i++)a[i]=b[i];return d;}
void* memset(void* d,int v,U64 n){U8* a=(U8*)d;for(U64 i=0;i<n;i++)a[i]=(U8)v;return d;}
static U32 slen(const char*s){U32 i=0;while(s[i])++i;return i;}
static void path_init(void){
 U32 n=GetModuleFileNameW(g_self,g_logPath,510); if(!n||n>510)return;
 while(n>0 && g_logPath[n-1]!='\\'&&g_logPath[n-1]!='/')--n;
 U32 i=0;while(kLogName[i]&&n+i<518){g_logPath[n+i]=kLogName[i];i++;}g_logPath[n+i]=0;
 n=GetModuleFileNameW(g_self,g_iniPath,510);
 while(n>0&&g_iniPath[n-1]!='\\'&&g_iniPath[n-1]!='/')--n;
 i=0;while(kConfigName[i]&&n+i<518){g_iniPath[n+i]=kConfigName[i];i++;}g_iniPath[n+i]=0;
}
static void log_msg(const char*s){
 if(!g_logPath[0])return;
 P h=CreateFileW(g_logPath,GENERIC_WRITE_,3,0,OPEN_ALWAYS_,0x80,0);
 if(!h||h==(P)(U64)-1)return;
 SetFilePointer(h,0,0,FILE_END_);U32 wr=0;WriteFile(h,s,slen(s),&wr,0);CloseHandle(h);
 OutputDebugStringA(s);
}
static void log_hex(const char*message,U32 value){
 char out[256];U32 n=0;while(message[n]&&n<215){out[n]=message[n];n++;}
 out[n++]=' ';out[n++]='0';out[n++]='x';
 for(U32 i=0;i<8;i++){U32 nib=(value>>(28-4*i))&15;out[n++]=(char)(nib<10?'0'+nib:'A'+nib-10);}
 out[n++]='\r';out[n++]='\n';out[n]=0;log_msg(out);
}
static void putint_w(I32 value,WCHAR*out){WCHAR r[16];U32 i=0,j=0;I32 neg=value<0;U32 n=neg?(U32)(-value):(U32)value;
 do{r[i++]=(WCHAR)('0'+n%10);n/=10;}while(n&&i<14);
 if(neg)out[j++]='-';while(i)out[j++]=r[--i];out[j]=0;
}
static void save_config(void){
 WCHAR buf[18];const WCHAR*keys[6]={kSharpKey,kSatKey,kContrastKey,kBrightKey,kGammaKey,kFxKey};
 for(U32 i=0;i<6;i++){putint_w(i==5?(I32)g_fx:g_values[i],buf);WritePrivateProfileStringW(kCore,keys[i],buf,g_iniPath);}
 putint_w((I32)g_previewMode,buf);WritePrivateProfileStringW(kDiag,kPreviewModeKey,buf,g_iniPath);
 putint_w(g_previewCenter,buf);WritePrivateProfileStringW(kDiag,kPreviewCenterKey,buf,g_iniPath);
 putint_w(g_previewWidth,buf);WritePrivateProfileStringW(kDiag,kPreviewWidthKey,buf,g_iniPath);
 putint_w(g_previewFov,buf);WritePrivateProfileStringW(kDiag,kPreviewFovKey,buf,g_iniPath);
 putint_w((I32)g_ao,buf);WritePrivateProfileStringW(kAOSection,kAOEnable,buf,g_iniPath);
 putint_w(g_aoStrength,buf);WritePrivateProfileStringW(kAOSection,kAOStrength,buf,g_iniPath);
 putint_w(g_aoRadius,buf);WritePrivateProfileStringW(kAOSection,kAORadius,buf,g_iniPath);
 putint_w((I32)g_aoQuality,buf);WritePrivateProfileStringW(kAOSection,kAOQuality,buf,g_iniPath);
 putint_w((I32)g_aoPreset,buf);WritePrivateProfileStringW(kAOSection,kAOPreset,buf,g_iniPath);
 putint_w((I32)g_aoSourceChoice,buf);WritePrivateProfileStringW(kAOSection,kAOSource,buf,g_iniPath);
 putint_w((I32)g_aoHudGuard,buf);WritePrivateProfileStringW(kAOSection,kAOHudGuard,buf,g_iniPath);
 putint_w(g_aoContactBoost,buf);WritePrivateProfileStringW(kAOSection,kAOContactBoost,buf,g_iniPath);
 putint_w((I32)g_aoEdgeGuard,buf);WritePrivateProfileStringW(kAOSection,kAOEdgeGuard,buf,g_iniPath);
}
static void load_config(void){
 const WCHAR*keys[5]={kSharpKey,kSatKey,kContrastKey,kBrightKey,kGammaKey};
 for(U32 i=0;i<5;i++)g_values[i]=(I32)GetPrivateProfileIntW(kCore,keys[i],g_values[i],g_iniPath);
 if(g_values[0]<0||g_values[0]>100)g_values[0]=30;
 if(g_values[1]<0||g_values[1]>200)g_values[1]=100;
 if(g_values[2]<50||g_values[2]>180)g_values[2]=100;
 if(g_values[3]<-30||g_values[3]>30)g_values[3]=0;
 if(g_values[4]<50||g_values[4]>150)g_values[4]=100;
 g_fx=GetPrivateProfileIntW(kCore,kFxKey,1,g_iniPath)?1:0;
 g_hookEnabled=GetPrivateProfileIntW(kDiag,kHookKey,1,g_iniPath)?1:0;
 g_probeDelayMs=GetPrivateProfileIntW(kDiag,kDelayKey,30000,g_iniPath);
 if(g_probeDelayMs<10000)g_probeDelayMs=10000;
 if(g_probeDelayMs>120000)g_probeDelayMs=120000;
 g_passthroughFrames=GetPrivateProfileIntW(kDiag,kFramesKey,120,g_iniPath);
 if(g_passthroughFrames<30)g_passthroughFrames=30;
 if(g_passthroughFrames>1200)g_passthroughFrames=1200;
 g_previewMode=GetPrivateProfileIntW(kDiag,kPreviewModeKey,1,g_iniPath);
 if(g_previewMode>=PREVIEW_MODE_COUNT)g_previewMode=1;
 g_previewCenter=(I32)GetPrivateProfileIntW(kDiag,kPreviewCenterKey,50,g_iniPath);
 if(g_previewCenter<0||g_previewCenter>100)g_previewCenter=50;
 g_previewWidth=(I32)GetPrivateProfileIntW(kDiag,kPreviewWidthKey,20,g_iniPath);
 if(g_previewWidth<1||g_previewWidth>100)g_previewWidth=20;
 g_previewFov=(I32)GetPrivateProfileIntW(kDiag,kPreviewFovKey,70,g_iniPath);
 if(g_previewFov<40||g_previewFov>110)g_previewFov=70;
 g_ao=GetPrivateProfileIntW(kAOSection,kAOEnable,1,g_iniPath)?1:0;
 g_aoStrength=(I32)GetPrivateProfileIntW(kAOSection,kAOStrength,38,g_iniPath);
 if(g_aoStrength<0||g_aoStrength>100)g_aoStrength=38;
 g_aoRadius=(I32)GetPrivateProfileIntW(kAOSection,kAORadius,14,g_iniPath);
 if(g_aoRadius<4||g_aoRadius>48)g_aoRadius=14;
 g_aoQuality=GetPrivateProfileIntW(kAOSection,kAOQuality,2,g_iniPath);
 if(g_aoQuality>2)g_aoQuality=2;
 g_aoPreset=GetPrivateProfileIntW(kAOSection,kAOPreset,1,g_iniPath);
 if(g_aoPreset>3)g_aoPreset=3;
 g_aoDebug=0; /* Developer visualizations require an explicit session action. */
 g_aoHudGuard=GetPrivateProfileIntW(kAOSection,kAOHudGuard,1,g_iniPath)?1:0;
 g_aoContactBoost=(I32)GetPrivateProfileIntW(kAOSection,kAOContactBoost,15,g_iniPath);
 if(g_aoContactBoost<0||g_aoContactBoost>100)g_aoContactBoost=15;
 g_aoEdgeGuard=GetPrivateProfileIntW(kAOSection,kAOEdgeGuard,1,g_iniPath);
 if(g_aoEdgeGuard>2)g_aoEdgeGuard=1;
 g_aoSourceChoice=GetPrivateProfileIntW(kAOSection,kAOSource,0,g_iniPath);
 if(g_aoSourceChoice>3)g_aoSourceChoice=0;
 g_aoState=g_ao?AO_REQUESTED:AO_OFF;
 if(g_ao)g_aoAutoProbeAfter=g_passthroughFrames+1;
}

static void px(I32 x,I32 y,U8 r,U8 g,U8 b,U8 a){
 if(x<0||x>=MENU_W||y<0||y>=MENU_H)return;
 U32 p=((U32)y*MENU_W+(U32)x)*4;
 g_menuPixels[p]=r;g_menuPixels[p+1]=g;g_menuPixels[p+2]=b;g_menuPixels[p+3]=a;
}
static void rect(I32 x,I32 y,I32 w,I32 h,U8 r,U8 g,U8 b,U8 a){
 for(I32 j=y;j<y+h;j++)for(I32 i=x;i<x+w;i++)px(i,j,r,g,b,a);
}
static void label(I32 x,I32 y,const char*s,U8 r,U8 g,U8 b){
 for(U32 c=0;s[c];c++){U32 ch=(U8)s[c];if(ch<32||ch>126)ch=32;
  for(U32 yy=0;yy<12;yy++){U8 row=kFont[ch-32][yy];for(U32 xx=0;xx<8;xx++)if(row&(1u<<(7-xx)))px(x+(I32)c*8+(I32)xx,y+(I32)yy,r,g,b,255);}
 }
}
static void rowNumber(U32 row,I32 value){
 char digits[20];U32 n=0;U32 neg=value<0;U32 a=neg?(U32)(-value):(U32)value;
 do{digits[n++]=(char)('0'+a%10);a/=10;}while(a&&n<16);
 char result[22];U32 j=0; if(neg)result[j++]='-';while(n)result[j++]=digits[--n];result[j]=0;
 label(415,82+(I32)row*31,result,240,240,255);
}
static const char* preview_mode_name(U32 mode){
 static const char* names[PREVIEW_MODE_COUNT]={
  "False color", "Raw grayscale", "Inverted", "Range grayscale",
  "Range inverted", "Est. linear forward", "Est. linear reverse",
  "EST. REVERSE NORMALS", "Reverse depth edges", "Normal slope debug", "Normal confidence"
 };
 return names[mode<PREVIEW_MODE_COUNT?mode:0];
}
static int eligible_preview(U32 i){
 if(i>=g_depthCount)return 0;
 const DEPTH_REC *r=&g_depthRecords[i];
 return (r->format==19||r->format==39) && (r->bindFlags&BIND_SRV) && r->msaa==1 && g_depthTexture[i]!=0;
}
static const char *const aoStateText[AO_STATE_COUNT]={
 "AO OFF BY USER", "AO REQUESTED", "AO WAITING FOR DEPTH", "AO WAITING FOR CAMERA",
 "AO UNSAFE INPUT", "AO SHADER COMPILE FAILED", "AO PIPELINE SETUP FAILED",
 "AO ACTIVE", "AO ACTIVE - ESTIMATED CAMERA", "AO DEBUG VIEW"
};

static void set_ao_state(enum AO_STATE state){
 U64 now=GetTickCount64();
 if(state!=g_aoState){g_aoState=state;g_aoStateSince=now;g_dirty=1;}
 if(state==g_aoLoggedState)return;
 /* Keep the menu current but log only sustained availability changes. */
 if(state!=AO_OFF && state!=AO_REQUESTED && state!=AO_SHADER_FAILURE &&
    state!=AO_PIPELINE_FAILURE && now-g_aoStateSince<650)return;
 g_aoLoggedState=state;
 char message[48];U32 n=slen(aoStateText[state]);
 memcpy(message,aoStateText[state],n);
 message[n++]='\r';message[n++]='\n';message[n]=0;
 log_msg(message);
}
static const char *ao_toggle_text(void){
 static const char *const labels[AO_STATE_COUNT]={
  "OFF", "REQUESTED", "WAITING FOR DEPTH", "WAITING FOR CAMERA", "UNSAFE INPUT",
  "SHADER ERROR", "SETUP ERROR", "ACTIVE", "ACTIVE (EST.)", "DEBUG VIEW"
 };
 return g_ao?labels[g_aoState]:"OFF";
}
static void make_menu(void){
 memset(g_menuPixels,0,sizeof(g_menuPixels));
 if(!g_advancedMenu){
  /* Compact player panel; the rest of the 600x930 overlay is transparent. */
  rect(0,0,MENU_W,550,15,20,32,225);
  rect(0,0,MENU_W,45,26,51,81,250);
  label(18,16,"WD2 ENHANCED 0.38 | PLAYER SETTINGS",255,255,255);
  label(18,54,"F8 HIDE  UP/DOWN SELECT  LEFT/RIGHT CHANGE",172,204,242);
  static const char* rows[PLAYER_ROWS]={
   "XeGTAO","AO appearance","AO strength %","AO radius",
   "AO quality","Sharpen + color","Sharpen","Saturation",
   "Contrast","Brightness","Gamma","Developer options"
  };
  static const char* presets[4]={"NATURAL","BALANCED","STRONG","CUSTOM"};
  for(U32 i=0;i<PLAYER_ROWS;i++){
   U32 y=82+i*31;
   if(g_selected==i)rect(14,(I32)y-4,MENU_W-28,27,40,80,111,236);
   label(26,(I32)y,rows[i],255,255,255);
   if(i==0)label(415,(I32)y,ao_toggle_text(),g_ao?130:255,g_ao?245:160,145);
   else if(i==1)label(400,(I32)y,presets[g_aoPreset<4?g_aoPreset:3],140,225,255);
   else if(i==2)rowNumber(i,g_aoStrength);
   else if(i==3)rowNumber(i,g_aoRadius);
   else if(i==4)label(415,(I32)y,g_aoQuality==0?"LOW":g_aoQuality==1?"MEDIUM":"HIGH",140,225,255);
   else if(i==5)label(415,(I32)y,g_fx?"ON":"OFF",g_fx?130:255,g_fx?245:160,145);
   else if(i<11)rowNumber(i,g_values[i-6]);
   else label(375,(I32)y,"ENTER / TAB",140,225,255);
  }
  label(18,462,aoStateText[g_aoState],(g_aoState==AO_ACTIVE||g_aoState==AO_ACTIVE_ESTIMATE)?140:240,220,163);
  label(18,489,"TAB DEVELOPER OPTIONS  |  F9 SHARPEN + COLOR",166,210,255);
  g_dirty=0;
  return;
 }
 rect(0,0,MENU_W,MENU_H,15,20,32,222);
 rect(0,0,MENU_W,44,26,51,81,250);
 label(18,16,"WD2 ENHANCED 0.38 | DEVELOPER OPTIONS",255,255,255);
 label(18,54,"TAB PLAYER MENU  F8 HIDE  ARROWS ADJUST",172,204,242);
 static const char* names[MENU_ROWS]={
  "Sharpen", "Saturation", "Contrast", "Brightness", "Gamma", "Post FX",
  "Depth probe", "Depth candidate", "Depth mode", "Range center %",
  "Range width %", "Est. FOV deg", "Depth preview",
  "XeGTAO", "AO strength %", "AO radius", "AO quality", "AO visualization", "AO depth source", "AO HUD guard", "AO contact boost %", "AO edge guard", "AO projection"
 };
 for(U32 i=0;i<MENU_ROWS;i++){
  U32 y=82+i*31;
  if(g_selected==i)rect(14,(I32)y-4,MENU_W-28,27,40,80,111,236);
  label(26,(I32)y,names[i],255,255,255);
  if(i<5)rowNumber(i,g_values[i]);
  else if(i==5)label(415,(I32)y,g_fx?"ON":"OFF",g_fx?100:255,g_fx?245:142,132);
  else if(i==6)label(415,(I32)y,g_depthDone?"DONE":g_depthEnabled?"CAPTURING":"OFF",g_depthDone?115:255,g_depthDone?234:190,148);
  else if(i==7){if(g_depthDone && g_depthCount){rowNumber(i,(I32)g_previewIndex);label(453,(I32)y,eligible_preview(g_previewIndex)?"SRV":"N/A",180,207,247);}else label(415,(I32)y,"NO DATA",255,170,150);}
  else if(i==8)label(320,(I32)y,preview_mode_name(g_previewMode),130,225,255);
  else if(i==9)rowNumber(i,g_previewCenter);
  else if(i==10)rowNumber(i,g_previewWidth);
  else if(i==11)rowNumber(i,g_previewFov);
  else if(i==12)label(415,(I32)y,g_previewOn?"ON":"OFF",g_previewOn?130:255,g_previewOn?245:160,145);
  else if(i==13)label(415,(I32)y,ao_toggle_text(),g_ao?130:255,g_ao?245:160,145);
  else if(i==14)rowNumber(i,g_aoStrength);
  else if(i==15)rowNumber(i,g_aoRadius);
  else if(i==16)label(400,(I32)y,g_aoQuality==0?"LOW":g_aoQuality==1?"MEDIUM":"HIGH",130,225,255);
  else if(i==17){
   static const char*debugNames[AO_DEBUG_COUNT]={
    "OFF","FINAL AO (WHITE=NONE)","RAW SCENE DEPTH","VIEW-SPACE DEPTH","DEPTH VALIDITY",
    "DEPTH COVERAGE","RECONSTRUCTED NORMALS","PREPARED DEPTH MIP 0","PREPARED DEPTH MIP 1",
    "PREPARED DEPTH MIP 2","PREPARED DEPTH MIP 3","PREPARED DEPTH MIP 4",
    "RAW VISIBILITY","DENOISED VISIBILITY","REJECTION REASONS"};
   label(327,(I32)y,debugNames[g_aoDebug],g_aoDebug?130:255,g_aoDebug?245:160,145);
  }
  else if(i==18)label(350,(I32)y,g_aoSourceChoice==0?"AUTO SNAPSHOT":g_aoSourceChoice==1?"CANDIDATE 0":g_aoSourceChoice==2?"CANDIDATE 1":"CANDIDATE 2",140,225,255);
  else if(i==19)label(415,(I32)y,g_aoHudGuard?"ON":"OFF",g_aoHudGuard?130:255,220,172);
  else if(i==20)rowNumber(i,g_aoContactBoost);
  else if(i==21)label(390,(I32)y,g_aoEdgeGuard==0?"GENTLE":g_aoEdgeGuard==1?"BALANCED":"STRICT",140,225,255);
  else label(350,(I32)y,g_projectionDetail,140,225,255);
 }
 label(18,801,"F10 PREVIEW  F11 DEPTH  F12 PREVIEW MODE",166,210,255);
 label(18,825,"TAB BACK TO PLAYER SETTINGS | F9 POST FX",255,197,117);
 label(18,849,aoStateText[g_aoState],(g_aoState==AO_ACTIVE||g_aoState==AO_ACTIVE_ESTIMATE)?140:240,220,163);
 label(18,873,g_aoDepthStatus==DEPTH_WAITING||g_aoDepthStatus==DEPTH_UNSAFE?g_aoDepthReason:
          g_aoSetupFailure==AO_PIPELINE_FAILURE&&g_aoPS?"AO PIPELINE RESOURCES READY":"AO DEPTH SNAPSHOT READY",255,190,102);
 if(g_aoDepthIndex<MAX_DEPTH_CANDIDATES){
  char candidate[]="SNAPSHOT CANDIDATE 00";
  candidate[19]=(char)('0'+g_aoDepthIndex/10);
  candidate[20]=(char)('0'+g_aoDepthIndex%10);
  label(18,897,candidate,166,210,255);
  label(210,897,g_aoDepthBoundary==DEPTH_BOUNDARY_CLEAR?"BEFORE CLEAR":
        g_aoDepthBoundary==DEPTH_BOUNDARY_UNBIND?"DSV SWITCH":
        g_aoDepthBoundary==DEPTH_BOUNDARY_MUTATION?"BEFORE RESOURCE CHANGE":"PRESENT BOUNDARY",166,210,255);
 }
 g_dirty=0;
}
static U32 rising(U32 vk){
 U32 down=(GetAsyncKeyState((I32)vk)&0x8000)?1:0;
 U32 idx=vk==VK_F8?0:vk==VK_F9?1:vk==VK_UP?2:vk==VK_DOWN?3:vk==VK_LEFT?4:vk==VK_RIGHT?5:vk==VK_F10?7:vk==VK_F11?8:vk==VK_F12?9:vk==VK_TAB?10:6;
 U32 prev=g_input[idx];
 g_input[idx]=down;return down&&!prev;
}
static void clear_depth_probe(void);
static void select_depth_candidate(U32 idx){
 if(!g_depthDone || !g_depthCount)return;
 g_previewIndex=idx%g_depthCount;
 REL(g_previewSrv);g_previewLoadedIndex=0xffffffffu;
 g_previewFailReported=0;g_previewDrawLogged=0;g_dirty=1;
 log_hex("DEPTH PREVIEW SELECTED CANDIDATE",g_previewIndex);
}
static void set_preview_mode(U32 mode){
 g_previewMode=mode%PREVIEW_MODE_COUNT;g_dirty=1;save_config();
 log_hex("DEPTH PREVIEW MODE",g_previewMode);
 if(g_previewMode>=5)log_msg("WARNING: ESTIMATED PERSPECTIVE DEPTH / NORMALS USE ASSUMED CAMERA; DEBUG ONLY\r\n");
}
static void toggle_ao(void){
 g_ao=!g_ao;g_aoAutoProbeAfter=0;g_dirty=1;save_config();
 set_ao_state(g_ao?AO_REQUESTED:AO_OFF);
 if(g_ao && !g_depthDone){g_depthEnabled=1;g_depthDone=0;g_depthStartFrame=g_frame;clear_depth_probe();g_depthHookSessionChecked=0;g_depthHookSessionReady=0;log_msg("AO AUTO-STARTED DEPTH PROBE\r\n");}
}
static void set_ao_preset(U32 preset){
 if(preset>2)return;
 g_aoPreset=preset;
 if(preset==0){g_aoStrength=24;g_aoRadius=10;g_aoContactBoost=10;g_aoEdgeGuard=2;}
 else if(preset==1){g_aoStrength=38;g_aoRadius=14;g_aoContactBoost=15;g_aoEdgeGuard=1;}
 else {g_aoStrength=49;g_aoRadius=18;g_aoContactBoost=22;g_aoEdgeGuard=1;}
 g_aoQuality=2;g_aoHudGuard=1;g_aoDebug=0;
 g_dirty=1;save_config();log_hex("PLAYER AO PRESET (0 NATURAL, 1 BALANCED, 2 STRONG)",preset);
}
static void prime_keyboard(void){
 static const U32 keys[]={VK_F8,VK_F9,VK_UP,VK_DOWN,VK_LEFT,VK_RIGHT,VK_RETURN,VK_F10,VK_F11,VK_F12,VK_TAB};
 for(U32 i=0;i<sizeof(keys)/sizeof(keys[0]);i++)rising(keys[i]);
}
static void keyboard(void){
 if(rising(VK_F10) && g_menu && g_advancedMenu){
  if(!g_depthDone || !g_depthCount)log_msg("DEPTH PREVIEW UNAVAILABLE: COMPLETE DEPTH PROBE FIRST\r\n");
  else{
   g_previewOn=!g_previewOn;
   if(!g_previewOn)REL(g_previewSrv);
   g_previewLoadedIndex=0xffffffffu;g_previewFailReported=0;g_previewDrawLogged=0;g_dirty=1;
   log_msg(g_previewOn?"DEPTH PREVIEW ON (UNVERIFIED CANDIDATE)\r\n":"DEPTH PREVIEW OFF\r\n");
  }
 }
 if(rising(VK_F11) && g_menu && g_advancedMenu){
  if(g_depthDone&&g_depthCount)select_depth_candidate(g_previewIndex+1);
  else log_msg("DEPTH PREVIEW NEXT: NO CAPTURED DEPTH CANDIDATES\r\n");
 }
 if(rising(VK_F12) && g_menu && g_advancedMenu)set_preview_mode(g_previewMode+1);
 if(rising(VK_F8)){
  g_menu=!g_menu;g_dirty=1;
  if(!g_menu){g_aoDebug=0;g_previewOn=0;REL(g_previewSrv);g_previewLoadedIndex=0xffffffffu;}
  log_msg(g_menu?"F8 MENU OPEN\r\n":"F8 MENU CLOSED\r\n");
 }
 if(rising(VK_F9)){g_fx=!g_fx;g_dirty=1;save_config();log_msg(g_fx?"POSTFX ON\r\n":"POSTFX OFF\r\n");}
 if(!g_menu){rising(VK_UP);rising(VK_DOWN);rising(VK_LEFT);rising(VK_RIGHT);rising(VK_RETURN);rising(VK_TAB);return;}
 if(rising(VK_TAB)){
  g_advancedMenu=!g_advancedMenu;g_selected=0;g_dirty=1;
  if(!g_advancedMenu){
   /* Returning to player settings must not leave a developer-only diagnostic
      full-screen mask active (magenta invalid depth is not a scene error). */
   g_aoDebug=0;g_previewOn=0;REL(g_previewSrv);g_previewLoadedIndex=0xffffffffu;
   save_config();
  }
  return;
 }
 U32 rowCount=g_advancedMenu?MENU_ROWS:PLAYER_ROWS;
 if(rising(VK_UP)){g_selected=g_selected?g_selected-1:rowCount-1;g_dirty=1;}
 if(rising(VK_DOWN)){g_selected=(g_selected+1)%rowCount;g_dirty=1;}
 I32 step=(I32)rising(VK_RIGHT)-(I32)rising(VK_LEFT);
 U32 enter=rising(VK_RETURN);
 if(!g_advancedMenu){
  if((step||enter) && g_selected==0)toggle_ao();
  else if((step||enter) && g_selected==1){U32 p=(g_aoPreset==3?1:g_aoPreset);p=(p+(step<0?2:1))%3;set_ao_preset(p);}
  else if(step && g_selected==2){g_aoStrength+=step*5;if(g_aoStrength<0)g_aoStrength=0;if(g_aoStrength>100)g_aoStrength=100;g_aoPreset=3;g_dirty=1;save_config();}
  else if(step && g_selected==3){g_aoRadius+=step*2;if(g_aoRadius<4)g_aoRadius=4;if(g_aoRadius>48)g_aoRadius=48;g_aoPreset=3;g_dirty=1;save_config();}
  else if((step||enter) && g_selected==4){g_aoQuality=(g_aoQuality+(step<0?2:1))%3;g_aoPreset=3;g_dirty=1;save_config();}
  else if((step||enter) && g_selected==5){g_fx=!g_fx;g_dirty=1;save_config();}
  else if(step && g_selected>=6 && g_selected<=10){
   U32 j=g_selected-6;
   static const I32 low[5]={0,0,50,-30,50};static const I32 high[5]={100,200,180,30,150};
   I32 v=g_values[j]+step*5;if(v<low[j])v=low[j];if(v>high[j])v=high[j];
   g_values[j]=v;g_dirty=1;save_config();
  }
  else if((step||enter) && g_selected==11){g_advancedMenu=1;g_selected=0;g_dirty=1;}
  return;
 }
 if((step||enter)&&g_selected==6){g_depthEnabled=!g_depthEnabled;g_depthDone=0;g_depthStartFrame=g_frame;clear_depth_probe();g_dirty=1;log_msg(g_depthEnabled?"DEPTH PROBE ENABLED BY MENU\r\n":"DEPTH PROBE DISABLED BY MENU\r\n");}
 else if((step||enter)&&g_selected==5){g_fx=!g_fx;g_dirty=1;save_config();}
 else if((step||enter)&&g_selected==7){
   if(g_depthDone&&g_depthCount){
    U32 idx=(g_previewIndex+g_depthCount+(step<0?g_depthCount-1:1))%g_depthCount;
    select_depth_candidate(idx);
   }
 }
 else if((step||enter)&&g_selected==8){
   U32 idx=(g_previewMode+PREVIEW_MODE_COUNT+(step<0?PREVIEW_MODE_COUNT-1:1))%PREVIEW_MODE_COUNT;
   set_preview_mode(idx);
 }
 else if(step && (g_selected==9||g_selected==10)){
   I32 *value=g_selected==9?&g_previewCenter:&g_previewWidth;
   I32 v=*value+step*5;
   if(v<(g_selected==9?0:1))v=(g_selected==9?0:1);
   if(v>100)v=100;
   *value=v;g_dirty=1;save_config();
   log_hex(g_selected==9?"DEPTH RANGE CENTER %":"DEPTH RANGE WIDTH %",(U32)v);
 }
 else if(step && g_selected==11){
   I32 v=g_previewFov+step*5;
   if(v<40)v=40;if(v>110)v=110;
   g_previewFov=v;g_dirty=1;save_config();
   log_hex("ESTIMATED CAMERA FOV DEGREES (NOT VALIDATED)",(U32)v);
 }
 else if((step||enter)&&g_selected==12){
   if(g_depthDone&&g_depthCount){
    g_previewOn=!g_previewOn;g_dirty=1;
    log_msg(g_previewOn?"DEPTH PREVIEW ON (NOT VALIDATED AS SCENE DEPTH)\r\n":"DEPTH PREVIEW OFF\r\n");
   }
 }
 else if((step||enter)&&g_selected==13){toggle_ao();}
 else if(step&&g_selected==14){
   g_aoStrength+=step*5;if(g_aoStrength<0)g_aoStrength=0;if(g_aoStrength>100)g_aoStrength=100;
   g_aoPreset=3;g_dirty=1;save_config();
 }
 else if(step&&g_selected==15){
   g_aoRadius+=step*4;if(g_aoRadius<4)g_aoRadius=4;if(g_aoRadius>48)g_aoRadius=48;
   g_aoPreset=3;g_dirty=1;save_config();
 }
 else if((step||enter)&&g_selected==16){
   g_aoQuality=(g_aoQuality+(step<0?2:1))%3;g_aoPreset=3;g_dirty=1;save_config();
 }
 else if((step||enter)&&g_selected==17){
   g_aoDebug=(g_aoDebug+(step<0?AO_DEBUG_COUNT-1:1))%AO_DEBUG_COUNT;g_dirty=1;
 }
 else if((step||enter)&&g_selected==18){
    g_aoSourceChoice=(g_aoSourceChoice+(step<0?3:1))%4;
    g_dirty=1;save_config();
    log_hex("AO DEPTH SOURCE CHOICE (0 AUTO, 1-3 CANDIDATES)",g_aoSourceChoice);
  }
  else if((step||enter)&&g_selected==19){g_aoHudGuard=!g_aoHudGuard;g_aoPreset=3;g_dirty=1;save_config();}
  else if(step&&g_selected==20){
   g_aoContactBoost+=step*10; if(g_aoContactBoost<0)g_aoContactBoost=0;
   if(g_aoContactBoost>100)g_aoContactBoost=100;g_aoPreset=3;g_dirty=1;save_config();
  }
  else if((step||enter)&&g_selected==21){
   g_aoEdgeGuard=(g_aoEdgeGuard+(step<0?2:1))%3;g_aoPreset=3;g_dirty=1;save_config();
  }
  else if(step&&g_selected<5){
   static const I32 low[5]={0,0,50,-30,50};static const I32 high[5]={100,200,180,30,150};
   I32 v=g_values[g_selected]+step*5;
   if(v<low[g_selected])v=low[g_selected];if(v>high[g_selected])v=high[g_selected];
   g_values[g_selected]=v;g_dirty=1;save_config();
 }
}

#include "shaders.inc"

typedef struct {
 float invW,invH,sharp,sat,contrast,bright,gamma,fx;
 float menu,pad[3];
 float aoMode,aoIntensity,aoRadius,aoQuality;
 float depthB,depthA,invScaleX,invScaleY;
 float sampleCount,depthWidth,depthHeight,hudGuard;
 float contactBoost,edgeGuard,colorAlreadyLinear,diagnosticInputReady;
 float offsetX,offsetY,clearDepth,padEnd;
} CB_;
typedef char assert_fx_cb_size[sizeof(CB_)==128?1:-1];
typedef struct {float center,rangeWidth,nearGuess,farGuess;U32 mode;float fovDeg,padding[2];} PREVIEW_CB_;
typedef char assert_preview_cb_size[sizeof(PREVIEW_CB_)==32?1:-1];
/* VTABLE function calls, using D3D11 published stable COM indices. */
static HRESULT_ dev_tex(P dev,const TEX2D_DESC*d,const SUB_DATA*s,P*out){return V(dev,5,HRESULT_(CALL*)(P,const TEX2D_DESC*,const SUB_DATA*,P*))(dev,d,s,out);}
static HRESULT_ dev_srv(P dev,P tex,P*out){return V(dev,7,HRESULT_(CALL*)(P,P,const void*,P*))(dev,tex,0,out);}
static HRESULT_ dev_srv_mip(P dev,P tex,U32 mip,P*out){
 TEX_SRV_DESC_ d={DXGI_FORMAT_RGBA32F,4,mip,1,0,0};
 return V(dev,7,HRESULT_(CALL*)(P,P,const void*,P*))(dev,tex,&d,out);
}
typedef struct {U32 Format,Dimension,Mip0,MipCount,Padding0,Padding1;} DEPTH_SRV_DESC;
typedef char assert_srv_size[sizeof(DEPTH_SRV_DESC)==24?1:-1];
static HRESULT_ dev_depth_srv(P dev,P tex,U32 format,U32 msaa,P*out){
 DEPTH_SRV_DESC d={format,msaa>1?6u:4u,0,msaa>1?0u:1u,0,0}; /* TEXTURE2D=4, TEXTURE2DMS=6 */
 return V(dev,7,HRESULT_(CALL*)(P,P,const DEPTH_SRV_DESC*,P*))(dev,tex,&d,out);
}
static HRESULT_ dev_rtv(P dev,P tex,P*out){return V(dev,9,HRESULT_(CALL*)(P,P,const void*,P*))(dev,tex,0,out);}
static HRESULT_ dev_rtv_mip(P dev,P tex,U32 mip,P*out){
 TEX_RTV_DESC_ d={DXGI_FORMAT_RGBA32F,4,mip,0,0};
 return V(dev,9,HRESULT_(CALL*)(P,P,const void*,P*))(dev,tex,&d,out);
}
static HRESULT_ dev_buf(P dev,const BUFFER_DESC*d,P*out){return V(dev,3,HRESULT_(CALL*)(P,const BUFFER_DESC*,const void*,P*))(dev,d,0,out);}
static HRESULT_ dev_vs(P dev,const void*data,SIZE_T_ size,P*out){return V(dev,12,HRESULT_(CALL*)(P,const void*,SIZE_T_,P,P*))(dev,data,size,0,out);}
static HRESULT_ dev_ps(P dev,const void*data,SIZE_T_ size,P*out){return V(dev,15,HRESULT_(CALL*)(P,const void*,SIZE_T_,P,P*))(dev,data,size,0,out);}
static HRESULT_ dev_sampler(P dev,const SAMPLER_DESC*d,P*out){return V(dev,23,HRESULT_(CALL*)(P,const SAMPLER_DESC*,P*))(dev,d,out);}
static HRESULT_ dev_blend(P dev,const BLEND_DESC_*d,P*out){return V(dev,20,HRESULT_(CALL*)(P,const BLEND_DESC_*,P*))(dev,d,out);}
static HRESULT_ (CALL *g_oldPresent)(P,U32,U32)=0;
static HRESULT_ (CALL *g_oldResize)(P,U32,U32,U32,U32,U32)=0;
static P g_target=0;
static U32 g_loggedFX=0,g_loggedOverlay=0,g_loggedMenuReady=0,g_loggedUav=0,g_loggedClasses=0,g_loggedAOPass=0;
static U64 g_nextInitAttempt=0,g_nextFxAttempt=0;
static HRESULT_ (CALL *g_compile)(const void*,SIZE_T_,const char*,const void*,void*,const char*,const char*,U32,U32,P*,P*)=0;
static void reset_depth_capture(void);
static void camera_reset(void);
static void release_depth_preview_resources(void){
 /* Guard texture ownership against callbacks on game rendering threads. */
 while(__sync_lock_test_and_set(&g_depthGuard,1)) Sleep(1);
 REL(g_previewSrv);
 reset_depth_capture();
 camera_reset();
 g_previewLoadedIndex=0xffffffffu;
 for(U32 i=0;i<MAX_DEPTH_CANDIDATES;i++) REL(g_depthTexture[i]);
 g_depthCount=0;g_depthActive=0xffffffffu;
 g_previewIndex=0;g_previewOn=0;g_previewFailReported=0;g_previewDrawLogged=0;
 __sync_lock_release(&g_depthGuard);
}
static void release_ao_pipeline(void){
 g_aoPassesLogged=0;
 for(U32 m=0;m<XE_DEPTH_MIP_LEVELS;m++){REL(g_xeMipSRV[m]);REL(g_xeMipRTV[m]);}
 REL(g_xeDepthSRV);REL(g_xeDepthRTV);REL(g_xeDepthTex);REL(g_xeDownsamplePS);REL(g_xePreparePS);
 REL(g_aoDenoiseSRV);REL(g_aoDenoiseRTV);REL(g_aoDenoiseTex);REL(g_aoDenoisePS);
 REL(g_aoOutputSRV);REL(g_aoRTV);REL(g_aoTex);REL(g_aoPS);
 g_aoOutputW=g_aoOutputH=0;g_loggedAOPass=0;
}
static void release_fx(void){
 release_ao_pipeline();g_nextAoAttempt=0;g_sceneFormat=0;
 REL(g_fxOutputRTV);REL(g_fxOutput);
 REL(g_srv);REL(g_source);REL(g_ps);REL(g_sampler);REL(g_constants);g_loggedFX=0;
}
static void release_pipeline(void){
 release_depth_preview_resources();REL(g_previewPS);REL(g_previewCB);release_fx();REL(g_uiSrv);REL(g_uiTex);REL(g_rtv);REL(g_back);
 REL(g_overlayPS);REL(g_overlayBlend);REL(g_vs);
 REL(g_ctx);REL(g_device);g_width=g_height=0;g_backOwner=0;g_loggedMenuReady=0;g_loggedOverlay=0;
}
static void drop_back(void){
 release_depth_preview_resources();REL(g_previewPS);REL(g_previewCB);release_fx();REL(g_uiSrv);REL(g_uiTex);REL(g_rtv);REL(g_back);g_width=g_height=0;
}
static int compile_shader_src(const char*source,const char*entry,const char*model,P*out){
 if(!g_compile){g_compiler=LoadLibraryW(kCompilerDll);if(g_compiler)g_compile=(void*)GetProcAddress(g_compiler,"D3DCompile");}
 if(!g_compile){log_msg("ERROR: d3dcompiler_47.dll unavailable\r\n");return 0;}
 P errors=0;HRESULT_ hr=g_compile(source,slen(source),"WD2Enhanced Embedded",0,0,entry,model,0,0,out,&errors);
 if(!SUCCEEDED_(hr)){
  log_hex("ERROR: HLSL compile",(U32)hr);
  if(errors){const char*detail=(const char*)V(errors,3,P(CALL*)(P))(errors);if(detail)log_msg(detail);}
 }
 REL(errors);return SUCCEEDED_(hr);
}
static int setup_overlay_inner(P sc){
 if(g_backOwner&&g_backOwner!=sc)release_pipeline();
 g_backOwner=sc;
 HRESULT_ hr;
 if(!g_device){
  hr=V(sc,7,HRESULT_(CALL*)(P,const GUID_*,P*))(sc,&IID_D3D11_DEVICE,&g_device);
  if(!SUCCEEDED_(hr)){log_hex("ERROR: Swapchain GetDevice(ID3D11Device)",(U32)hr);return 0;}
  log_msg("DX11 GAME DEVICE ACQUIRED\r\n");
  V(g_device,40,void(CALL*)(P,P*))(g_device,&g_ctx);
  if(!g_ctx){log_msg("ERROR: ID3D11Device::GetImmediateContext returned NULL\r\n");return 0;}
 }
 if(!g_vs){
  P blob=0;
  if(!compile_shader_src(hlsl,"VSMain","vs_5_0",&blob))return 0;
  P data=V(blob,3,P(CALL*)(P))(blob);SIZE_T_ length=V(blob,4,SIZE_T_(CALL*)(P))(blob);
  hr=dev_vs(g_device,data,length,&g_vs);REL(blob);
  if(!SUCCEEDED_(hr)){log_hex("ERROR: CreateVertexShader",(U32)hr);return 0;}
 }
 if(!g_overlayPS){
  P blob=0;
  if(!compile_shader_src(overlay_hlsl,"PSOverlay","ps_5_0",&blob))return 0;
  P data=V(blob,3,P(CALL*)(P))(blob);SIZE_T_ length=V(blob,4,SIZE_T_(CALL*)(P))(blob);
  hr=dev_ps(g_device,data,length,&g_overlayPS);REL(blob);
  if(!SUCCEEDED_(hr)){log_hex("ERROR: CreateOverlayPixelShader",(U32)hr);return 0;}
 }
 if(!g_overlayBlend){
  BLEND_DESC_ b;memset(&b,0,sizeof(b));
  b.Target[0].BlendEnable=1;
  b.Target[0].SrcBlend=5; // D3D11_BLEND_SRC_ALPHA
  b.Target[0].DestBlend=6; // D3D11_BLEND_INV_SRC_ALPHA
  b.Target[0].BlendOp=1; // D3D11_BLEND_OP_ADD
  b.Target[0].SrcBlendAlpha=2; // ONE
  b.Target[0].DestBlendAlpha=6; // INV_SRC_ALPHA
  b.Target[0].BlendOpAlpha=1;
  b.Target[0].RenderTargetWriteMask=0xF;
  hr=dev_blend(g_device,&b,&g_overlayBlend);
  if(!SUCCEEDED_(hr)){log_hex("ERROR: CreateBlendState",(U32)hr);return 0;}
 }
 if(!g_back){
  hr=V(sc,9,HRESULT_(CALL*)(P,U32,const GUID_*,P*))(sc,0,&IID_TEXTURE2D,&g_back);
  if(!SUCCEEDED_(hr)){log_hex("ERROR: Swapchain GetBuffer(0,Texture2D)",(U32)hr);return 0;}
  TEX2D_DESC desc;V(g_back,10,void(CALL*)(P,TEX2D_DESC*))(g_back,&desc);
  log_hex("BACKBUFFER FORMAT",desc.Format);log_hex("BACKBUFFER WIDTH",desc.Width);
  log_hex("BACKBUFFER HEIGHT",desc.Height);log_hex("BACKBUFFER MSAA SAMPLES",desc.SampleDesc.Count);
  log_hex("BACKBUFFER BIND FLAGS",desc.BindFlags);
  if(!desc.Width||!desc.Height||desc.Width>16384||desc.Height>16384){log_msg("ERROR: BACKBUFFER DIMENSIONS INVALID\r\n");return 0;}
  g_width=desc.Width;g_height=desc.Height;
  hr=dev_rtv(g_device,g_back,&g_rtv);
  if(!SUCCEEDED_(hr)){log_hex("ERROR: CreateRenderTargetView(backbuffer)",(U32)hr);return 0;}
 }
 if(!g_uiTex){
  TEX2D_DESC menu;memset(&menu,0,sizeof(menu));menu.Width=MENU_W;menu.Height=MENU_H;menu.MipLevels=1;menu.ArraySize=1;
  menu.Format=DXGI_FORMAT_RGBA8;menu.SampleDesc.Count=1;menu.BindFlags=BIND_SRV;
  make_menu();SUB_DATA data={g_menuPixels,MENU_W*4,0};
  hr=dev_tex(g_device,&menu,&data,&g_uiTex);
  if(!SUCCEEDED_(hr)){log_hex("ERROR: CreateMenuTexture",(U32)hr);return 0;}
 }
 if(!g_uiSrv){
  hr=dev_srv(g_device,g_uiTex,&g_uiSrv);
  if(!SUCCEEDED_(hr)){log_hex("ERROR: CreateMenuShaderResourceView",(U32)hr);return 0;}
 }
 return 1;
}
static int setup_overlay(P sc){
 if(setup_overlay_inner(sc)&&g_back&&g_rtv&&g_uiTex&&g_uiSrv&&g_vs&&g_overlayPS&&g_overlayBlend&&g_ctx)return 1;
 release_pipeline();return 0;
}
/* Optional color/sharpening.  Menu does not depend on this stage. */
static int setup_fx_inner(void){
 if(g_ps&&g_srv&&g_source&&g_sampler&&g_constants&&g_fxOutputRTV)return 1;
 g_fxSetupFailure=AO_PIPELINE_FAILURE;
 TEX2D_DESC desc;V(g_back,10,void(CALL*)(P,TEX2D_DESC*))(g_back,&desc);
 if(desc.SampleDesc.Count!=1){log_msg("FX UNAVAILABLE: MULTISAMPLED BACKBUFFER; MENU STILL AVAILABLE\r\n");return 0;}
 if(desc.Format!=28&&desc.Format!=29&&desc.Format!=87&&desc.Format!=91&&desc.Format!=24){
  log_hex("FX UNAVAILABLE: UNSUPPORTED BACKBUFFER FORMAT",desc.Format);return 0;
 }
 HRESULT_ hr;
 if(!g_ps){
  P psBlob=0;if(!compile_shader_src(hlsl,"PSMain","ps_5_0",&psBlob)){g_fxSetupFailure=AO_SHADER_FAILURE;return 0;}
  P data=V(psBlob,3,P(CALL*)(P))(psBlob);SIZE_T_ length=V(psBlob,4,SIZE_T_(CALL*)(P))(psBlob);
  hr=dev_ps(g_device,data,length,&g_ps);REL(psBlob);
  if(!SUCCEEDED_(hr)){log_hex("ERROR: CreateFXPixelShader",(U32)hr);return 0;}
 }
 if(!g_sampler){
  SAMPLER_DESC sd;memset(&sd,0,sizeof(sd));sd.Filter=D3D11_FILTER_MIN_MAG_MIP_LINEAR;
  sd.AddressU=sd.AddressV=sd.AddressW=D3D11_TEXTURE_ADDRESS_CLAMP;sd.ComparisonFunc=D3D11_COMPARISON_NEVER;
  sd.MaxLOD=3.402823e38f;
  hr=dev_sampler(g_device,&sd,&g_sampler);
  if(!SUCCEEDED_(hr)){log_hex("ERROR: CreateSamplerState",(U32)hr);return 0;}
 }
 if(!g_constants){
  BUFFER_DESC cbd;memset(&cbd,0,sizeof(cbd));cbd.ByteWidth=sizeof(CB_);cbd.BindFlags=4;
  hr=dev_buf(g_device,&cbd,&g_constants);
  if(!SUCCEEDED_(hr)){log_hex("ERROR: CreateConstantBuffer",(U32)hr);return 0;}
 }
 if(!g_source){
  desc.MipLevels=1;desc.BindFlags=BIND_SRV;desc.Usage=0;desc.CPUAccessFlags=0;desc.MiscFlags=0;
  hr=dev_tex(g_device,&desc,0,&g_source);
  if(!SUCCEEDED_(hr)){log_hex("ERROR: CreateSceneCopyTexture",(U32)hr);return 0;}
 }
 if(!g_srv){
  hr=dev_srv(g_device,g_source,&g_srv);
  if(!SUCCEEDED_(hr)){log_hex("ERROR: CreateSceneCopySRV",(U32)hr);return 0;}
 }
 if(!g_fxOutput){
  desc.BindFlags=BIND_RTV;
  hr=dev_tex(g_device,&desc,0,&g_fxOutput);
  if(!SUCCEEDED_(hr)){log_hex("ERROR: CreateCompositeTexture",(U32)hr);return 0;}
 }
 if(!g_fxOutputRTV){
  hr=dev_rtv(g_device,g_fxOutput,&g_fxOutputRTV);
  if(!SUCCEEDED_(hr)){log_hex("ERROR: CreateCompositeRTV",(U32)hr);return 0;}
 }
 g_sceneFormat=desc.Format;
 log_msg("DX11 SHARPEN / COLOR PIPELINE READY\r\n");return 1;
}
static int setup_fx(void){if(setup_fx_inner())return 1;release_fx();return 0;}
static int setup_ao_pipeline_inner(void){
 g_aoSetupFailure=AO_PIPELINE_FAILURE;
 if(!g_device||g_width<31||g_height<31)return 0;
 if(g_aoPS && g_xePreparePS && g_xeDownsamplePS && g_xeDepthTex && g_xeDepthRTV && g_xeDepthSRV && g_xeMipSRV[3] && g_xeMipRTV[4] && g_aoTex && g_aoRTV && g_aoOutputSRV && g_aoDenoisePS && g_aoDenoiseTex && g_aoDenoiseRTV && g_aoDenoiseSRV)return 1;
 HRESULT_ hr;
 if(!g_xePreparePS){
  P blob=0;if(!compile_shader_src(hlsl,"PSPrepare","ps_5_0",&blob)){g_aoSetupFailure=AO_SHADER_FAILURE;return 0;}
  P ptr=V(blob,3,P(CALL*)(P))(blob);SIZE_T_ sz=V(blob,4,SIZE_T_(CALL*)(P))(blob);
  hr=dev_ps(g_device,ptr,sz,&g_xePreparePS);REL(blob);
  if(!SUCCEEDED_(hr)){log_hex("ERROR: XeGTAO PREPARE PS",(U32)hr);return 0;}
 }
 if(!g_xeDownsamplePS){
  P blob=0;if(!compile_shader_src(hlsl,"PSDownsample","ps_5_0",&blob)){g_aoSetupFailure=AO_SHADER_FAILURE;return 0;}
  P ptr=V(blob,3,P(CALL*)(P))(blob);SIZE_T_ sz=V(blob,4,SIZE_T_(CALL*)(P))(blob);
  hr=dev_ps(g_device,ptr,sz,&g_xeDownsamplePS);REL(blob);
  if(!SUCCEEDED_(hr)){log_hex("ERROR: XeGTAO 5-MIP REDUCE PS",(U32)hr);return 0;}
 }
 if(!g_aoDenoisePS){
  P blob=0;if(!compile_shader_src(hlsl,"PSAODenoise","ps_5_0",&blob)){g_aoSetupFailure=AO_SHADER_FAILURE;return 0;}
  P ptr=V(blob,3,P(CALL*)(P))(blob);SIZE_T_ sz=V(blob,4,SIZE_T_(CALL*)(P))(blob);
  hr=dev_ps(g_device,ptr,sz,&g_aoDenoisePS);REL(blob);
  if(!SUCCEEDED_(hr)){log_hex("ERROR: XeGTAO DENOISE PS",(U32)hr);return 0;}
 }
 if(!g_aoPS){
  P blob=0;if(!compile_shader_src(hlsl,"PSAO","ps_5_0",&blob)){g_aoSetupFailure=AO_SHADER_FAILURE;return 0;}
  P ptr=V(blob,3,P(CALL*)(P))(blob);SIZE_T_ sz=V(blob,4,SIZE_T_(CALL*)(P))(blob);
  hr=dev_ps(g_device,ptr,sz,&g_aoPS);REL(blob);
  if(!SUCCEEDED_(hr)){log_hex("ERROR: AO PS CREATE",(U32)hr);return 0;}
 }
 if(!g_aoTex){
  TEX2D_DESC d;memset(&d,0,sizeof(d));
  g_aoOutputW=(g_width+1)/2;g_aoOutputH=(g_height+1)/2;
  d.Width=g_aoOutputW;d.Height=g_aoOutputH;d.MipLevels=1;d.ArraySize=1;
  d.Format=DXGI_FORMAT_RGBA16F;d.SampleDesc.Count=1;d.BindFlags=BIND_RTV|BIND_SRV;
  hr=dev_tex(g_device,&d,0,&g_aoTex);
  if(!SUCCEEDED_(hr)){log_hex("ERROR: AO HALFRES TEXTURE",(U32)hr);return 0;}
 }
 if(!g_aoDenoiseTex){
  TEX2D_DESC d;memset(&d,0,sizeof(d));
  d.Width=g_aoOutputW;d.Height=g_aoOutputH;d.MipLevels=1;d.ArraySize=1;
  d.Format=DXGI_FORMAT_RGBA16F;d.SampleDesc.Count=1;d.BindFlags=BIND_RTV|BIND_SRV;
  hr=dev_tex(g_device,&d,0,&g_aoDenoiseTex);
  if(!SUCCEEDED_(hr)){log_hex("ERROR: XeGTAO DENOISE TEXTURE",(U32)hr);return 0;}
 }
 if(!g_xeDepthTex){
  TEX2D_DESC d;memset(&d,0,sizeof(d));
  d.Width=g_aoOutputW;d.Height=g_aoOutputH;d.MipLevels=XE_DEPTH_MIP_LEVELS;d.ArraySize=1;
  d.Format=DXGI_FORMAT_RGBA32F;d.SampleDesc.Count=1;d.BindFlags=BIND_RTV|BIND_SRV;
  hr=dev_tex(g_device,&d,0,&g_xeDepthTex);
  if(!SUCCEEDED_(hr)){log_hex("ERROR: XeGTAO DEPTH PREPARE TEX",(U32)hr);return 0;}
 }
 if(!g_xeDepthRTV){hr=dev_rtv(g_device,g_xeDepthTex,&g_xeDepthRTV);
  if(!SUCCEEDED_(hr)){log_hex("ERROR: XeGTAO DEPTH PREPARE RTV",(U32)hr);return 0;}}
 if(!g_xeDepthSRV){hr=dev_srv(g_device,g_xeDepthTex,&g_xeDepthSRV);
  if(!SUCCEEDED_(hr)){log_hex("ERROR: XeGTAO DEPTH PREPARE SRV",(U32)hr);return 0;}}
 /* Each reduction reads mip n-1 and writes mip n with explicitly disjoint
    D3D11 SRV/RTV subresources. Never bind the full-chain SRV during reduction. */
 for(U32 m=0;m<XE_DEPTH_MIP_LEVELS;m++){
  if(!g_xeMipSRV[m]){
   hr=dev_srv_mip(g_device,g_xeDepthTex,m,&g_xeMipSRV[m]);
   if(!SUCCEEDED_(hr)){log_hex("ERROR: XeGTAO MIP SRV CREATE",(U32)hr);return 0;}
  }
  if(m>0 && !g_xeMipRTV[m]){
   hr=dev_rtv_mip(g_device,g_xeDepthTex,m,&g_xeMipRTV[m]);
   if(!SUCCEEDED_(hr)){log_hex("ERROR: XeGTAO MIP RTV CREATE",(U32)hr);return 0;}
  }
 }
 if(!g_aoRTV){hr=dev_rtv(g_device,g_aoTex,&g_aoRTV);
  if(!SUCCEEDED_(hr)){log_hex("ERROR: AO HALFRES RTV",(U32)hr);return 0;}}
 if(!g_aoOutputSRV){hr=dev_srv(g_device,g_aoTex,&g_aoOutputSRV);
  if(!SUCCEEDED_(hr)){log_hex("ERROR: AO HALFRES SRV",(U32)hr);return 0;}}
 if(!g_aoDenoiseRTV){hr=dev_rtv(g_device,g_aoDenoiseTex,&g_aoDenoiseRTV);
  if(!SUCCEEDED_(hr)){log_hex("ERROR: AO DENOISE RTV",(U32)hr);return 0;}}
 if(!g_aoDenoiseSRV){hr=dev_srv(g_device,g_aoDenoiseTex,&g_aoDenoiseSRV);
  if(!SUCCEEDED_(hr)){log_hex("ERROR: AO DENOISE SRV",(U32)hr);return 0;}}
 if(!g_loggedAOPass){g_loggedAOPass=1;log_hex("AO HALFRES WIDTH",g_aoOutputW);log_hex("AO HALFRES HEIGHT",g_aoOutputH);log_msg("XEGTAO RENDER TARGETS AND SHADERS READY\r\n");}
 return 1;
}
static int setup_ao_pipeline(void){
 U64 now=GetTickCount64();
 if(now<g_nextAoAttempt)return 0;
 if(setup_ao_pipeline_inner())return 1;
 release_ao_pipeline();g_nextAoAttempt=now+5000;
 return 0;
}
/* Restore all explicitly changed states. No OM UAVs: skip instead. */
typedef struct {P rt[8],dsv,uav[8];P vs,ps,gs,hs,ds;P vsclass[MAX_CLASSES],psclass[MAX_CLASSES],gsclass[MAX_CLASSES],hsclass[MAX_CLASSES],dsclass[MAX_CLASSES];
 U32 vsc,psc,gsc,hsc,dsc;P psrv[7],psampler,pcbuf,layout,blend,depth,raster,pred;U32 topology,mask,stencil,nvp,nsc;I32 predValue;
 float factors[4];VIEWPORT_ vp[16];RECT_ sc[16];int uavActive;} SAVE_;
static void save_state(P ctx,SAVE_*s){
 memset(s,0,sizeof(*s));s->nvp=16;s->nsc=16;s->vsc=s->psc=s->gsc=s->hsc=s->dsc=MAX_CLASSES;
 V(ctx,89,void(CALL*)(P,U32,P*,P*))(ctx,8,s->rt,&s->dsv);
 V(ctx,90,void(CALL*)(P,U32,P*,P*,U32,U32,P*))(ctx,0,0,0,0,8,s->uav);
 for(U32 i=0;i<8;i++)if(s->uav[i])s->uavActive=1;
 V(ctx,76,void(CALL*)(P,P*,P*,U32*))(ctx,&s->vs,s->vsclass,&s->vsc);
 V(ctx,74,void(CALL*)(P,P*,P*,U32*))(ctx,&s->ps,s->psclass,&s->psc);
 V(ctx,82,void(CALL*)(P,P*,P*,U32*))(ctx,&s->gs,s->gsclass,&s->gsc);
 V(ctx,98,void(CALL*)(P,P*,P*,U32*))(ctx,&s->hs,s->hsclass,&s->hsc);
 V(ctx,102,void(CALL*)(P,P*,P*,U32*))(ctx,&s->ds,s->dsclass,&s->dsc);
 V(ctx,73,void(CALL*)(P,U32,U32,P*))(ctx,0,7,s->psrv);
 V(ctx,75,void(CALL*)(P,U32,U32,P*))(ctx,0,1,&s->psampler);
 V(ctx,77,void(CALL*)(P,U32,U32,P*))(ctx,0,1,&s->pcbuf);
 V(ctx,78,void(CALL*)(P,P*))(ctx,&s->layout);
 V(ctx,83,void(CALL*)(P,U32*))(ctx,&s->topology);
 V(ctx,91,void(CALL*)(P,P*,float*,U32*))(ctx,&s->blend,s->factors,&s->mask);
 V(ctx,92,void(CALL*)(P,P*,U32*))(ctx,&s->depth,&s->stencil);
 V(ctx,94,void(CALL*)(P,P*))(ctx,&s->raster);
 V(ctx,95,void(CALL*)(P,U32*,VIEWPORT_*))(ctx,&s->nvp,s->vp);
 V(ctx,96,void(CALL*)(P,U32*,RECT_*))(ctx,&s->nsc,s->sc);
 V(ctx,86,void(CALL*)(P,P*,I32*))(ctx,&s->pred,&s->predValue);
}
static void restore_state(P ctx,SAVE_*s,int changed){
 if(changed){
 /* Unbind all effect inputs (including depth at t2) before restoring DSV.
    Otherwise D3D11 may refuse to rebind an SRV-overlapping depth target. */
 P cleared[7]={0,0,0,0,0,0,0};V(ctx,8,void(CALL*)(P,U32,U32,P*))(ctx,0,7,cleared);
 V(ctx,33,void(CALL*)(P,U32,P*,P))(ctx,8,s->rt,s->dsv);
 V(ctx,11,void(CALL*)(P,P,P*,U32))(ctx,s->vs,s->vsclass,s->vsc);
 V(ctx,9,void(CALL*)(P,P,P*,U32))(ctx,s->ps,s->psclass,s->psc);
 V(ctx,23,void(CALL*)(P,P,P*,U32))(ctx,s->gs,s->gsclass,s->gsc);
 V(ctx,60,void(CALL*)(P,P,P*,U32))(ctx,s->hs,s->hsclass,s->hsc);
 V(ctx,64,void(CALL*)(P,P,P*,U32))(ctx,s->ds,s->dsclass,s->dsc);
 V(ctx,8,void(CALL*)(P,U32,U32,P*))(ctx,0,7,s->psrv);
 V(ctx,10,void(CALL*)(P,U32,U32,P*))(ctx,0,1,&s->psampler);
 V(ctx,16,void(CALL*)(P,U32,U32,P*))(ctx,0,1,&s->pcbuf);
 V(ctx,17,void(CALL*)(P,P))(ctx,s->layout);
 V(ctx,24,void(CALL*)(P,U32))(ctx,s->topology);
 V(ctx,35,void(CALL*)(P,P,float*,U32))(ctx,s->blend,s->factors,s->mask);
 V(ctx,36,void(CALL*)(P,P,U32))(ctx,s->depth,s->stencil);
 V(ctx,43,void(CALL*)(P,P))(ctx,s->raster);
 V(ctx,44,void(CALL*)(P,U32,VIEWPORT_*))(ctx,s->nvp,s->vp);
 V(ctx,45,void(CALL*)(P,U32,RECT_*))(ctx,s->nsc,s->sc);
 V(ctx,30,void(CALL*)(P,P,I32))(ctx,s->pred,s->predValue);
 }
 for(U32 i=0;i<8;i++){REL(s->rt[i]);REL(s->uav[i]);}
 REL(s->dsv);REL(s->vs);REL(s->ps);REL(s->gs);REL(s->hs);REL(s->ds);
 for(U32 i=0;i<MAX_CLASSES;i++){REL(s->vsclass[i]);REL(s->psclass[i]);REL(s->gsclass[i]);REL(s->hsclass[i]);REL(s->dsclass[i]);}
 for(U32 i=0;i<7;i++)REL(s->psrv[i]);
 REL(s->psampler);REL(s->pcbuf);REL(s->layout);REL(s->blend);REL(s->depth);REL(s->raster);REL(s->pred);
}
static int setup_depth_preview(void);

#include "camera_capture.inc"
#include "depth_capture.inc"

/* All passes use private render targets and only touch this bounded PS SRV range. */
static void render_pass(P target,P shader,P inputs[7],U32 width,U32 height){
 P empty[7]={0};
 V(g_ctx,8,void(CALL*)(P,U32,U32,P*))(g_ctx,0,7,empty);
 V(g_ctx,33,void(CALL*)(P,U32,P*,P))(g_ctx,1,&target,0);
 VIEWPORT_ viewport={0,0,(float)width,(float)height,0,1};
 V(g_ctx,44,void(CALL*)(P,U32,const VIEWPORT_*))(g_ctx,1,&viewport);
 V(g_ctx,9,void(CALL*)(P,P,P*,U32))(g_ctx,shader,0,0);
 V(g_ctx,8,void(CALL*)(P,U32,U32,P*))(g_ctx,0,7,inputs);
 g_internalDrawActive=1;
 V(g_ctx,13,void(CALL*)(P,U32,U32))(g_ctx,3,0);
 g_internalDrawActive=0;
}

static U32 mip_extent(U32 size,U32 mip){
 U32 extent=size>>mip;
 return extent?extent:1;
}

static void draw_fx(void){
 if(!g_back||!g_source||!g_ctx)return;
 U32 debug=g_menu&&g_advancedMenu?g_aoDebug:0;
 SAVE_ state;save_state(g_ctx,&state);
 if(state.uavActive||state.vsc>=MAX_CLASSES||state.psc>=MAX_CLASSES||
    state.gsc>=MAX_CLASSES||state.hsc>=MAX_CLASSES||state.dsc>=MAX_CLASSES){
  if(state.uavActive&&!g_loggedUav){g_loggedUav=1;log_msg("OUTPUT UAV ACTIVE; POST PROCESSING SKIPPED\r\n");}
  if(!state.uavActive&&!g_loggedClasses){g_loggedClasses=1;log_msg("SHADER CLASS STATE EXCEEDS SAVE LIMIT; POST PROCESSING SKIPPED\r\n");}
  set_ao_state(g_ao?AO_UNSAFE:AO_OFF);
  restore_state(g_ctx,&state,0);return;
 }
 U32 depthFound=0,depthLive=0,projectionOK=0,estimated=0,passes=0;
 U32 previousDepth=g_aoDepthIndex,previousBoundary=g_aoDepthBoundary;
 const char *previousReason=g_aoDepthReason;
 Projection_ projection={0};
 enum AO_STATE status=g_ao?AO_WAITING_DEPTH:AO_OFF;
 const int sdr=g_sceneFormat==28||g_sceneFormat==29||g_sceneFormat==87||g_sceneFormat==91;
 if(g_ao||debug){
  capture_depth_at_present();
  depthFound=setup_ao_depth_input()?1u:0u;
  depthLive=depthFound&&depth_source_live();
  if(depthLive){
   projectionOK=camera_get_projection(g_ctx,g_depthTexture[g_aoDepthIndex],
                  g_aoDepthFrame,g_aoDepthEpoch,&projection)?1u:0u;
   const DEPTH_REC *r=&g_depthRecords[g_aoDepthIndex];
   if(!projectionOK && capture_compat_shape(r)){
    estimated=projection_estimate_wd2(r->width,r->height,g_aoDepthClear,&projection);
    projectionOK=estimated;
   }
  }
  if(!sdr||(g_depthHookSessionChecked&&!g_depthHookSessionReady)||
     g_aoDepthStatus==DEPTH_UNSAFE||(depthFound&&!depthLive))status=AO_UNSAFE;
  else if(!depthFound)status=!g_depthHookSessionChecked?AO_REQUESTED:AO_WAITING_DEPTH;
  else if(!projectionOK)status=AO_WAITING_CAMERA;
  else if(debug==2||debug==3)status=AO_DEBUG;
  else if(!setup_ao_pipeline())status=g_aoSetupFailure;
  else {passes=1;status=debug?AO_DEBUG:estimated?AO_ACTIVE_ESTIMATE:AO_ACTIVE;}
 }
 U32 projectionStatus=projectionOK?(projection.reverseZ?2u:1u):0u;
 static const char *const cameraDetail[]={
  "NO MATRIX EVIDENCE", "READBACK PENDING", "INSUFFICIENT SAMPLES",
  "AMBIGUOUS MATRICES", "AWAITING AGREEMENT", "MATRIX AVAILABLE"
 };
 const char *detail=estimated?(projection.reverseZ?"ESTIMATED REVERSED Z":"ESTIMATED STANDARD Z"):
                    projectionStatus==2?"REVERSED Z":projectionStatus==1?"STANDARD Z":
                    depthLive?cameraDetail[g_cameraStatus]:"UNAVAILABLE";
 if(detail!=g_projectionDetail||previousDepth!=g_aoDepthIndex||
    previousBoundary!=g_aoDepthBoundary||previousReason!=g_aoDepthReason)g_dirty=1;
 g_projectionDetail=detail;
 /* The shader keeps unavailable diagnostic inputs distinct from normal output. */
 U32 diagnostic=debug!=0;
 if(!g_ao&&!diagnostic)status=AO_OFF;
 set_ao_state(status);
 if((status==AO_WAITING_DEPTH||status==AO_UNSAFE) &&
    g_aoReasonLogged!=g_aoDepthReason && g_aoLoggedState==status &&
    GetTickCount64()-g_lastAoReasonTick>=1000){
  g_lastAoReasonTick=GetTickCount64();
  g_aoReasonLogged=g_aoDepthReason;
  log_msg("AO DEPTH BLOCKER: ");log_msg(g_aoDepthReason);log_msg("\r\n");
 }
 if(!g_fx&&!passes&&!diagnostic){restore_state(g_ctx,&state,0);return;}

 CB_ settings={0};
 settings.invW=1.0f/g_width;settings.invH=1.0f/g_height;
 settings.sharp=g_values[0]*0.01f;settings.sat=g_values[1]*0.01f;
 settings.contrast=g_values[2]*0.01f;settings.bright=g_values[3]*0.01f;
 settings.gamma=g_values[4]*0.01f;settings.fx=(float)g_fx;
 settings.aoMode=diagnostic?(float)(debug+1):passes&&g_ao?1.0f:0.0f;
 settings.aoIntensity=g_aoStrength*0.01f;settings.aoRadius=(float)g_aoRadius;
 settings.aoQuality=(float)g_aoQuality;
 /* Estimated lens parameters are less reliable across silhouettes. Use the
    next stricter edge policy and a slightly shorter reach at the same strength. */
 if(estimated)settings.aoRadius*=0.85f;
 if(projectionOK){
  settings.depthB=projection.depthB;settings.depthA=projection.depthA;
  settings.invScaleX=1.0f/projection.scaleX;settings.invScaleY=1.0f/projection.scaleY;
  settings.offsetX=projection.offsetX;settings.offsetY=projection.offsetY;
 }
 P depthTex[7]={0};
 if(depthFound){
  const DEPTH_REC *r=&g_depthRecords[g_aoDepthIndex];
  settings.sampleCount=(float)r->msaa;
  settings.depthWidth=(float)r->width;settings.depthHeight=(float)r->height;
  settings.clearDepth=g_aoDepthClear;
  depthTex[r->msaa>1?3:2]=g_aoDepthSrv;
 }
 settings.hudGuard=(float)g_aoHudGuard;
 settings.contactBoost=g_aoContactBoost*0.01f;
 settings.edgeGuard=(float)(estimated&&g_aoEdgeGuard<2?g_aoEdgeGuard+1:g_aoEdgeGuard);
 settings.colorAlreadyLinear=(float)(g_sceneFormat==29||g_sceneFormat==91);
 settings.diagnosticInputReady=(float)(passes?2:depthFound?1:0);

 V(g_ctx,33,void(CALL*)(P,U32,P*,P))(g_ctx,0,0,0);
 V(g_ctx,47,void(CALL*)(P,P,P))(g_ctx,g_source,g_back);
 V(g_ctx,48,void(CALL*)(P,P,U32,const void*,const void*,U32,U32))(g_ctx,g_constants,0,0,&settings,0,0);
 V(g_ctx,35,void(CALL*)(P,P,float*,U32))(g_ctx,0,0,0xffffffffu);
 V(g_ctx,36,void(CALL*)(P,P,U32))(g_ctx,0,0);
 V(g_ctx,43,void(CALL*)(P,P))(g_ctx,0);
 V(g_ctx,45,void(CALL*)(P,U32,RECT_*))(g_ctx,0,0);
 V(g_ctx,17,void(CALL*)(P,P))(g_ctx,0);
 V(g_ctx,24,void(CALL*)(P,U32))(g_ctx,TRIANGLELIST);
 V(g_ctx,11,void(CALL*)(P,P,P*,U32))(g_ctx,g_vs,0,0);
 V(g_ctx,23,void(CALL*)(P,P,P*,U32))(g_ctx,0,0,0);
 V(g_ctx,60,void(CALL*)(P,P,P*,U32))(g_ctx,0,0,0);
 V(g_ctx,64,void(CALL*)(P,P,P*,U32))(g_ctx,0,0,0);
 V(g_ctx,10,void(CALL*)(P,U32,U32,P*))(g_ctx,0,1,&g_sampler);
 V(g_ctx,16,void(CALL*)(P,U32,U32,P*))(g_ctx,0,1,&g_constants);
 V(g_ctx,30,void(CALL*)(P,P,I32))(g_ctx,0,0);
 if(passes){
  render_pass(g_xeDepthRTV,g_xePreparePS,depthTex,g_aoOutputW,g_aoOutputH);
  for(U32 m=1;m<XE_DEPTH_MIP_LEVELS;m++){
   P mipInput[7]={0,0,0,0,0,g_xeMipSRV[m-1],0};
   render_pass(g_xeMipRTV[m],g_xeDownsamplePS,mipInput,
               mip_extent(g_aoOutputW,m),mip_extent(g_aoOutputH,m));
  }
  depthTex[5]=g_xeDepthSRV;
  render_pass(g_aoRTV,g_aoPS,depthTex,g_aoOutputW,g_aoOutputH);
  P rawVisibility[7]={0,0,0,0,g_aoOutputSRV,0,0};
  render_pass(g_aoDenoiseRTV,g_aoDenoisePS,rawVisibility,g_aoOutputW,g_aoOutputH);
  depthTex[4]=g_aoDenoiseSRV;
  depthTex[6]=g_aoOutputSRV;
 }
 depthTex[0]=g_srv;
 render_pass(g_fxOutputRTV,g_ps,depthTex,g_width,g_height);
 if(passes&&g_ao&&!diagnostic&&!g_aoPassesLogged){
  g_aoPassesLogged=1;
  log_msg(estimated?"AO PROJECTION: ESTIMATED CAMERA\r\n":"AO PROJECTION: RECOVERED CAMERA\r\n");
  log_msg("AO MAIN, DENOISE AND COMPOSITE DISPATCHED\r\n");
 }
 V(g_ctx,33,void(CALL*)(P,U32,P*,P))(g_ctx,0,0,0);
 V(g_ctx,47,void(CALL*)(P,P,P))(g_ctx,g_back,g_fxOutput);
 restore_state(g_ctx,&state,1);
 if(!g_loggedFX){g_loggedFX=1;log_msg("SHADER DRAW DISPATCHED\r\n");}
}
static void draw_overlay(void){
 if(!g_back||!g_ctx||!g_overlayPS||!g_uiSrv||!g_overlayBlend)return;
 SAVE_ s;save_state(g_ctx,&s);
 if(s.uavActive){restore_state(g_ctx,&s,0);return;}
 if(s.vsc>=MAX_CLASSES||s.psc>=MAX_CLASSES||s.gsc>=MAX_CLASSES||s.hsc>=MAX_CLASSES||s.dsc>=MAX_CLASSES){restore_state(g_ctx,&s,0);return;}
 if(g_dirty){make_menu();V(g_ctx,48,void(CALL*)(P,P,U32,const void*,const void*,U32,U32))(g_ctx,g_uiTex,0,0,g_menuPixels,MENU_W*4,0);}
 P rt=g_rtv, tex=g_uiSrv;
 V(g_ctx,33,void(CALL*)(P,U32,P*,P))(g_ctx,1,&rt,0);
 float blendFactors[4]={0,0,0,0};
 V(g_ctx,35,void(CALL*)(P,P,float*,U32))(g_ctx,g_overlayBlend,blendFactors,0xffffffffu);
 V(g_ctx,36,void(CALL*)(P,P,U32))(g_ctx,0,0);
 V(g_ctx,43,void(CALL*)(P,P))(g_ctx,0);
 VIEWPORT_ vp={0,0,(float)g_width,(float)g_height,0,1};
 V(g_ctx,44,void(CALL*)(P,U32,VIEWPORT_*))(g_ctx,1,&vp);
 V(g_ctx,45,void(CALL*)(P,U32,RECT_*))(g_ctx,0,0);
 V(g_ctx,17,void(CALL*)(P,P))(g_ctx,0);
 V(g_ctx,24,void(CALL*)(P,U32))(g_ctx,TRIANGLELIST);
 V(g_ctx,11,void(CALL*)(P,P,P*,U32))(g_ctx,g_vs,0,0);
 V(g_ctx,23,void(CALL*)(P,P,P*,U32))(g_ctx,0,0,0);
 V(g_ctx,60,void(CALL*)(P,P,P*,U32))(g_ctx,0,0,0);
 V(g_ctx,64,void(CALL*)(P,P,P*,U32))(g_ctx,0,0,0);
 V(g_ctx,9,void(CALL*)(P,P,P*,U32))(g_ctx,g_overlayPS,0,0);
 V(g_ctx,8,void(CALL*)(P,U32,U32,P*))(g_ctx,0,1,&tex);
 V(g_ctx,30,void(CALL*)(P,P,I32))(g_ctx,0,0);
 g_internalDrawActive=1;
 V(g_ctx,13,void(CALL*)(P,U32,U32))(g_ctx,3,0);
 g_internalDrawActive=0;
 restore_state(g_ctx,&s,1);
 if(!g_loggedOverlay){g_loggedOverlay=1;log_msg("DX11 OVERLAY DRAW DISPATCHED\r\n");}
}
static P current_preview_snapshot(void){
 if(g_previewIndex>=g_depthCount || g_aoDepthIndex!=g_previewIndex ||
    g_depthRecords[g_previewIndex].msaa!=1 || !depth_source_live())return 0;
 return g_aoDepthSrv;
}
/* Draw a diagnostic false-color depth texture in a small corner viewport.
   RED: conventional-Z contrast, GREEN: reverse-Z contrast, BLUE: mid-range detail.
   Partial XeGTAO core: selected resource is NOT proven scene depth. */
static int setup_depth_preview(void){
 if(!g_depthDone||!g_depthCount||g_previewIndex>=g_depthCount)return 0;
 if(!g_device||!g_back||!g_ctx||!g_rtv||!g_vs)return 0;
 if(!g_previewPS){
  P blob=0;if(!compile_shader_src(depth_preview_hlsl,"PSDepth","ps_5_0",&blob))return 0;
  P data=V(blob,3,P(CALL*)(P))(blob);SIZE_T_ len=V(blob,4,SIZE_T_(CALL*)(P))(blob);
  HRESULT_ hr=dev_ps(g_device,data,len,&g_previewPS);REL(blob);
  if(!SUCCEEDED_(hr)){log_hex("ERROR: CreateDepthPreviewPixelShader",(U32)hr);return 0;}
 }
 if(!g_previewCB){
  BUFFER_DESC bd;memset(&bd,0,sizeof(bd));bd.ByteWidth=sizeof(PREVIEW_CB_);bd.BindFlags=4;
  HRESULT_ hr=dev_buf(g_device,&bd,&g_previewCB);
  if(!SUCCEEDED_(hr)){log_hex("ERROR: CreateDepthPreviewConstants",(U32)hr);return 0;}
 }
 if(current_preview_snapshot())return 1;
 if(g_previewLoadedIndex!=g_previewIndex){REL(g_previewSrv);g_previewLoadedIndex=0xffffffffu;}
 if(!g_previewSrv){
  DEPTH_REC *r=&g_depthRecords[g_previewIndex];
  U32 typedFormat=capture_srv_format(r->format);
  if(!typedFormat || !(r->bindFlags&BIND_SRV) || r->msaa!=1 || !g_depthTexture[g_previewIndex]){
   if(!g_previewFailReported){g_previewFailReported=1;log_msg("DEPTH PREVIEW FORMAT UNSUPPORTED OR RESOURCE MISSING\r\n");}
   return 0;
  }
  HRESULT_ hr=dev_depth_srv(g_device,g_depthTexture[g_previewIndex],typedFormat,1,&g_previewSrv);
  if(!SUCCEEDED_(hr)){
   if(!g_previewFailReported){g_previewFailReported=1;log_hex("ERROR: CreateDepthPreviewSRV",(U32)hr);}
   return 0;
  }
  g_previewLoadedIndex=g_previewIndex;g_previewFailReported=0;
  log_hex("DEPTH PREVIEW SRV READY FOR CANDIDATE",g_previewIndex);
 }
 return 1;
}
static void draw_depth_preview(void){
 if(!g_previewOn||!setup_depth_preview())return;
 SAVE_ s;save_state(g_ctx,&s);
 if(s.uavActive||s.vsc>=MAX_CLASSES||s.psc>=MAX_CLASSES||s.gsc>=MAX_CLASSES||s.hsc>=MAX_CLASSES||s.dsc>=MAX_CLASSES){restore_state(g_ctx,&s,0);return;}
 PREVIEW_CB_ params={(float)g_previewCenter/100.0f,(float)g_previewWidth/100.0f,0.1f,1000.0f,g_previewMode,(float)g_previewFov,{0,0}};
 V(g_ctx,48,void(CALL*)(P,P,U32,const void*,const void*,U32,U32))(g_ctx,g_previewCB,0,0,&params,0,0);
 P snapshot=current_preview_snapshot();
 P rt=g_rtv,texture=snapshot?snapshot:g_previewSrv,previewConstants=g_previewCB;
 V(g_ctx,33,void(CALL*)(P,U32,P*,P))(g_ctx,1,&rt,0); /* Unbind any saved DSV before sampling. */
 V(g_ctx,35,void(CALL*)(P,P,float*,U32))(g_ctx,0,0,0xffffffffu);
 V(g_ctx,36,void(CALL*)(P,P,U32))(g_ctx,0,0);
 V(g_ctx,43,void(CALL*)(P,P))(g_ctx,0);
 float pw=g_width>1100?480.0f:240.0f;
 float ph=pw*9.0f/16.0f;
 VIEWPORT_ vp={(float)g_width-pw-30.0f,40.0f,pw,ph,0,1};
 V(g_ctx,44,void(CALL*)(P,U32,VIEWPORT_*))(g_ctx,1,&vp);
 V(g_ctx,45,void(CALL*)(P,U32,RECT_*))(g_ctx,0,0);
 V(g_ctx,17,void(CALL*)(P,P))(g_ctx,0);
 V(g_ctx,24,void(CALL*)(P,U32))(g_ctx,TRIANGLELIST);
 V(g_ctx,11,void(CALL*)(P,P,P*,U32))(g_ctx,g_vs,0,0);
 V(g_ctx,23,void(CALL*)(P,P,P*,U32))(g_ctx,0,0,0);
 V(g_ctx,60,void(CALL*)(P,P,P*,U32))(g_ctx,0,0,0);
 V(g_ctx,64,void(CALL*)(P,P,P*,U32))(g_ctx,0,0,0);
 V(g_ctx,9,void(CALL*)(P,P,P*,U32))(g_ctx,g_previewPS,0,0);
 V(g_ctx,8,void(CALL*)(P,U32,U32,P*))(g_ctx,0,1,&texture);
 V(g_ctx,16,void(CALL*)(P,U32,U32,P*))(g_ctx,0,1,&previewConstants);
 V(g_ctx,30,void(CALL*)(P,P,I32))(g_ctx,0,0);
 g_internalDrawActive=1;
 V(g_ctx,13,void(CALL*)(P,U32,U32))(g_ctx,3,0);
 g_internalDrawActive=0;
 restore_state(g_ctx,&s,1);
 if(!g_previewDrawLogged){g_previewDrawLogged=1;log_msg(snapshot?"DEPTH PREVIEW: CURRENT AO SNAPSHOT\r\n":"DEPTH PREVIEW: LIVE DEBUG RESOURCE\r\n");log_hex("DEPTH PREVIEW MODE",g_previewMode);}
}
static int focused(P sc){
 SWAP_DESC d;memset(&d,0,sizeof(d));
 if(!SUCCEEDED_(V(sc,12,HRESULT_(CALL*)(P,SWAP_DESC*))(sc,&d)))return 0;
 if(!IsWindow(d.OutputWindow))return 0;
 P foreground=GetForegroundWindow();return foreground==d.OutputWindow||
 (GetAncestor(foreground,2)==GetAncestor(d.OutputWindow,2));
}
static HRESULT_ CALL resize_hook(P sc,U32 count,U32 w,U32 h,U32 fmt,U32 flags);
static int patch(P*slot,P replacement);
static int ensure_resize_hook(P sc){
 if(g_resizeHooked)return 1;
 P* vt=*(P**)sc;
 if(!vt||!g_oldResize)return 0;
 if(vt[13]==(P)resize_hook){g_resizeHooked=1;return 1;}
 if(vt[13]!=(P)g_oldResize){log_msg("WARNING: RESIZE SLOT MODIFIED BY ANOTHER MODULE; NO EFFECTS\r\n");return 0;}
 if(!patch(&vt[13],(P)resize_hook)){log_msg("ERROR: RESIZE HOOK FAILED; NO EFFECTS\r\n");return 0;}
 g_resizeHooked=1;
 log_msg("RESIZE HOOK INSTALLED AFTER STARTUP\r\n");
 return 1;
}
static int ensure_depth_hooks(void);
static void depth_summary(void);
static void run_dispatch_self_test(void);
static void monitor_depth_hook(P sc);
static HRESULT_ CALL present_hook(P sc,U32 interval,U32 flags){
 if((flags&1u)||__sync_lock_test_and_set(&g_presentBusy,1))return g_oldPresent(sc,interval,flags);
 while(__sync_lock_test_and_set(&g_surfaceBusy,1))Sleep(1);
 if(g_resizing){
  __sync_lock_release(&g_surfaceBusy);
  HRESULT_ passthrough=g_oldPresent(sc,interval,flags);
  __sync_lock_release(&g_presentBusy);
  return passthrough;
 }
 if(!g_firstPresent){g_firstPresent=1;log_msg("PRESENT CALLBACK ENTERED; EARLY FRAMES PASSTHROUGH\r\n");}
 if(g_frame>=g_passthroughFrames&&(!g_target||g_target==sc)){
  if(focused(sc)){
   if(!g_seen){g_seen=1;g_target=sc;log_msg("GAME PRESENT OBSERVED AFTER PASSTHROUGH\r\n");}
   if(!g_hadFocus){prime_keyboard();g_hadFocus=1;}
   keyboard();
   if(!g_ao&&!g_aoDebug&&g_aoDepthIndex!=CAPTURE_INVALID){
    capture_release_selected();g_projectionDetail="UNAVAILABLE";g_dirty=1;
   }
   if(g_menu||g_fx||g_previewOn||g_ao){
    U64 now=GetTickCount64();
    if(now>=g_nextInitAttempt){
     if(ensure_resize_hook(sc)&&setup_overlay(sc)){
      g_nextInitAttempt=0;
      if(!g_loggedMenuReady){g_loggedMenuReady=1;log_msg("DX11 MENU PIPELINE READY\r\n");}
      if(!g_depthDone&&!g_depthEnabled&&
         (g_aoDebug||(g_ao&&g_aoAutoProbeAfter&&g_frame>=g_aoAutoProbeAfter))){
       g_depthEnabled=1;clear_depth_probe();g_depthStartFrame=g_frame;g_aoAutoProbeAfter=0;
       log_msg("AO DEPTH OBSERVATION STARTED\r\n");
      }
      if(g_depthEnabled&&!g_depthDone&&!g_depthHookSessionChecked){
       g_depthHookSessionChecked=1;
       g_depthHookSessionReady=ensure_depth_hooks()?1:0;
       if(!g_depthHookSessionReady){
        g_depthHookWarned=1;
        log_msg("DEPTH OBSERVER UNAVAILABLE FOR THIS CAPTURE\r\n");
       }
      }
      if(g_depthEnabled&&!g_depthDone&&g_depthHookSessionReady&&!g_selfTestExecuted)
       run_dispatch_self_test();
      if(g_fx||g_ao||g_aoDebug){
       if(now>=g_nextFxAttempt){
        if(setup_fx()){draw_fx();g_nextFxAttempt=0;}
        else {
         g_nextFxAttempt=now+5000;
         if(g_ao)set_ao_state(g_fxSetupFailure);
        }
       }
      }
      if(g_previewOn)draw_depth_preview();
      if(g_menu)draw_overlay();
     }else{
      g_nextInitAttempt=now+5000;
      if(g_ao)set_ao_state(AO_PIPELINE_FAILURE);
      log_msg("DX11 MENU SETUP UNAVAILABLE; RETRY IN 5 SECONDS\r\n");
     }
    }
   }
  }else if(g_target==sc){
   g_hadFocus=0;
   if(g_ao)set_ao_state(AO_WAITING_DEPTH);
  }
 }
 if(sc==g_target&&g_depthEnabled&&!g_depthDone){monitor_depth_hook(sc);depth_summary();}
 __sync_lock_release(&g_surfaceBusy);
 HRESULT_ hr=g_oldPresent(sc,interval,flags);
 if(!g_firstReturned){g_firstReturned=1;log_msg("ORIGINAL PRESENT RETURNED TO HOOK\r\n");}
 /* Advance the render epoch even if the target Present failed or was occluded.
    Frames from other swapchains and DXGI_PRESENT_TEST cannot age this stream. */
 if((!g_target||g_target==sc)&&g_frame<0xffffffffffffffffULL)++g_frame;
 __sync_lock_release(&g_presentBusy);
 return hr;
}
static HRESULT_ CALL resize_hook(P sc,U32 count,U32 w,U32 h,U32 fmt,U32 flags){
 while(__sync_lock_test_and_set(&g_surfaceBusy,1))Sleep(1);
 int ownsSurface=sc==g_backOwner;
 if(ownsSurface){
  __sync_add_and_fetch(&g_resizing,1);
  if(g_depthEnabled&&!g_depthDone)++g_resizesWhileCapturing;
  drop_back();g_depthEnabled=0;g_depthDone=0;g_nextInitAttempt=0;g_nextFxAttempt=0;
  g_projectionDetail="UNAVAILABLE";g_dirty=1;g_aoAutoProbeAfter=g_ao?g_frame+1:0;
  set_ao_state(g_ao?AO_REQUESTED:AO_OFF);
  log_msg("RESIZE BUFFERS: BACKBUFFER, DEPTH AND PROJECTION INVALIDATED\r\n");
 }
 __sync_lock_release(&g_surfaceBusy);
 HRESULT_ hr=g_oldResize(sc,count,w,h,fmt,flags);
 if(ownsSurface)__sync_sub_and_fetch(&g_resizing,1);
 return hr;
}
/* Depth observation retains the game's existing private immediate-context hooks. */
#define DEPTH_PROBE_FRAMES 120
static U32 g_rgCount=0,g_rgProbeCalls=0;
static void (CALL *g_originalPSResources)(P,U32,U32,P*)=0;
static volatile U32 g_drawTotals[7]={0}; /* game-context calls outside Present */
static volatile U32 g_drawRawTotals[7]={0}; /* all calls that reached patched method */
static volatile U32 g_drawInternalTotals[7]={0}; /* mod's own draws via same vtable */
static volatile U32 g_drawInPresentTotals[7]={0};
static volatile U32 g_drawForeignContextTotals[7]={0};
static volatile U32 g_cmdListCount=0,g_cmdListRaw=0,g_cmdListForeign=0,g_cmdListInPresent=0;
static U32 g_drawHookSlotPass=0;
static void (CALL *g_originalDraw)(P,U32,U32)=0;
static void (CALL *g_originalDrawIndexed)(P,U32,U32,I32)=0;
static void (CALL *g_originalDrawIndexedInstanced)(P,U32,U32,U32,I32,U32)=0;
static void (CALL *g_originalDrawInstanced)(P,U32,U32,U32,U32)=0;
static void (CALL *g_originalDrawAuto)(P)=0;
static void (CALL *g_originalDrawIndexedInstancedIndirect)(P,P,U32)=0;
static void (CALL *g_originalDrawInstancedIndirect)(P,P,U32)=0;
static void (CALL *g_originalExecuteCommandList)(P,P,BOOL_)=0;
static void clear_depth_probe(void){
 /* Preview references must be dropped before candidate identities are reset. */
 release_depth_preview_resources();
 memset(g_depthRecords,0,sizeof(g_depthRecords));
 memset(g_rgRecords,0,sizeof(g_rgRecords));g_rgCount=0;g_rgProbeCalls=0;
 g_depthCount=0;g_depthActive=0xffffffffu;
 for(U32 j=0;j<7;j++){
  g_drawTotals[j]=0;g_drawRawTotals[j]=0;
  g_drawInternalTotals[j]=0;g_drawInPresentTotals[j]=0;
  g_drawForeignContextTotals[j]=0;
 }
 g_rawOMCalls=0;g_presentOMCalls=0;g_foreignOMCalls=0;
 g_cmdListCount=0;g_cmdListRaw=0;g_cmdListForeign=0;g_cmdListInPresent=0;
 g_selfTestExecuted=0;g_selfTestPassed=0;g_selfTestRawBefore=0;g_selfTestRawAfter=0;
 g_depthDone=0;g_depthStartFrame=g_frame;g_depthHookWarned=0;
 g_depthHookSessionChecked=0;g_depthHookSessionReady=0;
 g_hookLossObserved=0;g_unfocusedPresents=0;g_resizesWhileCapturing=0;g_monitorSamples=0;
}
/* Diagnostic counters do not drive depth eligibility or ranking. */
static void depth_draw(P ctx,U32 kind,U32 geometry,U32 fullscreen){
 if(!g_depthEnabled && !g_depthDone)return;
 if(!g_depthDone)__sync_fetch_and_add(&g_drawRawTotals[kind],1);
 if(ctx!=g_ctx){
  if(!g_depthDone)__sync_fetch_and_add(&g_drawForeignContextTotals[kind],1);
  return;
 }
 if(g_internalDrawActive){
  if(!g_depthDone)__sync_fetch_and_add(&g_drawInternalTotals[kind],1);
  return;
 }
 if(g_presentBusy){
  if(!g_depthDone)__sync_fetch_and_add(&g_drawInPresentTotals[kind],1);
  return;
 }
 if(!g_depthDone)__sync_fetch_and_add(&g_drawTotals[kind],1);
 capture_observe_draw(ctx,geometry,fullscreen);
}
static void CALL depth_draw_nonindexed(P ctx,U32 vertices,U32 start){
 depth_draw(ctx,1,vertices>6,vertices>=3 && vertices<=6);
 if(g_originalDraw)g_originalDraw(ctx,vertices,start);
}
/* Harmless diagnostic: issue one zero-vertex draw through the *game context's*
   public COM vtable. This should generate no geometry or visible output.
   It distinguishes a patched slot from a working dispatch path. One shot
   per explicit depth-probe session; never executed during normal play. */
static void run_dispatch_self_test(void){
 if(g_selfTestExecuted || !g_ctx || !g_depthEnabled || g_depthDone || !g_depthHooked)return;
 g_selfTestExecuted=1;
 P*vt=*(P**)g_ctx;
 if(!vt || vt[13]!=(P)depth_draw_nonindexed){
  log_msg("DRAW SELF-TEST FAILED: COM SLOT 13 NOT OUR HOOK\r\n");
  return;
 }
 g_selfTestRawBefore=g_drawRawTotals[1];
 g_internalDrawActive=1;
 V(g_ctx,13,void(CALL*)(P,U32,U32))(g_ctx,0,0); /* Draw(0,0) produces no primitives */
 g_internalDrawActive=0;
 g_selfTestRawAfter=g_drawRawTotals[1];
 if(g_selfTestRawAfter>g_selfTestRawBefore){
  g_selfTestPassed=1;
  log_msg("DRAW SELF-TEST PASSED: DIRECT COM CALL REACHED DRAW HOOK\r\n");
 }else{
  log_msg("DRAW SELF-TEST FAILED: DIRECT COM CALL DID NOT REACH HOOK\r\n");
 }
}
static void CALL depth_draw_indexed(P ctx,U32 indices,U32 start,I32 base){
 depth_draw(ctx,0,indices>=3,indices>=3 && indices<=6); if(g_originalDrawIndexed)g_originalDrawIndexed(ctx,indices,start,base);
}
static void CALL depth_draw_indexed_instanced(P ctx,U32 indices,U32 instances,U32 start,I32 base,U32 startInstance){
 depth_draw(ctx,2,indices>=3 && instances!=0,0);
 if(g_originalDrawIndexedInstanced)g_originalDrawIndexedInstanced(ctx,indices,instances,start,base,startInstance);
}
static void CALL depth_draw_instanced(P ctx,U32 vertices,U32 instances,U32 start,U32 startInstance){
 depth_draw(ctx,3,vertices>=3 && instances!=0,0);
 if(g_originalDrawInstanced)g_originalDrawInstanced(ctx,vertices,instances,start,startInstance);
}
static void CALL depth_draw_auto(P ctx){
 depth_draw(ctx,4,1,0); if(g_originalDrawAuto)g_originalDrawAuto(ctx);
}
static void CALL depth_draw_indexed_indirect(P ctx,P args,U32 offset){
 depth_draw(ctx,5,1,0);
 if(g_originalDrawIndexedInstancedIndirect)g_originalDrawIndexedInstancedIndirect(ctx,args,offset);
}
static void CALL depth_draw_indirect(P ctx,P args,U32 offset){
 depth_draw(ctx,6,1,0);
 if(g_originalDrawInstancedIndirect)g_originalDrawInstancedIndirect(ctx,args,offset);
}
static void CALL depth_execute_command_list(P ctx,P list,BOOL_ restore){
 if(g_depthEnabled && !g_depthDone){
  __sync_fetch_and_add(&g_cmdListRaw,1);
  if(ctx!=g_ctx)__sync_fetch_and_add(&g_cmdListForeign,1);
  else if(g_presentBusy)__sync_fetch_and_add(&g_cmdListInPresent,1);
  else __sync_fetch_and_add(&g_cmdListCount,1);
 }
 if(ctx==g_ctx && !g_presentBusy && (g_depthEnabled||g_depthDone))capture_opaque_commands();
 if(g_originalExecuteCommandList)g_originalExecuteCommandList(ctx,list,restore);
}
/* PSSetShaderResources observer: detect candidate near-screen two-channel textures.
   Formats and sizes CANNOT establish whether contents are motion vectors. */
static void CALL probe_ps_resources(P ctx,U32 start,U32 count,P*views){
 if(g_originalPSResources)g_originalPSResources(ctx,start,count,views);
 capture_note_ps_inputs(ctx,start,count);
 if(ctx!=g_ctx || !g_depthEnabled || g_depthDone || g_presentBusy || !views || !count)return;
 if(g_rgProbeCalls>=256)return;
 if(__sync_fetch_and_add(&g_rgProbeCalls,1)>=256)return;
 U32 limit=count<2?count:2;
 for(U32 i=0;i<limit;i++){
  P srv=views[i];if(!srv)continue;
  P r=0,t=0;V(srv,7,void(CALL*)(P,P*))(srv,&r);
  if(r && SUCCEEDED_(V(r,0,HRESULT_(CALL*)(P,const GUID_*,P*))(r,&IID_TEXTURE2D,&t)) && t){
   TEX2D_DESC d;memset(&d,0,sizeof(d));V(t,10,void(CALL*)(P,TEX2D_DESC*))(t,&d);
   /* Only likely RG vector encodings; shader input identity is NOT established. */
   U32 potentialRG=d.Format==16||d.Format==34||d.Format==35||d.Format==37||d.Format==49||d.Format==50||d.Format==52;
   if(potentialRG && d.Width>=g_width/2 && d.Width<=g_width*2 && d.Height>=g_height/2 && d.Height<=g_height*2){
    U32 n=0;for(;n<g_rgCount;n++)if(g_rgRecords[n].resourceKey==r)break;
    if(n==g_rgCount&&n<MAX_RG_CANDIDATES){
     DEPTH_REC*rec=&g_rgRecords[n];rec->resourceKey=r;
     rec->width=d.Width;rec->height=d.Height;rec->format=d.Format;
     rec->bindFlags=d.BindFlags;rec->msaa=d.SampleDesc.Count;g_rgCount++;
    }
    if(n<g_rgCount)__sync_fetch_and_add(&g_rgRecords[n].bindings,1);
   }
  }
  REL(t);REL(r);
 }
}
/* Do not modify the shared D3D11 COM function table. The first 22 dev
   builds patched common method slots and the game restored the Draw slots
   during the first frame. This isolated table is an experimental attempt
   to avoid touching the shared vtable. */
/* The base pointer can be shared with a newer interface. Preserve each
   officially defined vtable slot exposed on that exact interface pointer. */
static U32 context_vtable_slots(P ctx){
 static const struct { GUID_ iid; U32 slots; } versions[]={
  {{0x917600da,0xf58c,0x4c33,{0x98,0xd8,0x3e,0x15,0xb3,0x90,0xfa,0x24}},149},
  {{0xb4e3c01d,0xe79e,0x4637,{0x91,0xb2,0x51,0x0e,0x9f,0x4c,0x9b,0x8f}},147},
  {{0x420d5b32,0xb90c,0x4da4,{0xbe,0xf0,0x35,0x9f,0x6a,0x24,0xa8,0x3a}},144},
  {{0xbb2c6faa,0xb5fb,0x4082,{0x8e,0x6b,0x38,0x8b,0x8c,0xfa,0x90,0xe1}},134},
 };
 for(U32 i=0;i<sizeof(versions)/sizeof(versions[0]);i++){
  P extended=0;
  if(SUCCEEDED_(V(ctx,0,HRESULT_(CALL*)(P,const GUID_*,P*))(ctx,&versions[i].iid,&extended))){
   int same=extended==ctx;
   REL(extended);
   if(same)return versions[i].slots;
  }
 }
 return D3D11_BASE_CONTEXT_SLOTS;
}
static int ensure_depth_hooks(void){
 if(!g_ctx)return 0;
 P*shared=*(P**)g_ctx;
 if(!shared)return 0;
 if(g_privateVtablePublished){
  if(g_ctx!=g_depthPatchedContext || shared!=g_privateContextVtable){
   log_msg("PRIVATE CONTEXT VTABLE IS NO LONGER ATTACHED; NO AUTO-REPUBLISH\r\n");
   return 0;
  }
  U32 valid=(shared[12]==(P)depth_draw_indexed && shared[13]==(P)depth_draw_nonindexed &&
   shared[33]==(P)depth_om && shared[34]==(P)depth_omuav && shared[53]==(P)depth_clear);
  if(!valid)log_msg("PRIVATE CONTEXT HOOK SLOTS CHANGED; NO REPLACEMENT\r\n");
  return valid?1:0;
 }
 U32 slots=context_vtable_slots(g_ctx);
 memcpy(g_privateContextVtable,shared,slots*sizeof(P));
 if(!capture_attach_hooks(shared,g_privateContextVtable,slots))return 0;
 g_originalDrawIndexed=(void*)shared[12];
 g_originalDraw=(void*)shared[13];
 g_originalPSResources=(void*)shared[8];
 g_originalDrawIndexedInstanced=(void*)shared[20];
 g_originalDrawInstanced=(void*)shared[21];
 g_originalDrawAuto=(void*)shared[38];
 g_originalDrawIndexedInstancedIndirect=(void*)shared[39];
 g_originalDrawInstancedIndirect=(void*)shared[40];
 g_originalExecuteCommandList=(void*)shared[58];
 g_privateContextVtable[12]=(P)depth_draw_indexed;
 g_privateContextVtable[13]=(P)depth_draw_nonindexed;
 g_privateContextVtable[20]=(P)depth_draw_indexed_instanced;
 g_privateContextVtable[21]=(P)depth_draw_instanced;
 g_privateContextVtable[38]=(P)depth_draw_auto;
 g_privateContextVtable[39]=(P)depth_draw_indexed_indirect;
 g_privateContextVtable[40]=(P)depth_draw_indirect;
 g_privateContextVtable[58]=(P)depth_execute_command_list;
 g_privateContextVtable[8]=(P)probe_ps_resources;
 /* Publish the private table atomically on this exact interface pointer.
    Fail closed if another component changed the interface in the meantime. */
 U32 oldProt=0;
 if(!VirtualProtect(g_ctx,sizeof(P),0x04,&oldProt)){
  log_msg("PRIVATE VTABLE INSTALL FAILED: OBJECT PROTECTION\r\n");return 0;
 }
 int published=__sync_bool_compare_and_swap((P*)g_ctx,(P)shared,(P)g_privateContextVtable);
 U32 ignore=0;VirtualProtect(g_ctx,sizeof(P),oldProt,&ignore);
 if(!published){
  log_msg("PRIVATE VTABLE INSTALL ABORTED: CONTEXT TABLE CHANGED\r\n");return 0;
 }
 g_sharedContextVtable=shared;
 g_depthPatchedTable=g_privateContextVtable;
 g_depthPatchedContext=g_ctx;
 g_privateVtablePublished=1;
 g_depthHooked=1;
 g_drawHookSlotPass=1;
 log_hex("PRIVATE D3D11 CONTEXT VTABLE ATTACHED, SLOTS",slots);
 log_msg("DRAW AND RESOURCE HOOKS ISOLATED TO GAME CONTEXT INSTANCE\r\n");
 return 1;
}
static void monitor_depth_hook(P sc){
 if(!g_ctx || !g_target || sc!=g_target || !g_depthHookSessionReady || !g_depthHooked)return;
 ++g_monitorSamples;
 if(!focused(sc))++g_unfocusedPresents;
 P*vt=*(P**)g_ctx;
 if(g_hookLossObserved)return;
 if(vt==g_depthPatchedTable && g_ctx==g_depthPatchedContext && vt[13]==(P)depth_draw_nonindexed)return;
 g_hookLossObserved=1;
 log_msg("DRAW HOOK FIRST LOSS DETECTED DURING CAPTURE\r\n");
 log_hex("FIRST LOSS FRAME OFFSET",(U32)(g_frame-g_depthStartFrame));
 log_hex("FIRST LOSS GAME IN FOREGROUND",focused(sc)?1:0);
 log_hex("FIRST LOSS RESIZE COUNT",g_resizesWhileCapturing);
 log_hex("FIRST LOSS PRIVATE VTABLE STILL ATTACHED",vt==g_privateContextVtable?1:0);
 log_hex("FIRST LOSS DRAW SLOT RESTORED ORIGINAL",vt[13]==(P)g_originalDraw?1:0);
 log_hex("FIRST LOSS DRAW INDEXED SLOT STILL HOOKED",vt[12]==(P)depth_draw_indexed?1:0);
 log_hex("FIRST LOSS OM SLOT STILL HOOKED",vt[33]==(P)depth_om?1:0);
 log_hex("FIRST LOSS PS-SRV SLOT STILL HOOKED",vt[8]==(P)probe_ps_resources?1:0);
}
static void depth_summary(void){
 if(!g_depthEnabled || g_depthDone || g_frame<g_depthStartFrame+DEPTH_PROBE_FRAMES)return;
 g_depthDone=1;g_dirty=1;
 if(g_ctx){
  P*active=*(P**)g_ctx;
  U32 sameTable=(active && active==g_depthPatchedTable && g_ctx==g_depthPatchedContext)?1:0;
  U32 activeDraw=(sameTable && active[13]==(P)depth_draw_nonindexed)?1:0;
  log_hex("DRAW HOOK ACTIVE AT CAPTURE END",activeDraw);
  log_hex("DEPTH CONTEXT VTABLE IDENTITY STABLE",sameTable);
  log_hex("PRIVATE VTABLE ATTACHED AT CAPTURE END",active==g_privateContextVtable?1:0);
  if(sameTable && !activeDraw){
   if(active[13]==(P)g_originalDraw)log_msg("DRAW SLOT RESTORED TO ORIGINAL DURING CAPTURE\r\n");
   else log_msg("DRAW SLOT CHANGED TO UNRECOGNIZED CALLBACK DURING CAPTURE\r\n");
  }
  if(!sameTable)log_msg("DRAW HOOK TABLE OR CONTEXT CHANGED DURING CAPTURE\r\n");
  if(g_depthHookSessionReady && !activeDraw)log_msg("DEPTH HOOK LOST DURING CAPTURE; DATA IS INCOMPLETE\r\n");
 }
 log_hex("DEPTH OBSERVER INITIALIZED FOR CAPTURE",g_depthHookSessionReady);
 log_hex("PRIVATE VTABLE PUBLISHED",g_privateVtablePublished);
 log_hex("CAPTURE MONITOR SAMPLED PRESENTS",g_monitorSamples);
 log_hex("CAPTURE UNFOCUSED PRESENT SAMPLES",g_unfocusedPresents);
 log_hex("CAPTURE RESIZE EVENTS",g_resizesWhileCapturing);
 log_hex("DRAW HOOK LOSS OBSERVED BEFORE CAPTURE END",g_hookLossObserved);
 log_msg("DEPTH PROBE COMPLETE (120 PRESENT FRAMES; 7 DRAW TYPES + COMMAND LISTS)\r\n");
 log_hex("DEPTH CANDIDATE COUNT",g_depthCount);
 U32 bestPreview=0xffffffffu;U64 previewPixels=0;U32 bestPreviewBinds=0;
 for(U32 i=0;i<g_depthCount;i++){
  const DEPTH_REC*r=&g_depthRecords[i];
  log_hex("DEPTH CANDIDATE INDEX",i);
  log_hex("DEPTH WIDTH",r->width);log_hex("DEPTH HEIGHT",r->height);
  log_hex("DEPTH FORMAT",r->format);log_hex("DEPTH BIND FLAGS",r->bindFlags);
  log_hex("DEPTH SAMPLE COUNT",r->msaa);
  log_hex("DEPTH DRAW CALLS",r->draws);
  log_hex("DEPTH CLEAR COUNT",r->clearCount);
  log_hex("DEPTH FULL VIEWPORT DRAWS",r->fullViewportDraws);
  log_hex("DEPTH PARTIAL VIEWPORT DRAWS",r->partialViewportDraws);
  log_hex("DEPTH DRAWS SINCE LAST CLEAR",r->drawsSinceClear);
  if(capture_compat_shape(r)){
   log_hex("AO COMPATIBLE DEPTH HAS CURRENT FULL WRITE",
           r->lastDepthClearFrame==g_frame && r->compatWriteSerial>r->lastDepthClearSerial);
   log_hex("AO DEPTH BLOCK FLAGS (1 CLEAR, 2 PARTIAL, 4 COPY, 8 DISCARD/CLEARVIEW)",r->compatInvalid);
   log_hex("AO DEPTH EPOCH EVENTS",r->compatSeenReasons);
   U32 clearBits=0;memcpy(&clearBits,&r->lastClearDepth,sizeof(clearBits));
   log_hex("AO DEPTH CLEAR FLOAT BITS",clearBits);
  }
  log_hex("DEPTH PREVIEW ELIGIBLE",eligible_preview(i));
  if(eligible_preview(i)){
   U64 pixels=(U64)r->width*(U64)r->height;
   if(pixels>previewPixels || (pixels==previewPixels && r->bindings>bestPreviewBinds)){
    bestPreview=i;previewPixels=pixels;bestPreviewBinds=r->bindings;
   }
  }
  log_msg((r->bindFlags&BIND_SRV)?"DEPTH RESOURCE HAS SRV BIND FLAG\r\n":"DEPTH RESOURCE NOT SRV-BINDABLE\r\n");
 }
 if(bestPreview!=0xffffffffu){
  g_previewIndex=bestPreview;
  log_hex("DEPTH PREVIEW AUTO-SELECT LARGEST ELIGIBLE CANDIDATE (NOT VALIDATED)",bestPreview);
 }
 const char* names[7]={"DRAW INDEXED", "DRAW", "DRAW INDEXED INSTANCED", "DRAW INSTANCED", "DRAW AUTO", "DRAW INDEXED INDIRECT", "DRAW INDIRECT"};
 U32 allDraws=0;
 for(U32 j=0;j<7;j++){log_hex(names[j],g_drawTotals[j]);allDraws+=g_drawTotals[j];}
 U32 allRaw=0,allOwn=0,allPresent=0,allForeign=0;
 for(U32 j=0;j<7;j++){
  allRaw+=g_drawRawTotals[j];allOwn+=g_drawInternalTotals[j];
  allPresent+=g_drawInPresentTotals[j];allForeign+=g_drawForeignContextTotals[j];
 }
 log_hex("DRAW SELF-TEST EXECUTED",g_selfTestExecuted);
 log_hex("DRAW SELF-TEST PASSED",g_selfTestPassed);
 log_hex("DRAW SELF-TEST RAW BEFORE",g_selfTestRawBefore);
 log_hex("DRAW SELF-TEST RAW AFTER",g_selfTestRawAfter);
 log_hex("DRAW HOOK RAW CALLS (ALL CONTEXTS)",allRaw);
 log_hex("DRAW HOOK MOD OWN DRAW CALLS",allOwn);
 log_hex("DRAW HOOK OTHER PRESENT CALLS",allPresent);
 log_hex("DRAW HOOK FOREIGN CONTEXT CALLS",allForeign);
 log_hex("DRAW HOOK GAME CONTEXT CALLS OUTSIDE PRESENT",allDraws);
 log_hex("OM HOOK RAW BIND CALLS",g_rawOMCalls);
 log_hex("OM HOOK PRESENT BIND CALLS",g_presentOMCalls);
 log_hex("OM HOOK FOREIGN CONTEXT CALLS",g_foreignOMCalls);
 log_hex("EXECUTE COMMAND LIST COUNT",g_cmdListCount);
 log_hex("EXECUTE COMMAND LIST RAW",g_cmdListRaw);
 log_hex("EXECUTE COMMAND LIST FOREIGN CONTEXT",g_cmdListForeign);
 log_hex("EXECUTE COMMAND LIST IN PRESENT",g_cmdListInPresent);
 log_hex("PS SRV PROBE CALLS (LIMIT 256)",g_rgProbeCalls);
 if(!allDraws && g_cmdListCount)log_msg("DEFERRED COMMAND LISTS OBSERVED; PER-DEPTH DRAW ATTRIBUTION IS INCOMPLETE\r\n");
 if(!allRaw)log_msg("DRAW METHODS UNOBSERVED, EVEN FOR OWN OVERLAY; CHECK HOOK DISPATCH\r\n");
 else if(allOwn && !allDraws && !g_cmdListCount)log_msg("DRAW HOOK WORKS FOR MOD DRAWS, NOT GAME DRAWS: GAME DISPATCH PATH UNRESOLVED\r\n");
 else if(!allOwn)log_msg("NO MOD DRAW CLASSIFIED: CHECK MENU DRAW PATH AND DISPATCH TEST\r\n");
 if(!allDraws && !g_cmdListCount)log_msg("NO GAME IMMEDIATE-CONTEXT DRAWS OBSERVED; DEPTH IDENTITY UNRESOLVED\r\n");
 log_hex("NEAR-SCREEN RG SRV CANDIDATE COUNT (NOT PROVEN MOTION)",g_rgCount);
 for(U32 i=0;i<g_rgCount;i++){
  const DEPTH_REC*r=&g_rgRecords[i];
  log_hex("RG CANDIDATE INDEX",i);log_hex("RG WIDTH",r->width);
  log_hex("RG HEIGHT",r->height);log_hex("RG FORMAT",r->format);
  log_hex("RG SHADER BINDINGS",r->bindings);
 }
 log_msg("RESOURCE IDS ARE TEMPORARY; RG CANDIDATES ARE NOT PROVEN MOTION VECTORS\r\n");
}
static int patch(P*slot,P replacement){
 U32 prev;
 if(!VirtualProtect(slot,sizeof(P),0x40,&prev))return 0;
 __sync_lock_test_and_set(slot,replacement);
 U32 tmp;VirtualProtect(slot,sizeof(P),prev,&tmp);return 1;
}
typedef HRESULT_(CALL *DeviceCreate)(P,U32,P,U32,const U32*,U32,U32,const SWAP_DESC*,P*,P*,U32*,P*);
static U32 CALL probe_thread(P unused){
 (void)unused;
 for(U32 t=0;t<120&&!GetModuleHandleW(kD3D11Dll);t++)Sleep(250);
 g_d3d11=GetModuleHandleW(kD3D11Dll);
 if(!g_d3d11){log_msg("ERROR: d3d11.dll not loaded\r\n");return 0;}
 log_msg("DXGI PROBE DEFERRED UNTIL AFTER STARTUP\r\n");
 Sleep(g_probeDelayMs);
 DeviceCreate create=(DeviceCreate)GetProcAddress(g_d3d11,"D3D11CreateDeviceAndSwapChain");
 if(!create){log_msg("ERROR: D3D11CreateDeviceAndSwapChain not found\r\n");return 0;}
 P window=CreateWindowExW(0,kStatic,kBlank,WINDOW_STYLE_POPUP,-32000,-32000,16,16,0,0,0,0);
 if(!window){log_msg("ERROR: probe HWND failed\r\n");return 0;}
 SWAP_DESC d;memset(&d,0,sizeof(d));d.BufferDesc.Width=16;d.BufferDesc.Height=16;d.BufferDesc.Format=DXGI_FORMAT_RGBA8;
 d.SampleDesc.Count=1;d.BufferUsage=0x20;d.BufferCount=1;d.OutputWindow=window;d.Windowed=1;d.SwapEffect=0;
 P sc=0,dev=0,ctx=0;U32 level=0;
 HRESULT_ hr=create(0,D3D11_DRIVER_HARDWARE,0,0,0,0,D3D11_SDK_VERSION,&d,&sc,&dev,&level,&ctx);
 if(!SUCCEEDED_(hr))hr=create(0,D3D11_DRIVER_WARP,0,0,0,0,D3D11_SDK_VERSION,&d,&sc,&dev,&level,&ctx);
 if(SUCCEEDED_(hr)&&sc){
  P*vt=*(P**)sc;g_oldPresent=(void*)vt[8];g_oldResize=(void*)vt[13];
  int p1=patch(&vt[8],(P)present_hook);
  if(p1){g_hooked=1;log_msg("DXGI PRESENT HOOK INSTALLED (RESIZE DEFERRED)\r\n");}
  else{log_msg("ERROR: DXGI Present vtable patch failed\r\n");}
 }else log_msg("ERROR: D3D11 probe swap chain failed\r\n");
 REL(ctx);REL(dev);REL(sc);DestroyWindow(window);return 0;
}
static BOOL_ CALL resolve_system(INIT_ONCE_*o,void*p,void**q){
 (void)o;(void)p;(void)q;WCHAR dir[520];U32 len=GetSystemDirectoryW(dir,490);
 if(len&&len<490){U32 i=0;while(kSystemDll[i]){dir[len+i]=kSystemDll[i];i++;}dir[len+i]=0;g_system=LoadLibraryW(dir);}
 path_init();load_config();log_msg("WD2ENHANCED 0.38 AO DEPTH LIFECYCLE LOADED\r\n");
 set_ao_state(g_ao&&g_hookEnabled?AO_REQUESTED:AO_OFF);
 if(!g_hookEnabled)log_msg("HOOK DISABLED BY CONFIG; SAFE PROXY MODE\r\n");
 if(g_system&&g_hookEnabled&&!g_started){
  P pinned=0;
  /* Patched COM slots may be called as long as the game process is alive. */
  if(GetModuleHandleExW(0x1u|0x4u,(const WCHAR*)&resolve_system,&pinned)){
   g_started=1;P thread=CreateThread(0,0,probe_thread,0,0,0);if(thread)CloseHandle(thread);
   else log_msg("GRAPHICS STARTUP THREAD UNAVAILABLE; DIRECTINPUT FORWARDING ONLY\r\n");
  }else log_msg("GRAPHICS MODULE PIN FAILED; DIRECTINPUT FORWARDING ONLY\r\n");
 }
 return 1;
}
static P lookup(const char*name){InitOnceExecuteOnce(&g_once,resolve_system,0,0);return g_system?GetProcAddress(g_system,name):0;}
EX HRESULT_ CALL DirectInput8Create(P h,U32 version,const GUID_*id,P*out,P outer){
 typedef HRESULT_(CALL*fn)(P,U32,const GUID_*,P*,P);fn f=(fn)lookup("DirectInput8Create");return f?f(h,version,id,out,outer):(HRESULT_)0x80004005;
}
EX HRESULT_ CALL DllCanUnloadNow(void){typedef HRESULT_(CALL*fn)(void);fn f=(fn)lookup("DllCanUnloadNow");return f?f():1;}
EX HRESULT_ CALL DllGetClassObject(const GUID_*a,const GUID_*b,P*out){typedef HRESULT_(CALL*fn)(const GUID_*,const GUID_*,P*);fn f=(fn)lookup("DllGetClassObject");return f?f(a,b,out):(HRESULT_)0x80040111;}
EX HRESULT_ CALL DllRegisterServer(void){typedef HRESULT_(CALL*fn)(void);fn f=(fn)lookup("DllRegisterServer");return f?f():(HRESULT_)0x80004001;}
EX HRESULT_ CALL DllUnregisterServer(void){typedef HRESULT_(CALL*fn)(void);fn f=(fn)lookup("DllUnregisterServer");return f?f():(HRESULT_)0x80004001;}
EX P CALL GetdfDIJoystick(void){typedef P(CALL*fn)(void);fn f=(fn)lookup("GetdfDIJoystick");return f?f():0;}
BOOL_ CALL DllMain(P instance,U32 why,P reserved){(void)reserved;if(why==1){g_self=instance;DisableThreadLibraryCalls(instance);}return 1;}
/* MSVC floating point marker required by freestanding clang-cl link. */
int _fltused = 0;
