/* Observe vertex constants only on depth-qualified immediate-context draws.
   Staging copies preserve the bytes at those draws even if the game later
   updates or renames the buffer. Do not flush, stall, or change game state. */
#include "projection_math.h"

#define CAMERA_VS_SLOTS 14
#define CAMERA_MAX_BATCH 6
#define CAMERA_COPY_BUDGET 32
#define CAMERA_COPY_SLOTS 64
#define CAMERA_EPOCH_SLOTS 24
#define CAMERA_MAX_AGE 3
#define CAMERA_STILL_DRAWING 0x887a000au

typedef enum {
 CAMERA_NO_EVIDENCE,
 CAMERA_READBACK_PENDING,
 CAMERA_INSUFFICIENT_SAMPLES,
 CAMERA_AMBIGUOUS_PROJECTION,
 CAMERA_WAITING_FOR_AGREEMENT,
 CAMERA_PROJECTION_AVAILABLE
} CameraStatus_;

typedef struct {
 P depthKey; /* The capture records hold the reference. */
 U64 frame, epoch;
 U32 width, height;
 float clearDepth;
 U32 samples, confirmed, pending, ambiguous;
 Projection_ projection;
} CameraEvidence_;

typedef struct {
 P staging;
 U32 bytes, offset, length;
 U32 evidenceIndex, batchBit;
} CameraCopy_;

typedef struct { P data; U32 rowPitch, depthPitch; } CameraMapped_;
typedef void (CALL *CameraGetVSConstants_)(P,U32,U32,P*,U32*,U32*);

static const GUID_ IID_CAMERA_CONTEXT1 =
 {0xbb2c6faa,0xb5fb,0x4082,{0x8e,0x6b,0x38,0x8b,0x8c,0xfa,0x90,0xe1}};
static CameraEvidence_ g_cameraEvidence[CAMERA_EPOCH_SLOTS];
static CameraCopy_ g_cameraCopies[CAMERA_COPY_SLOTS];
static U64 g_cameraDrawFrame = (U64)-1;
static U32 g_cameraCopyCount;
static CameraStatus_ g_cameraStatus;

static void camera_reset(void)
{
 for (U32 i = 0; i < CAMERA_COPY_SLOTS; ++i)
  REL(g_cameraCopies[i].staging);
 memset(g_cameraEvidence,0,sizeof(g_cameraEvidence));
 memset(g_cameraCopies,0,sizeof(g_cameraCopies));
 g_cameraDrawFrame = (U64)-1;
 g_cameraCopyCount = 0;
 g_cameraStatus = CAMERA_NO_EVIDENCE;
}

static void camera_scan_constants(CameraEvidence_* evidence, const float* data,
                                  U32 count, U32 batchBit)
{
 for (U32 offset = 0; offset + 16 <= count && !evidence->ambiguous; offset += 4) {
  for (int transposed = 0; transposed <= 1; ++transposed) {
   Projection_ sample;
   if (!projection_decode(data + offset, transposed, evidence->width,
                          evidence->height, evidence->clearDepth, &sample))
    continue;
   if (evidence->confirmed &&
       !projection_matches(&sample, &evidence->projection,
                           evidence->width, evidence->height, 1)) {
    evidence->ambiguous = 1;
    break;
   }
   if (!evidence->confirmed) evidence->projection = sample;
   evidence->confirmed |= batchBit;
  }
 }
}

static void camera_poll(P ctx, U64 frame)
{
 for (U32 i = 0; i < CAMERA_COPY_SLOTS; ++i) {
  CameraCopy_* copy = &g_cameraCopies[i];
  if (!copy->batchBit) continue;

  CameraEvidence_* evidence = &g_cameraEvidence[copy->evidenceIndex];
  if (evidence->frame <= frame && frame - evidence->frame > CAMERA_MAX_AGE) {
   /* The driver owns queued references. Avoid reusing an unfinished copy. */
   REL(copy->staging);
   copy->batchBit = 0;
   --evidence->pending;
   continue;
  }

  CameraMapped_ mapped = {0};
  /* D3D11_MAP_READ + D3D11_MAP_FLAG_DO_NOT_WAIT. */
  HRESULT_ hr = V(ctx,14,HRESULT_(CALL*)(P,P,U32,U32,U32,CameraMapped_*))
   (ctx,copy->staging,0,1,0x100000u,&mapped);
  if ((U32)hr == CAMERA_STILL_DRAWING) continue;

  if (SUCCEEDED_(hr)) {
   if (mapped.data) {
    const float* constants = (const float*)((const U8*)mapped.data + copy->offset);
    camera_scan_constants(evidence,constants,copy->length / sizeof(float),copy->batchBit);
   } else {
    evidence->ambiguous = 1;
   }
   V(ctx,15,void(CALL*)(P,P,U32))(ctx,copy->staging,0);
  } else {
   evidence->ambiguous = 1;
   REL(copy->staging);
  }
  copy->batchBit = 0;
  --evidence->pending;
 }

 for (U32 i = 0; i < CAMERA_EPOCH_SLOTS; ++i) {
  CameraEvidence_* evidence = &g_cameraEvidence[i];
  if (evidence->depthKey && evidence->frame <= frame &&
      frame - evidence->frame > CAMERA_MAX_AGE)
   memset(evidence,0,sizeof(*evidence));
 }
}

static int camera_get_vs_constants(P ctx, P* buffers, U32* first, U32* counts)
{
 P ctx1 = 0;
 if (SUCCEEDED_(V(ctx,0,HRESULT_(CALL*)(P,const GUID_*,P*))
                (ctx,&IID_CAMERA_CONTEXT1,&ctx1)) && ctx1) {
  /* A versioned interface can alias the privately hooked base pointer.
     The original table is guaranteed to expose slot 125 for that alias. */
  P* table = ctx1 == g_depthPatchedContext ? g_sharedContextVtable : *(P**)ctx1;
  if (table && table[125])
   ((CameraGetVSConstants_)table[125])(ctx1,0,CAMERA_VS_SLOTS,buffers,first,counts);
  else {
   REL(ctx1);
   return 0;
  }
  REL(ctx1);
 } else {
  V(ctx,72,void(CALL*)(P,U32,U32,P*))(ctx,0,CAMERA_VS_SLOTS,buffers);
  for (U32 i = 0; i < CAMERA_VS_SLOTS; ++i) counts[i] = 4096;
 }
 return 1;
}

static CameraCopy_* camera_find_copy_slot(U32 size)
{
 CameraCopy_* empty = 0;
 CameraCopy_* replace = 0;
 for (U32 i = 0; i < CAMERA_COPY_SLOTS; ++i) {
  CameraCopy_* copy = &g_cameraCopies[i];
  if (copy->batchBit) continue;
  if (copy->staging && copy->bytes == size) return copy;
  if (!copy->staging && !empty) empty = copy;
  if (!replace) replace = copy;
 }
 return empty ? empty : replace;
}

static void camera_schedule_copies(P ctx, U32 evidenceIndex, U32 batchBit)
{
 P buffers[CAMERA_VS_SLOTS] = {0};
 U32 first[CAMERA_VS_SLOTS] = {0}, counts[CAMERA_VS_SLOTS] = {0};
 U32 chosen[CAMERA_MAX_BATCH], sizes[CAMERA_MAX_BATCH], number = 0;

 if (!camera_get_vs_constants(ctx,buffers,first,counts)) return;
 for (U32 i = 0; i < CAMERA_VS_SLOTS; ++i) {
  if (!buffers[i] || first[i] >= 4096 || counts[i] < 4 || counts[i] > 4096)
   continue;
  BUFFER_DESC desc;
  V(buffers[i],10,void(CALL*)(P,BUFFER_DESC*))(buffers[i],&desc);
  if (first[i] * 16 + 64 > desc.ByteWidth) continue;
  if (desc.ByteWidth > 65536 || number == CAMERA_MAX_BATCH) {
   /* An incomplete binding set could hide a second projection. */
   number = 0;
   break;
  }
  chosen[number] = i;
  sizes[number] = desc.ByteWidth;
  ++number;
 }

 CameraEvidence_* evidence = &g_cameraEvidence[evidenceIndex];
 if (number && g_cameraCopyCount + number <= CAMERA_COPY_BUDGET) {
  U32 freeSlots = 0;
  for (U32 j = 0; j < CAMERA_COPY_SLOTS; ++j)
   if (!g_cameraCopies[j].batchBit) ++freeSlots;
  if (freeSlots >= number) {
   for (U32 k = 0; k < number; ++k) {
    U32 i = chosen[k];
    CameraCopy_* copy = camera_find_copy_slot(sizes[k]);
    if (copy->bytes != sizes[k]) REL(copy->staging);
    if (!copy->staging) {
     const BUFFER_DESC desc = {sizes[k],3,0,0x20000u,0,0}; /* STAGING, CPU READ */
     if (!SUCCEEDED_(dev_buf(g_device,&desc,&copy->staging))) {
      evidence->ambiguous = 1;
      break;
     }
     copy->bytes = sizes[k];
    }
    copy->evidenceIndex = evidenceIndex;
    copy->batchBit = batchBit;
    copy->offset = first[i] * 16;
    copy->length = counts[i] * 16;
    if (copy->length > sizes[k] - copy->offset)
     copy->length = sizes[k] - copy->offset;
    /* Bypass the internal color-lineage observer for our own buffer copy. */
    P* table = ctx == g_depthPatchedContext ? g_sharedContextVtable : *(P**)ctx;
    ((void(CALL*)(P,P,P))table[47])(ctx,copy->staging,buffers[i]);
    ++evidence->pending;
    ++g_cameraCopyCount;
   }
  }
 }
 for (U32 i = 0; i < CAMERA_VS_SLOTS; ++i) REL(buffers[i]);
}

static void camera_observe_draw(P ctx, P depthKey, U64 frame, U64 epoch,
                                U32 width, U32 height, float clearDepth,
                                U32 writeDrawCount)
{
 U32 batchBit;
 if (writeDrawCount == 1) batchBit = 1u;
 else if (writeDrawCount == 3) batchBit = 2u;
 else if (writeDrawCount == 7) batchBit = 4u;
 else return;
 if (!depthKey || !epoch || !width || !height) return;

 if (g_cameraDrawFrame != frame) {
  g_cameraDrawFrame = frame;
  g_cameraCopyCount = 0;
  camera_poll(ctx,frame);
 }

 U32 index = CAMERA_EPOCH_SLOTS, freeIndex = CAMERA_EPOCH_SLOTS;
 for (U32 i = 0; i < CAMERA_EPOCH_SLOTS; ++i) {
  const CameraEvidence_* evidence = &g_cameraEvidence[i];
  if (evidence->depthKey == depthKey && evidence->frame == frame &&
      evidence->epoch == epoch) {
   index = i;
   break;
  }
  if (!evidence->depthKey && freeIndex == CAMERA_EPOCH_SLOTS) freeIndex = i;
 }

 if (index == CAMERA_EPOCH_SLOTS) {
  if (freeIndex == CAMERA_EPOCH_SLOTS) return;
  index = freeIndex;
  CameraEvidence_* evidence = &g_cameraEvidence[index];
  evidence->depthKey = depthKey;
  evidence->frame = frame;
  evidence->epoch = epoch;
  evidence->width = width;
  evidence->height = height;
  evidence->clearDepth = clearDepth;
 }

 CameraEvidence_* evidence = &g_cameraEvidence[index];
 if (evidence->samples & batchBit) return;
 evidence->samples |= batchBit;
 camera_schedule_copies(ctx,index,batchBit);
}

static int camera_has_agreement(const CameraEvidence_* evidence)
{
 return !evidence->ambiguous && !evidence->pending &&
        (evidence->confirmed & (evidence->confirmed - 1u)) != 0;
}

static int camera_resolve_projection(P ctx, P depthKey, U64 frame, U64 epoch,
                                     Projection_* out)
{
 camera_poll(ctx,g_frame);
 g_cameraStatus = CAMERA_NO_EVIDENCE;
 const CameraEvidence_* current = 0;
 for (U32 i = 0; i < CAMERA_EPOCH_SLOTS; ++i) {
  const CameraEvidence_* evidence = &g_cameraEvidence[i];
  if (evidence->depthKey == depthKey && evidence->frame == frame &&
      evidence->epoch == epoch) {
   current = evidence;
   break;
  }
 }
 if (!current || !depthKey) return 0;
 if (current->ambiguous) {
  g_cameraStatus = CAMERA_AMBIGUOUS_PROJECTION;
  return 0;
 }
 if (current->pending) {
  g_cameraStatus = CAMERA_READBACK_PENDING;
  return 0;
 }
 if (!camera_has_agreement(current)) {
  g_cameraStatus = CAMERA_INSUFFICIENT_SAMPLES;
  return 0;
 }

 /* Require corroboration for stable lens/depth parameters on the
    previous frame. Current-frame jitter is never taken from history. */
 U32 corroborated = 0;
 for (U32 i = 0; i < CAMERA_EPOCH_SLOTS; ++i) {
  const CameraEvidence_* previous = &g_cameraEvidence[i];
  if (previous->depthKey != depthKey || previous->frame + 1 != frame ||
      previous->width != current->width || previous->height != current->height ||
      !camera_has_agreement(previous)) continue;
  if (!projection_matches(&current->projection,&previous->projection,
                          current->width,current->height,0)) {
   g_cameraStatus = CAMERA_WAITING_FOR_AGREEMENT;
   return 0;
  }
  corroborated = 1;
 }
 if (!corroborated) {
  g_cameraStatus = CAMERA_WAITING_FOR_AGREEMENT;
  return 0;
 }
 *out = current->projection;
 g_cameraStatus = CAMERA_PROJECTION_AVAILABLE;
 return 1;
}

static int camera_get_projection(P ctx, P depthKey, U64 frame, U64 epoch,
                                 Projection_* out)
{
 if (__sync_lock_test_and_set(&g_depthGuard,1)) {
  g_cameraStatus = CAMERA_NO_EVIDENCE;
  return 0;
 }
 int ready = camera_resolve_projection(ctx,depthKey,frame,epoch,out);
 __sync_lock_release(&g_depthGuard);
 return ready;
}
