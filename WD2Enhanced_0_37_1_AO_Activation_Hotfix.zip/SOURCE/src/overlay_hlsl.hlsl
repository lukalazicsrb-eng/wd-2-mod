Texture2D Overlay : register(t0);
float4 PSOverlay(float4 pos:SV_Position):SV_Target {
int2 xy=int2(pos.xy)-int2(32,32);
if(any(xy<0) || xy.x>=600 || xy.y>=930) discard;
return Overlay.Load(int3(xy,0)); }
