Texture2D<float> DepthInput : register(t0);
cbuffer DepthParams : register(b0) { float Center; float RangeWidth; float NearGuess; float FarGuess; uint Mode; float FovDeg; float2 Padding; };
struct VOUT { float4 pos:SV_Position; float2 uv:TEXCOORD0; };
float zrev(int2 p){return saturate(DepthInput.Load(int3(p,0)));}
float viewZ(float z){return (NearGuess*FarGuess)/max(NearGuess+z*(FarGuess-NearGuess),0.000001); }
float3 viewP(int2 p,int2 wh){float2 uv=(float2(p)+0.5)/float2(wh);float z=viewZ(zrev(p));float t=tan(radians(FovDeg)*0.5);float aspect=(float)wh.x/max((float)wh.y,1.0);return float3((uv.x*2-1)*aspect*t*z,(1-uv.y*2)*t*z,z);}
float4 PSDepth(VOUT i):SV_Target {
uint w,h; DepthInput.GetDimensions(w,h);
int2 wh=int2(w,h);int2 pixel=int2(saturate(i.uv)*float2(w-1,h-1));
float z=zrev(pixel);
if(Mode==10){
 int2 l=max(pixel-int2(1,0),int2(0,0)),r=min(pixel+int2(1,0),wh-1);
 int2 u=max(pixel-int2(0,1),int2(0,0)),d=min(pixel+int2(0,1),wh-1);
 float c=viewZ(z), zl=viewZ(zrev(l)),zr=viewZ(zrev(r)),zu=viewZ(zrev(u)),zd=viewZ(zrev(d));
 float hx=min(abs(zl-c),abs(zr-c))/max(c,NearGuess);
 float hy=min(abs(zu-c),abs(zd-c))/max(c,NearGuess);
 float t=max(0.005,RangeWidth*0.15);float conf=1.0-smoothstep(t,t*2.0,max(hx,hy));
 if(z<0.000001)conf=0.0;return float4(conf,conf,conf,1); }
if(Mode==7 || Mode==9){
 int2 L=max(pixel-int2(1,0),int2(0,0)),R=min(pixel+int2(1,0),wh-1);
 int2 U=max(pixel-int2(0,1),int2(0,0)),D=min(pixel+int2(0,1),wh-1);
 float3 c=viewP(pixel,wh),l=viewP(L,wh),r=viewP(R,wh),u=viewP(U,wh),d=viewP(D,wh);
 float3 dx=length(r-c)<length(c-l)?r-c:c-l;float3 dy=length(d-c)<length(c-u)?d-c:c-u;
 float3 n=cross(dx,dy); n=dot(n,n)>1e-12?normalize(n):float3(0,0,-1);
 if(Mode==9){float slope=saturate(length(n.xy)*4.0);float facing=saturate(abs(n.z));return float4(slope,1.0-slope,saturate((1.0-facing)*5.0),1.0);}
 return float4(saturate(n*0.5+0.5),1); }
if(Mode==8){int2 R=min(pixel+int2(1,0),wh-1),D=min(pixel+int2(0,1),wh-1);
float d0=viewZ(z);float dx=viewZ(zrev(R)),dy=viewZ(zrev(D));
float e=max(abs(dx-d0),abs(dy-d0))/max(d0,NearGuess);
float threshold=max(0.002,RangeWidth*0.12);float g=smoothstep(threshold,threshold*3.0,e);return float4(g,g,g,1); }
if(Mode==0){return float4(pow(saturate(1-z),0.2),pow(z,0.2),abs(z-0.5)*1.6,1);}
float grey=z;
if(Mode==2)grey=1-z;
if(Mode==3)grey=saturate((z-Center)/max(RangeWidth,0.001)+0.5);
if(Mode==4)grey=saturate(((1-z)-Center)/max(RangeWidth,0.001)+0.5);
if(Mode==5){float dist=(NearGuess*FarGuess)/max(FarGuess-z*(FarGuess-NearGuess),0.001); grey=saturate(dist/max(RangeWidth*FarGuess,1.0));}
if(Mode==6){float dist=(NearGuess*FarGuess)/max(NearGuess+z*(FarGuess-NearGuess),0.001); grey=saturate(dist/max(RangeWidth*FarGuess,1.0));}
return float4(grey,grey,grey,1); }
