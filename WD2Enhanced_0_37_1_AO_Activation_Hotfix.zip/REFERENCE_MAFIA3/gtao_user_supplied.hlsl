// Ground-truth ambient occlusion (Jimenez et al. 2016, horizon search in the
// formulation popularised by Intel's XeGTAO), computed from the depth buffer
// the game hands to HBAO+. Two passes: AO (+ view depth) into an R16G16F
// target, then a depth-aware blur into the target HBAO+ would have written.

cbuffer Gtao : register(b0)
{
    float2 gSize;          // AO target size in pixels
    float2 gInvSize;
    float  gP00, gP11;     // projection x / y scale
    float  gZA, gZB;       // linear depth: w = gZB / (d - gZA)  (or d * gZB for view depths)
    float  gRadius;        // effect radius in view-space units
    float  gFalloff;       // fraction of the radius over which samples fade out
    float  gPower;         // final visibility exponent
    float  gIntensity;     // 0 = no AO, 1 = full
    float  gMaxRadiusPx;
    float  gDistPower;     // step distribution (> 1 = more samples close to the pixel)
    int    gSlices;
    int    gSteps;
    int    gViewDepths;
    float  gBlurSharpness; // 0 disables the blur
    float2 gPad;
}

Texture2D<float>  tDepth : register(t0);
Texture2D<float2> tAo    : register(t1);
SamplerState      sPoint : register(s0);

static const float PI = 3.14159265, HALF_PI = 1.57079633;

void FullscreenVS(uint id : SV_VertexID, out float4 pos : SV_Position, out float2 uv : TEXCOORD0)
{
    uv = float2((id << 1) & 2, id & 2);
    pos = float4(uv * float2(2, -2) + float2(-1, 1), 0, 1);
}

float LinearDepth(float d) { return gViewDepths ? d * gZB : gZB / (d - gZA); }

// View space: x right, y up, z forward (distance along the view axis).
// The position is rebuilt from the centre of the depth texel actually read;
// mixing an unsnapped uv with a point-sampled depth puts samples off the
// surface, which makes walls seen at grazing angles occlude themselves.
float3 ViewPos(float2 uv)
{
    uint w, h;
    tDepth.GetDimensions(w, h);
    int2 texel = clamp(int2(uv * float2(w, h)), int2(0, 0), int2(w, h) - 1);
    float z = LinearDepth(tDepth.Load(int3(texel, 0)));
    float2 ndc = (texel + 0.5) / float2(w, h) * float2(2, -2) + float2(-1, 1);
    return float3(ndc.x * z / gP00, ndc.y * z / gP11, z);
}

float FastAcos(float x)
{
    float a = abs(x);
    float r = (-0.156583 * a + HALF_PI) * sqrt(1.0 - a);
    return x >= 0 ? r : PI - r;
}

float Noise(float2 p) { return frac(52.9829189 * frac(dot(p, float2(0.06711056, 0.00583715)))); }

float2 GtaoPS(float4 pos : SV_Position, float2 uv : TEXCOORD0) : SV_Target
{
    float3 P = ViewPos(uv);
    if (!(P.z > 0.0 && P.z < 1e4))
        return float2(1.0, 0.0);  // sky / invalid depth

    // Normal from the depth neighbours, using the smaller difference on each axis.
    float3 pl = ViewPos(uv - float2(gInvSize.x, 0)), pr = ViewPos(uv + float2(gInvSize.x, 0));
    float3 pt = ViewPos(uv - float2(0, gInvSize.y)), pb = ViewPos(uv + float2(0, gInvSize.y));
    float3 dx = abs(pr.z - P.z) < abs(P.z - pl.z) ? pr - P : P - pl;
    float3 dy = abs(pb.z - P.z) < abs(P.z - pt.z) ? pb - P : P - pt;
    float3 N = normalize(cross(dx, dy));
    float3 V = normalize(-P);
    if (dot(N, V) < 0)
        N = -N;

    float radiusPx = min(gRadius * gP00 * 0.5 * gSize.x / P.z, gMaxRadiusPx);
    if (radiusPx < 1.5)
        return float2(1.0, P.z);
    float minStep = 1.3 / radiusPx;  // skip samples inside the centre pixel

    float falloffRange = max(gFalloff * gRadius, 1e-4);
    float falloffMul = -1.0 / falloffRange;
    float falloffAdd = gRadius * (1.0 - gFalloff) / falloffRange + 1.0;

    float sliceNoise = Noise(pos.xy);
    float stepNoise = Noise(pos.xy + float2(17.0, 59.0));
    float visibility = 0;

    [loop] for (int s = 0; s < gSlices; s++)
    {
        float phi = (s + sliceNoise) * PI / gSlices;
        float2 omega = float2(cos(phi), sin(phi));
        float3 dirV = float3(omega, 0);
        float2 dirUv = float2(omega.x, -omega.y) * radiusPx * gInvSize;

        float3 ortho = dirV - dot(dirV, V) * V;
        float3 axis = normalize(cross(ortho, V));
        float3 projN = N - axis * dot(N, axis);
        float projLen = length(projN);
        float cosN = saturate(dot(projN, V) / max(projLen, 1e-4));
        float n = sign(dot(ortho, projN)) * FastAcos(cosN);

        float low0 = cos(n + HALF_PI), low1 = cos(n - HALF_PI);
        float h0 = low0, h1 = low1;
        [loop] for (int j = 0; j < gSteps; j++)
        {
            float t = pow((j + stepNoise) / gSteps, gDistPower) + minStep;
            float2 off = dirUv * t;
            float2 uv0 = uv + off, uv1 = uv - off;
            float3 d0 = ViewPos(uv0) - P;
            float3 d1 = ViewPos(uv1) - P;
            float l0 = max(length(d0), 1e-5), l1 = max(length(d1), 1e-5);
            // Off-screen samples would be clamped onto edge pixels; ignore them.
            float w0 = saturate(l0 * falloffMul + falloffAdd) * all(uv0 == saturate(uv0));
            float w1 = saturate(l1 * falloffMul + falloffAdd) * all(uv1 == saturate(uv1));
            float c0 = lerp(low0, dot(d0 / l0, V), w0);
            float c1 = lerp(low1, dot(d1 / l1, V), w1);
            h0 = max(h0, c0);
            h1 = max(h1, c1);
        }

        projLen = lerp(projLen, 1.0, 0.05);
        float a0 = -FastAcos(h1), a1 = FastAcos(h0);
        a0 = n + clamp(a0 - n, -HALF_PI, HALF_PI);
        a1 = n + clamp(a1 - n, -HALF_PI, HALF_PI);
        float arc0 = (cosN + 2.0 * a0 * sin(n) - cos(2.0 * a0 - n)) * 0.25;
        float arc1 = (cosN + 2.0 * a1 * sin(n) - cos(2.0 * a1 - n)) * 0.25;
        visibility += projLen * (arc0 + arc1);
    }

    visibility = pow(saturate(visibility / gSlices), gPower);
    return float2(visibility, P.z);
}

float4 BlurPS(float4 pos : SV_Position, float2 uv : TEXCOORD0) : SV_Target
{
    float2 centre = tAo.SampleLevel(sPoint, uv, 0);
    float ao = centre.x;
    if (centre.y > 0.0 && gBlurSharpness > 0.0)
    {
        float sum = 0, weights = 0;
        [unroll] for (int y = -2; y <= 2; y++)
            [unroll] for (int x = -2; x <= 2; x++)
            {
                float2 s = tAo.SampleLevel(sPoint, uv + float2(x, y) * gInvSize, 0);
                float w = exp(-0.15 * (x * x + y * y)) * exp(-abs(s.y - centre.y) / centre.y * gBlurSharpness);
                w *= s.y > 0.0;
                sum += s.x * w;
                weights += w;
            }
        ao = sum / max(weights, 1e-4);
    }
    ao = lerp(1.0, ao, gIntensity);
    return float4(ao, ao, ao, ao);
}
