/* Exercise release capture policy with synthetic COM objects.
   Linux: cc -O2 -fno-builtin -ffunction-sections -fdata-sections
          -Wl,--gc-sections TOOLS/test_depth_capture.c -o /tmp/wd2-depth-test
   Then run /tmp/wd2-depth-test. No game, DLL or GPU is used by this test. */
#define __declspec(...)
#define __stdcall
#include "../SOURCE/src/native.c"
#include <stdio.h>

typedef struct { P *vtable; U32 refs; } FakeObject;
static U32 checks,failures,copies;

#define CHECK(x) do { ++checks; if(!(x)){ ++failures;  fprintf(stderr,"line %d: %s\n",__LINE__,#x); }} while(0)

static U32 fake_add_ref(P p){ return ++((FakeObject*)p)->refs; }
static U32 fake_release(P p){ return --((FakeObject*)p)->refs; }
static void fake_copy(P ctx,P dst,P src){
 (void)ctx;
 CHECK(dst && src && dst!=src);
 ++copies;
}
static P fake_vtable[3]={0,(P)fake_add_ref,(P)fake_release};

/* The real selector emits status logs; tests need no filesystem output. */
P CreateFileW(const WCHAR*a,U32 b,U32 c,P d,U32 e,U32 f,P g){
 (void)a;(void)b;(void)c;(void)d;(void)e;(void)f;(void)g;
 return (P)~0ull;
}
U32 WriteFile(P a,const void*b,U32 c,U32*d,P e){(void)a;(void)b;(void)c;(void)d;(void)e;return 0;}
U32 CloseHandle(P a){(void)a;return 1;}
U32 SetFilePointer(P a,I32 b,I32*c,U32 d){(void)a;(void)b;(void)c;(void)d;return 0;}
void OutputDebugStringA(const char*a){(void)a;}

static void test_bounds(void){
 g_captureViewportCount=1;
 g_captureViewport=(VIEWPORT_){0,0,2560,1440,0,1};
 g_captureScissorEnabled=0;
 CHECK(capture_full_bounds(2560,1440));
 CHECK(!capture_full_bounds(1280,720));
 g_captureViewport.TopLeftX=1;
 CHECK(!capture_full_bounds(2560,1440));
 g_captureViewport.TopLeftX=0;
 g_captureViewport.MinDepth=0.1f;
 CHECK(!capture_full_bounds(2560,1440));
 g_captureViewport.MinDepth=0;
 g_captureScissorEnabled=1;
 g_captureScissorCount=1;
 g_captureScissor=(RECT_){0,0,2560,1440};
 CHECK(capture_full_bounds(2560,1440));
 --g_captureScissor.right;
 CHECK(!capture_full_bounds(2560,1440));
 g_captureViewportCount=2;
 CHECK(!capture_full_bounds(2560,1440));
 g_width=2560;
 g_height=1440;
 CHECK(capture_related_size(2560,1440));
 CHECK(capture_related_size(1280,720));
 CHECK(!capture_related_size(1440,1440));
}

static void set_depth(U32 i,FakeObject *tex,U64 epoch){
 DEPTH_REC *r=&g_depthRecords[i];
 *r=(DEPTH_REC){0};
 r->resourceKey=tex;
 r->format=19;
 r->width=2560;
 r->height=1440;
 r->msaa=1;
 r->lastDepthClearFrame=g_frame;
 r->lastDrawFrame=g_frame;
 r->lastDepthClearSerial=epoch;
 r->lastWriteSerial=epoch+1;
 r->sceneWrites=3;
 g_depthTexture[i]=tex;
}
static void set_slot(U32 i,FakeObject *tex,FakeObject *srv){
 g_depthSnapshots[i]=(DEPTH_SNAPSHOT_){
  .texture=tex,.srv=srv,.desc={2560,1440,1,1,19,{1,0},0,BIND_SRV,0,0},.frame=~0ull
 };
}
static void test_selection(void){
 FakeObject ctx={fake_vtable,1},back={fake_vtable,1};
 FakeObject depth[2]={{fake_vtable,1},{fake_vtable,1}};
 FakeObject copy[2]={{fake_vtable,1},{fake_vtable,1}};
 FakeObject srv[2]={{fake_vtable,1},{fake_vtable,1}};
 g_oldResize=0;
 g_frame=41;
 g_ctx=&ctx;
 g_back=&back;
 g_depthCount=2;
 g_depthHooked=g_depthHookSessionReady=1;
 g_depthPatchedTable=fake_vtable;
 g_originalCopy=fake_copy;

 capture_begin_frame();
 set_depth(0,&depth[0],10);
 set_depth(1,&depth[1],20);
 set_slot(0,&copy[0],&srv[0]);
 set_slot(1,&copy[1],&srv[1]);
 U32 final=capture_color_index(&back,1);
 CHECK(final<CAPTURE_COLORS);
 CHECK(!setup_ao_depth_input() && g_aoDepthStatus==DEPTH_WAITING);

 CHECK(capture_make_snapshot(&ctx,0,DEPTH_BOUNDARY_UNBIND));
 CHECK(copies==1);
 CHECK(setup_ao_depth_input() && g_aoDepthStatus==DEPTH_UNSAFE);
 CHECK(!depth_source_live());
 CHECK(g_aoDepthIndex==0 && g_aoDepthEpoch==10 && g_aoDepthFrame==41);
 CHECK(srv[0].refs==2);

 CHECK(capture_make_snapshot(&ctx,1,DEPTH_BOUNDARY_CLEAR));
 CHECK(copies==2);
 CHECK(!setup_ao_depth_input() && !depth_source_live());
 CHECK(srv[0].refs==1);

 g_depthRecords[1].colorTargets=1ull<<final;
 CHECK(capture_make_snapshot(&ctx,1,DEPTH_BOUNDARY_PRESENT));
 CHECK(copies==2);
 CHECK(setup_ao_depth_input() && depth_source_live());
 CHECK(g_aoDepthIndex==1 && g_aoDepthEpoch==20 && g_aoDepthBoundary==DEPTH_BOUNDARY_CLEAR);
 CHECK(srv[1].refs==2);

 g_captureColors[final].sources=3;
 CHECK(!setup_ao_depth_input() && g_aoDepthStatus==DEPTH_UNSAFE);
 CHECK(srv[1].refs==1);
 g_aoSourceChoice=1;
 g_captureColors[final].sources=2;
 CHECK(setup_ao_depth_input() && !depth_source_live() && g_aoDepthIndex==0);
 g_aoSourceChoice=0;

 capture_consume(2);
 ++g_depthRecords[1].lastWriteSerial;
 CHECK(!capture_make_snapshot(&ctx,1,DEPTH_BOUNDARY_PRESENT));
 CHECK(!setup_ao_depth_input() && g_aoDepthStatus==DEPTH_UNSAFE);

 ++g_frame;
 capture_begin_frame();
 CHECK(!setup_ao_depth_input() && g_aoDepthStatus==DEPTH_WAITING);
 CHECK(back.refs==1);
 CHECK(!capture_eligible(&g_depthRecords[0]));
 set_depth(0,&depth[0],30);
 ++g_depthRecords[0].partialWrites;
 CHECK(!capture_eligible(&g_depthRecords[0]));

 reset_depth_capture();
 CHECK(srv[0].refs==0 && srv[1].refs==0);
 CHECK(copy[0].refs==0 && copy[1].refs==0);
 CHECK(!g_aoDepthSrv && g_aoDepthStatus==DEPTH_WAITING);
}
static void test_compatibility_selection(void){
 FakeObject ctx={fake_vtable,1},back={fake_vtable,1};
 FakeObject depth[2]={{fake_vtable,1},{fake_vtable,1}};
 FakeObject copy={fake_vtable,1},srv={fake_vtable,1};
 g_ctx=&ctx;
 g_back=&back;
 g_frame=50;
 g_depthCount=2;
 capture_begin_frame();
 set_depth(0,&depth[0],10);
 set_depth(1,&depth[1],20);
 DEPTH_REC *r=&g_depthRecords[1];
 r->bindFlags=BIND_SRV;
 r->sceneWrites=0;
 r->epochRejected=1;
 r->compatWriteSerial=21;
 g_compatDepth=(DEPTH_SNAPSHOT_){
  .texture=&copy,.srv=&srv,.desc={2560,1440,1,1,19,{1,0},0,BIND_SRV,0,0},.frame=~0ull
 };

 CHECK(!capture_eligible(r) && capture_compat_eligible(r));
 CHECK(!capture_make_snapshot(&ctx,1,DEPTH_BOUNDARY_UNBIND));
 CHECK(setup_ao_depth_input() && depth_source_live());
 CHECK(g_aoDepthStatus==DEPTH_COMPATIBLE && g_aoDepthIndex==1);
 CHECK(g_aoDepthEpoch==20 && g_aoDepthFrame==50 && srv.refs==2);
 r->compatInvalid=1;
 CHECK(!setup_ao_depth_input() && !depth_source_live());
 r->compatInvalid=0;
 CHECK(setup_ao_depth_input() && depth_source_live());

 g_aoSourceChoice=1;
 CHECK(!setup_ao_depth_input() && !depth_source_live());
 g_aoSourceChoice=0;
 g_depthRecords[0].bindFlags=BIND_SRV;
 g_depthRecords[0].compatWriteSerial=11;
 capture_compat_snapshot(&ctx,0,DEPTH_BOUNDARY_UNBIND);
 CHECK(g_compatConflict && !setup_ao_depth_input() && g_aoDepthStatus==DEPTH_UNSAFE);

 ++g_frame;
 capture_begin_frame();
 CHECK(!setup_ao_depth_input() && !depth_source_live());
 set_depth(1,&depth[1],40);
 r->bindFlags=BIND_SRV;
 r->compatWriteSerial=41;
 capture_compat_snapshot(&ctx,1,DEPTH_BOUNDARY_CLEAR);
 r->lastDepthClearSerial=42;
 r->compatWriteSerial=0;
 CHECK(setup_ao_depth_input() && depth_source_live() && g_aoDepthEpoch==40);
 g_captureOpaque=1;
 CHECK(!setup_ao_depth_input() && g_aoDepthStatus==DEPTH_UNSAFE);
 reset_depth_capture();
 CHECK(!g_compatDepth.srv && !g_compatDepth.texture && srv.refs==0 && copy.refs==0);
}
int main(void){
 test_bounds();
 test_selection();
 test_compatibility_selection();
 if(failures){
  fprintf(stderr,"%u of %u depth capture checks failed\n",failures,checks);
  return 1;
 }
 printf("%u depth capture checks passed\n",checks);
 return 0;
}
