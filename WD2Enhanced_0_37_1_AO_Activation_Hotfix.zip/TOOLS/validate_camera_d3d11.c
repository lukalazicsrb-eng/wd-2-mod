/* Developer test. Link a Windows x64 C executable with d3d11.lib. */
#define COBJMACROS
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <d3d11_1.h>
#include <math.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef void* P;
typedef unsigned char U8;
typedef unsigned int U32;
typedef unsigned long long U64;
typedef HRESULT HRESULT_;
typedef GUID GUID_;
typedef D3D11_BUFFER_DESC BUFFER_DESC;
#define CALL WINAPI
#define V(obj,i,t) ((t)((*(void***)(obj))[i]))
#define REL(p) do { if (p) { V(p,2,ULONG(CALL*)(P))(p); (p)=0; } } while (0)
#define SUCCEEDED_(hr) SUCCEEDED(hr)

static U64 g_frame;
static P g_device,g_depthPatchedContext;
static P* g_sharedContextVtable;
static volatile long g_depthGuard;

static HRESULT_ dev_buf(P dev, const BUFFER_DESC* desc, P* out)
{
 return ID3D11Device_CreateBuffer((ID3D11Device*)dev,desc,0,(ID3D11Buffer**)out);
}

#include "../SOURCE/src/camera_capture.inc"

#define WIDTH 2560u
#define HEIGHT 1440u
#define EXPECTED_A (-.00010001f)
#define EXPECTED_B .10001f

static void require(int condition, const char* label)
{
 if (!condition) {
  fprintf(stderr,"%s failed (camera state %d)\n",label,(int)g_cameraStatus);
  exit(EXIT_FAILURE);
 }
}

static void write_matrix(float* data, float sy, float jitter)
{
 const float matrix[16] = {
  sy * HEIGHT / WIDTH, 0, jitter, 0,
  0, sy, 0, 0,
  0, 0, EXPECTED_A, EXPECTED_B,
  0, 0, 1, 0
 };
 memcpy(data,matrix,sizeof(matrix));
}

static void upload(ID3D11DeviceContext* ctx, ID3D11Buffer* buffer,
                   float sy, float jitter, int ranged)
{
 float data[128] = {0};
 if (ranged) {
  /* The unbound region contains a different, otherwise valid projection. */
  write_matrix(data,sy + .3f,jitter);
  write_matrix(data + 64,sy,jitter);
 } else {
  write_matrix(data + 4,sy,jitter);
 }
 ID3D11DeviceContext_UpdateSubresource(ctx,(P)buffer,0,0,data,0,0);
}

static void complete_gpu(ID3D11Device* device, ID3D11DeviceContext* ctx)
{
 D3D11_QUERY_DESC desc = {D3D11_QUERY_EVENT,0};
 ID3D11Query* event = 0;
 require(SUCCEEDED(ID3D11Device_CreateQuery(device,&desc,&event)), "create event");
 ID3D11DeviceContext_End(ctx,(P)event);
 ID3D11DeviceContext_Flush(ctx);
 ULONGLONG until = GetTickCount64() + 3000;
 HRESULT hr;
 do {
  hr = ID3D11DeviceContext_GetData(ctx,(P)event,0,0,D3D11_ASYNC_GETDATA_DONOTFLUSH);
  if (hr == S_FALSE) Sleep(1);
 } while (hr == S_FALSE && GetTickCount64() < until);
 require(hr == S_OK,"staging work completes");
 REL(event);
}

static void test_binding(ID3D11Device* device, ID3D11DeviceContext* ctx,
                         ID3D11DeviceContext1* ctx1, ID3D11Buffer* buffer)
{
 unsigned int ranged = ctx1 != 0;
 UINT first = 16, count = 16;
 if (ranged)
  ID3D11DeviceContext1_VSSetConstantBuffers1(ctx1,2,1,&buffer,&first,&count);
 else
  ID3D11DeviceContext_VSSetConstantBuffers(ctx,2,1,&buffer);

 P depthKey = buffer; /* Stamped scene identity for this isolated test. */
 Projection_ result;
 const float lens = 1.6f;
 camera_reset();

 for (g_frame = 10; g_frame < 12; ++g_frame) {
  float jitter = (float)(g_frame - 9) * 0.0003f;
  upload(ctx,buffer,lens,jitter,ranged);
  camera_observe_draw(ctx,depthKey,g_frame,g_frame + 100,WIDTH,HEIGHT,0,1);
  camera_observe_draw(ctx,depthKey,g_frame,g_frame + 100,WIDTH,HEIGHT,0,3);
  /* The source changes after capture; the snapshot must keep the old bytes. */
  upload(ctx,buffer,lens + 0.4f,0.0f,ranged);
  complete_gpu(device,ctx);
  int ready = camera_get_projection(ctx,depthKey,g_frame,g_frame + 100,&result);
  if (g_frame == 10) {
   require(!ready && g_cameraStatus == CAMERA_WAITING_FOR_AGREEMENT,
           "first frame waits for corroboration");
  } else {
   require(ready && g_cameraStatus == CAMERA_PROJECTION_AVAILABLE,
           "two-draw, same-epoch projection available");
   require(fabsf(result.scaleY - lens) < 1e-6f,"staging preserved earlier lens");
   require(fabsf(result.offsetX - jitter) < 1e-7f,"same-frame jitter recovered");
   require(result.reverseZ && fabsf(result.depthB - EXPECTED_B) < 1e-7f,
           "view-space depth parameters recovered");
   require(!camera_get_projection(ctx,depthKey,g_frame,g_frame + 101,&result) &&
           g_cameraStatus == CAMERA_NO_EVIDENCE,"wrong clear epoch rejected");
  }
 }

 upload(ctx,buffer,lens,0.0f,ranged);
 camera_observe_draw(ctx,depthKey,g_frame,500,WIDTH,HEIGHT,0,1);
 upload(ctx,buffer,lens,0.001f,ranged);
 camera_observe_draw(ctx,depthKey,g_frame,500,WIDTH,HEIGHT,0,3);
 complete_gpu(device,ctx);
 require(!camera_get_projection(ctx,depthKey,g_frame,500,&result) &&
         g_cameraStatus == CAMERA_AMBIGUOUS_PROJECTION,"conflicting current jitter rejected");

 camera_reset();
 require(!camera_get_projection(ctx,depthKey,g_frame,500,&result) &&
         g_cameraStatus == CAMERA_NO_EVIDENCE,"reset abandons stale staging evidence");
}

int main(void)
{
 static const GUID_ iid1 =
  {0xbb2c6faa,0xb5fb,0x4082,{0x8e,0x6b,0x38,0x8b,0x8c,0xfa,0x90,0xe1}};
 ID3D11Device* device = 0;
 ID3D11DeviceContext* ctx = 0;
 ID3D11DeviceContext1* ctx1 = 0;
 D3D_FEATURE_LEVEL feature;
 HRESULT hr = D3D11CreateDevice(0,D3D_DRIVER_TYPE_HARDWARE,0,0,0,0,D3D11_SDK_VERSION,
                               &device,&feature,&ctx);
 if (FAILED(hr))
  hr = D3D11CreateDevice(0,D3D_DRIVER_TYPE_WARP,0,0,0,0,D3D11_SDK_VERSION,
                         &device,&feature,&ctx);
 require(SUCCEEDED(hr),"create D3D11 device");

 g_device = device;
 /* Exercise the original shared-table path a privately hooked context uses. */
 g_depthPatchedContext = ctx;
 g_sharedContextVtable = *(P**)ctx;
 const D3D11_BUFFER_DESC desc = {512,D3D11_USAGE_DEFAULT,D3D11_BIND_CONSTANT_BUFFER,0,0,0};
 ID3D11Buffer* buffer = 0;
 require(SUCCEEDED(ID3D11Device_CreateBuffer(device,&desc,0,&buffer)),"create VS constant buffer");
 test_binding(device,ctx,0,buffer);
 puts("D3D11 constant-buffer staging test passed.");
 if (SUCCEEDED(ID3D11DeviceContext_QueryInterface(ctx,&iid1,(P*)&ctx1))) {
  test_binding(device,ctx,ctx1,buffer);
  puts("D3D11.1 ranged constant-buffer staging test passed.");
 } else {
  puts("D3D11.1 unavailable, ranged binding test skipped.");
 }
 ID3D11DeviceContext_ClearState(ctx);
 REL(buffer);
 REL(ctx1);
 REL(ctx);
 REL(device);
 return EXIT_SUCCESS;
}
