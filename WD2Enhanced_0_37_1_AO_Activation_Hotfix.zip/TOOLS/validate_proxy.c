/* Run against an isolated copy of INSTALL/ with [Diagnostics] HookEnabled=0. */
#define COBJMACROS
#define DIRECTINPUT_VERSION 0x0800
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <dinput.h>
#include <stdio.h>
#include <string.h>

typedef HRESULT (WINAPI *CreateInput)(HINSTANCE, DWORD, const IID *, LPVOID *, LPUNKNOWN);
typedef HRESULT (WINAPI *CanUnload)(void);
typedef const DIDATAFORMAT *(WINAPI *GetJoystickFormat)(void);

int wmain(int argc, wchar_t **argv)
{
    if (argc != 2) {
        fprintf(stderr, "Usage: validate_proxy <absolute path to isolated dinput8.dll>\n");
        return 2;
    }
    HMODULE d3d = LoadLibraryExW(L"d3d11.dll", NULL, LOAD_LIBRARY_SEARCH_SYSTEM32);
    if (!d3d) {
        fprintf(stderr, "System d3d11.dll did not load (%lu)\n", (unsigned long)GetLastError());
        return 1;
    }
    HMODULE proxy = LoadLibraryW(argv[1]);
    if (!proxy) {
        fprintf(stderr, "Proxy did not load (%lu)\n", (unsigned long)GetLastError());
        return 1;
    }
    static const char *exports[] = {
        "DirectInput8Create", "DllCanUnloadNow", "DllGetClassObject",
        "DllRegisterServer", "DllUnregisterServer", "GetdfDIJoystick"
    };
    for (unsigned i = 0; i < sizeof(exports) / sizeof(exports[0]); ++i) {
        if (!GetProcAddress(proxy, exports[i])) {
            fprintf(stderr, "Missing export %s\n", exports[i]);
            return 1;
        }
        printf("PASS export %s\n", exports[i]);
    }
    CreateInput create = (CreateInput)(void *)GetProcAddress(proxy, "DirectInput8Create");
    CanUnload can_unload = (CanUnload)(void *)GetProcAddress(proxy, "DllCanUnloadNow");
    GetJoystickFormat joystick = (GetJoystickFormat)(void *)GetProcAddress(proxy, "GetdfDIJoystick");

    static const IID iid = {0xBF798030, 0x483A, 0x4DA2, {0xAA,0x99,0x5D,0x64,0xED,0x36,0x97,0x00}};
    IDirectInput8A *input = NULL;
    HRESULT hr = create(GetModuleHandleW(NULL), DIRECTINPUT_VERSION, &iid, (void **)&input, NULL);
    if (FAILED(hr) || !input) {
        fprintf(stderr, "DirectInput8Create failed (0x%08lx)\n", (unsigned long)hr);
        return 1;
    }
    IDirectInput8_Release(input);
    printf("PASS DirectInput8Create forwarded and returned a usable interface\n");

    wchar_t system_input[MAX_PATH];
    UINT count = GetSystemDirectoryW(system_input, MAX_PATH);
    static const wchar_t dll_name[] = L"\\dinput8.dll";
    if (count == 0 || count + sizeof(dll_name) / sizeof(dll_name[0]) >= MAX_PATH)
        return 1;
    memcpy(system_input + count, dll_name, sizeof(dll_name));
    HMODULE system = LoadLibraryW(system_input);
    if (!system || system == proxy) {
        fprintf(stderr, "Separate system dinput8.dll did not load\n");
        return 1;
    }
    GetJoystickFormat system_joystick = (GetJoystickFormat)(void *)GetProcAddress(system, "GetdfDIJoystick");
    const DIDATAFORMAT *format = joystick();
    if (system_joystick) {
        if (!format || format != system_joystick() || format->dwSize != sizeof(*format)) {
            fprintf(stderr, "Invalid GetdfDIJoystick response\n");
            return 1;
        }
        printf("PASS GetdfDIJoystick forwarded (%lu objects)\n", (unsigned long)format->dwNumObjs);
    } else {
        if (format) {
            fprintf(stderr, "Proxy returned an unexpected format for unavailable system export\n");
            return 1;
        }
        printf("PASS GetdfDIJoystick fallback (system export unavailable)\n");
    }

    hr = can_unload();
    if (hr != S_OK && hr != S_FALSE) {
        fprintf(stderr, "Unexpected DllCanUnloadNow result (0x%08lx)\n", (unsigned long)hr);
        return 1;
    }
    printf("PASS DllCanUnloadNow returned 0x%08lx\n", (unsigned long)hr);

    /* Allow the probe thread to reach its HookEnabled=0 check and log it. */
    Sleep(300);
    return 0;
}
