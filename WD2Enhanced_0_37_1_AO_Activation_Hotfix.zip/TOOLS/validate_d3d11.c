/* Compile the release's HLSL with D3DCompiler 47 and optionally execute its
   DX11 passes on synthetic depth buffers. This harness does not load the game. */
#define COBJMACROS
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <d3d11.h>
#include <d3dcompiler.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

enum { VS, COMPOSITE, PREPARE, MIP, GTAO, DENOISE, OVERLAY, PREVIEW, SHADERS };
enum { MIPS = 5, CHANNELS = 4 };
static UINT render_width = 321, render_height = 181;
#define WIDTH (render_width)
#define HEIGHT (render_height)
#define AO_WIDTH ((WIDTH + 1) / 2)
#define AO_HEIGHT ((HEIGHT + 1) / 2)
enum { RAW_DEPTH = 2, MSAA_DEPTH = 3, VISIBILITY = 4, DEPTH_MIPS = 5, RAW_VISIBILITY = 6, SLOTS = 7 };

static const struct {
    const char *file, *entry, *profile;
} specs[SHADERS] = {
    {"hlsl.hlsl", "VSMain", "vs_5_0"},
    {"hlsl.hlsl", "PSMain", "ps_5_0"},
    {"hlsl.hlsl", "PSPrepare", "ps_5_0"},
    {"hlsl.hlsl", "PSDownsample", "ps_5_0"},
    {"hlsl.hlsl", "PSAO", "ps_5_0"},
    {"hlsl.hlsl", "PSAODenoise", "ps_5_0"},
    {"overlay_hlsl.hlsl", "PSOverlay", "ps_5_0"},
    {"depth_preview_hlsl.hlsl", "PSDepth", "ps_5_0"}
};

typedef struct {
    float inv_w, inv_h, sharp, saturation;
    float contrast, brightness, gamma, fx;
    float menu, padding[3];
    float ao_mode, intensity, radius, quality;
    float depth_b, depth_a, inv_scale_x, inv_scale_y;
    float samples, width, height, hud_guard;
    float contact_boost, edge_guard, linear_color, diagnostics_ready;
    float jitter_x, jitter_y, clear_depth, reserved;
} Constants;

typedef struct {
    ID3D11Texture2D *texture;
    ID3D11ShaderResourceView *srv;
    ID3D11RenderTargetView *rtv;
} Image;

typedef struct {
    ID3D11Device *device;
    ID3D11DeviceContext *context;
    ID3D11VertexShader *vs;
    ID3D11PixelShader *ps[SHADERS];
    ID3D11Buffer *constant_buffer;
    ID3D11SamplerState *sampler;
    Image raw_depth, hierarchy, visibility, denoised, color, output, readback;
    ID3D11ShaderResourceView *input_depth;
    ID3D11ShaderResourceView *mip_srv[MIPS];
    ID3D11RenderTargetView *mip_rtv[MIPS];
} Test;

static void require(HRESULT hr, const char *operation)
{
    if (FAILED(hr)) {
        fprintf(stderr, "%s failed (0x%08lx)\n", operation, (unsigned long)hr);
        exit(1);
    }
}

static int compile_shaders(pD3DCompile compile, const char *directory, ID3DBlob *blobs[SHADERS])
{
    int success = 1;
    for (unsigned i = 0; i < SHADERS; ++i) {
        char path[1024];
        if (snprintf(path, sizeof(path), "%s/%s", directory, specs[i].file) >= (int)sizeof(path))
            return 0;
        FILE *file = fopen(path, "rb");
        if (!file) {
            perror(path);
            return 0;
        }
        if (fseek(file, 0, SEEK_END) != 0) {
            fclose(file);
            return 0;
        }
        long length = ftell(file);
        if (length <= 0 || fseek(file, 0, SEEK_SET) != 0) {
            fclose(file);
            return 0;
        }
        char *source = malloc((size_t)length);
        if (!source || fread(source, 1, (size_t)length, file) != (size_t)length) {
            fclose(file);
            free(source);
            return 0;
        }
        fclose(file);
        ID3DBlob *messages = NULL;
        HRESULT hr = compile(source, (SIZE_T)length, path, NULL, NULL, specs[i].entry,
                             specs[i].profile, 0, 0, &blobs[i], &messages);
        free(source);
        if (messages) {
            fprintf(stderr, "%s\n", (const char *)ID3D10Blob_GetBufferPointer(messages));
            ID3D10Blob_Release(messages);
        }
        if (FAILED(hr)) {
            fprintf(stderr, "FAIL %s %s (0x%08lx)\n", specs[i].entry,
                    specs[i].profile, (unsigned long)hr);
            success = 0;
        } else {
            printf("PASS %s %s (%llu bytes)\n", specs[i].entry, specs[i].profile,
                   (unsigned long long)ID3D10Blob_GetBufferSize(blobs[i]));
        }
    }
    return success;
}

static void make_image(Test *test, Image *image, UINT w, UINT h, UINT mips, DXGI_FORMAT format,
                       D3D11_USAGE usage, UINT binds, UINT cpu_access)
{
    D3D11_TEXTURE2D_DESC desc = {0};
    desc.Width = w;
    desc.Height = h;
    desc.MipLevels = mips;
    desc.ArraySize = 1;
    desc.Format = format;
    desc.SampleDesc.Count = 1;
    desc.Usage = usage;
    desc.BindFlags = binds;
    desc.CPUAccessFlags = cpu_access;
    require(ID3D11Device_CreateTexture2D(test->device, &desc, NULL, &image->texture), "CreateTexture2D");
    if (binds & D3D11_BIND_SHADER_RESOURCE) {
        require(ID3D11Device_CreateShaderResourceView(test->device, (ID3D11Resource *)image->texture,
                                                      NULL, &image->srv), "CreateShaderResourceView");
    }
    if ((binds & D3D11_BIND_RENDER_TARGET) && mips == 1) {
        require(ID3D11Device_CreateRenderTargetView(test->device, (ID3D11Resource *)image->texture,
                                                   NULL, &image->rtv), "CreateRenderTargetView");
    }
}

static void setup(Test *test, ID3DBlob *blobs[SHADERS])
{
    D3D_FEATURE_LEVEL level;
    HRESULT hr = D3D11CreateDevice(NULL, D3D_DRIVER_TYPE_WARP, NULL, 0, NULL, 0, D3D11_SDK_VERSION,
                                  &test->device, &level, &test->context);
    const char *driver = "WARP request";
    if (FAILED(hr)) {
        driver = "default adapter";
        hr = D3D11CreateDevice(NULL, D3D_DRIVER_TYPE_HARDWARE, NULL, 0, NULL, 0, D3D11_SDK_VERSION,
                              &test->device, &level, &test->context);
    }
    require(hr, "D3D11CreateDevice");
    printf("D3D11 feature level 0x%x (%s)\n", level, driver);
    require(ID3D11Device_CreateVertexShader(test->device, ID3D10Blob_GetBufferPointer(blobs[VS]),
                                          ID3D10Blob_GetBufferSize(blobs[VS]), NULL, &test->vs),
            "CreateVertexShader");
    for (unsigned i = COMPOSITE; i < SHADERS; ++i) {
        require(ID3D11Device_CreatePixelShader(test->device, ID3D10Blob_GetBufferPointer(blobs[i]),
                                             ID3D10Blob_GetBufferSize(blobs[i]), NULL, &test->ps[i]),
                specs[i].entry);
    }
    D3D11_BUFFER_DESC buffer = {0};
    buffer.ByteWidth = sizeof(Constants);
    buffer.Usage = D3D11_USAGE_DEFAULT;
    buffer.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
    require(ID3D11Device_CreateBuffer(test->device, &buffer, NULL, &test->constant_buffer),
            "CreateBuffer");

    D3D11_SAMPLER_DESC sampler = {0};
    sampler.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
    sampler.AddressU = sampler.AddressV = sampler.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
    sampler.MaxAnisotropy = 1;
    sampler.ComparisonFunc = D3D11_COMPARISON_NEVER;
    sampler.MaxLOD = D3D11_FLOAT32_MAX;
    require(ID3D11Device_CreateSamplerState(test->device, &sampler, &test->sampler), "CreateSamplerState");

    UINT io = D3D11_BIND_SHADER_RESOURCE | D3D11_BIND_RENDER_TARGET;
    make_image(test, &test->raw_depth, WIDTH, HEIGHT, 1, DXGI_FORMAT_R32_FLOAT,
               D3D11_USAGE_DEFAULT, D3D11_BIND_SHADER_RESOURCE, 0);
    make_image(test, &test->hierarchy, AO_WIDTH, AO_HEIGHT, MIPS, DXGI_FORMAT_R32G32B32A32_FLOAT,
               D3D11_USAGE_DEFAULT, io, 0);
    make_image(test, &test->visibility, AO_WIDTH, AO_HEIGHT, 1, DXGI_FORMAT_R16G16B16A16_FLOAT,
               D3D11_USAGE_DEFAULT, io, 0);
    make_image(test, &test->denoised, AO_WIDTH, AO_HEIGHT, 1, DXGI_FORMAT_R16G16B16A16_FLOAT,
               D3D11_USAGE_DEFAULT, io, 0);
    make_image(test, &test->color, WIDTH, HEIGHT, 1, DXGI_FORMAT_R32G32B32A32_FLOAT,
               D3D11_USAGE_DEFAULT, io, 0);
    make_image(test, &test->output, WIDTH, HEIGHT, 1, DXGI_FORMAT_R32G32B32A32_FLOAT,
               D3D11_USAGE_DEFAULT, io, 0);
    make_image(test, &test->readback, WIDTH, HEIGHT, 1, DXGI_FORMAT_R32G32B32A32_FLOAT,
               D3D11_USAGE_STAGING, 0, D3D11_CPU_ACCESS_READ);

    for (UINT level = 0; level < MIPS; ++level) {
        D3D11_SHADER_RESOURCE_VIEW_DESC srv = {0};
        srv.Format = DXGI_FORMAT_R32G32B32A32_FLOAT;
        srv.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
        srv.Texture2D.MostDetailedMip = level;
        srv.Texture2D.MipLevels = 1;
        require(ID3D11Device_CreateShaderResourceView(test->device,
                (ID3D11Resource *)test->hierarchy.texture, &srv, &test->mip_srv[level]), "Create mip SRV");
        D3D11_RENDER_TARGET_VIEW_DESC rtv = {0};
        rtv.Format = srv.Format;
        rtv.ViewDimension = D3D11_RTV_DIMENSION_TEXTURE2D;
        rtv.Texture2D.MipSlice = level;
        require(ID3D11Device_CreateRenderTargetView(test->device,
                (ID3D11Resource *)test->hierarchy.texture, &rtv, &test->mip_rtv[level]), "Create mip RTV");
    }
    const float scene_color[] = {0.5f, 0.5f, 0.5f, 1.0f};
    ID3D11DeviceContext_ClearRenderTargetView(test->context, test->color.rtv, scene_color);
    ID3D11DeviceContext_IASetPrimitiveTopology(test->context, D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
    ID3D11DeviceContext_VSSetShader(test->context, test->vs, NULL, 0);
    ID3D11DeviceContext_PSSetConstantBuffers(test->context, 0, 1, &test->constant_buffer);
    ID3D11DeviceContext_PSSetSamplers(test->context, 0, 1, &test->sampler);
}

static void pass(Test *test, unsigned shader, UINT w, UINT h, ID3D11RenderTargetView *target,
                 ID3D11ShaderResourceView *sources[SLOTS])
{
    ID3D11ShaderResourceView *null_sources[SLOTS] = {0};
    D3D11_VIEWPORT viewport = {0, 0, (float)w, (float)h, 0, 1};
    ID3D11DeviceContext_RSSetViewports(test->context, 1, &viewport);
    ID3D11DeviceContext_OMSetRenderTargets(test->context, 1, &target, NULL);
    ID3D11DeviceContext_PSSetShaderResources(test->context, 0, SLOTS, sources);
    ID3D11DeviceContext_PSSetShader(test->context, test->ps[shader], NULL, 0);
    ID3D11DeviceContext_Draw(test->context, 3, 0);
    ID3D11DeviceContext_PSSetShaderResources(test->context, 0, SLOTS, null_sources);
    ID3D11DeviceContext_OMSetRenderTargets(test->context, 0, NULL, NULL);
}

static void composite(Test *test, const Constants *cb, float *output)
{
    ID3D11DeviceContext_UpdateSubresource(test->context, (ID3D11Resource *)test->constant_buffer,
                                        0, NULL, cb, 0, 0);
    ID3D11ShaderResourceView *sources[SLOTS] = {0};
    sources[0] = test->color.srv;
    sources[cb->samples == 1.0f ? RAW_DEPTH : MSAA_DEPTH] = test->input_depth;
    sources[VISIBILITY] = test->denoised.srv;
    sources[DEPTH_MIPS] = test->hierarchy.srv;
    sources[RAW_VISIBILITY] = test->visibility.srv;
    pass(test, COMPOSITE, WIDTH, HEIGHT, test->output.rtv, sources);

    ID3D11DeviceContext_CopyResource(test->context, (ID3D11Resource *)test->readback.texture,
                                    (ID3D11Resource *)test->output.texture);
    D3D11_MAPPED_SUBRESOURCE map;
    require(ID3D11DeviceContext_Map(test->context, (ID3D11Resource *)test->readback.texture, 0,
                                  D3D11_MAP_READ, 0, &map), "Map output");
    for (unsigned y = 0; y < HEIGHT; ++y) {
        memcpy(output + y * WIDTH * CHANNELS, (const char *)map.pData + y * map.RowPitch,
               WIDTH * CHANNELS * sizeof(float));
    }
    ID3D11DeviceContext_Unmap(test->context, (ID3D11Resource *)test->readback.texture, 0);
}

static void render_depth(Test *test, const Constants *cb, float *output)
{
    ID3D11DeviceContext_UpdateSubresource(test->context, (ID3D11Resource *)test->constant_buffer,
                                        0, NULL, cb, 0, 0);
    ID3D11ShaderResourceView *sources[SLOTS] = {0};
    sources[cb->samples == 1.0f ? RAW_DEPTH : MSAA_DEPTH] = test->input_depth;
    pass(test, PREPARE, AO_WIDTH, AO_HEIGHT, test->mip_rtv[0], sources);
    sources[RAW_DEPTH] = sources[MSAA_DEPTH] = NULL;
    for (unsigned level = 1; level < MIPS; ++level) {
        sources[DEPTH_MIPS] = test->mip_srv[level - 1];
        pass(test, MIP, AO_WIDTH >> level, AO_HEIGHT >> level, test->mip_rtv[level], sources);
    }
    sources[DEPTH_MIPS] = test->hierarchy.srv;
    pass(test, GTAO, AO_WIDTH, AO_HEIGHT, test->visibility.rtv, sources);
    sources[VISIBILITY] = test->visibility.srv;
    pass(test, DENOISE, AO_WIDTH, AO_HEIGHT, test->denoised.rtv, sources);
    composite(test, cb, output);
}

static void run_scene(Test *test, const Constants *cb, const float *raw, float *output)
{
    ID3D11DeviceContext_UpdateSubresource(test->context, (ID3D11Resource *)test->raw_depth.texture,
                                        0, NULL, raw, WIDTH * sizeof(float), 0);
    test->input_depth = test->raw_depth.srv;
    render_depth(test, cb, output);
}

static float value(const float *image, unsigned x, unsigned y, unsigned channel)
{
    return image[(y * WIDTH + x) * CHANNELS + channel];
}

static float min_red(const float *image, unsigned x0, unsigned y0, unsigned x1, unsigned y1)
{
    float minimum = 1.0f;
    for (unsigned y = y0; y < y1; ++y) {
        for (unsigned x = x0; x < x1; ++x) {
            float red = value(image, x, y, 0);
            if (!isfinite(red) || red < 0.0f || red > 1.0001f)
                return -1.0f;
            minimum = fminf(minimum, red);
        }
    }
    return minimum;
}

enum { FLAT, SLOPE, CORNER, SILHOUETTE, EMPTY };
static void generate_depth(float *raw, const Constants *cb, unsigned scene)
{
    for (unsigned y = 0; y < HEIGHT; ++y) {
        float ray_y = (1.0f - 2.0f * ((float)y + 0.5f) / HEIGHT - cb->jitter_y) * cb->inv_scale_y;
        for (unsigned x = 0; x < WIDTH; ++x) {
            float ray_x = (2.0f * ((float)x + 0.5f) / WIDTH - 1.0f - cb->jitter_x) * cb->inv_scale_x;
            float z = 6.0f;
            if (scene == SLOPE) {
                z /= (1.0f + 0.3f * ray_x - 0.5f * ray_y);
            } else if (scene == CORNER) {
                /* A front-facing wall at z=5 intersects the floor y=-1.0. */
                z = ray_y < 0.0f ? fminf(5.0f, -1.0f / ray_y) : 5.0f;
            } else if (scene == SILHOUETTE) {
                int foreground = x >= WIDTH / 4 && x < WIDTH * 3 / 4 &&
                                 y >= HEIGHT / 4 && y < HEIGHT * 3 / 4;
                z = foreground ? 2.0f : 14.0f;
            }
            raw[y * WIDTH + x] = scene == EMPTY ? cb->clear_depth : cb->depth_a + cb->depth_b / z;
        }
    }
}

static void expect(int condition, const char *name, unsigned quality, float measured, int *success)
{
    printf("%s %s (quality %u, %.6f)\n", condition ? "PASS" : "FAIL", name, quality, measured);
    if (!condition)
        *success = 0;
}

static int validate_geometry(Test *test)
{
    float *raw = malloc(WIDTH * HEIGHT * sizeof(float));
    float *output = malloc(WIDTH * HEIGHT * CHANNELS * sizeof(float));
    if (!raw || !output) {
        free(raw);
        free(output);
        return 0;
    }

    Constants cb = {0};
    cb.inv_w = 1.0f / WIDTH;
    cb.inv_h = 1.0f / HEIGHT;
    cb.saturation = cb.contrast = cb.gamma = cb.fx = 1.0f;
    cb.ao_mode = 2.0f;
    cb.intensity = 1.0f;
    cb.radius = 14.0f;
    cb.inv_scale_y = 0.7002075f; /* tan(70 degrees / 2) */
    cb.inv_scale_x = cb.inv_scale_y * WIDTH / HEIGHT;
    cb.samples = 1.0f;
    cb.width = WIDTH;
    cb.height = HEIGHT;
    cb.edge_guard = 1.0f;
    cb.linear_color = 1.0f;
    cb.diagnostics_ready = 2.0f;
    cb.depth_b = 0.1f; /* Infinite-far reverse Z. */
    int success = 1;
    for (unsigned quality = 0; quality < 3; ++quality) {
        cb.quality = (float)quality;
        generate_depth(raw, &cb, FLAT);
        run_scene(test, &cb, raw, output);
        float minimum = min_red(output, 0, 0, WIDTH, HEIGHT);
        expect(minimum > 0.985f, "front-facing plane remains neutral", quality, minimum, &success);

        generate_depth(raw, &cb, SLOPE);
        run_scene(test, &cb, raw, output);
        minimum = min_red(output, 0, 0, WIDTH, HEIGHT);
        expect(minimum > 0.96f, "sloped plane remains neutral", quality, minimum, &success);

        generate_depth(raw, &cb, CORNER);
        run_scene(test, &cb, raw, output);
        unsigned seam = (unsigned)(HEIGHT * (0.5f + 0.1f / cb.inv_scale_y));
        minimum = min_red(output, WIDTH / 4, seam - 6, WIDTH * 3 / 4, seam + 9);
        expect(minimum > 0.0f && minimum < 0.995f, "floor-wall contact produces occlusion",
               quality, minimum, &success);
        minimum = min_red(output, WIDTH / 4, 12, WIDTH * 3 / 4, HEIGHT / 3);
        expect(minimum > 0.985f, "wall remains neutral away from the contact", quality, minimum, &success);

        generate_depth(raw, &cb, SILHOUETTE);
        run_scene(test, &cb, raw, output);
        minimum = min_red(output, 0, 0, WIDTH, HEIGHT);
        expect(minimum > 0.96f, "separated foreground does not halo against far geometry",
               quality, minimum, &success);

        generate_depth(raw, &cb, EMPTY);
        run_scene(test, &cb, raw, output);
        minimum = min_red(output, 0, 0, WIDTH, HEIGHT);
        expect(minimum > 0.999f, "cleared depth produces neutral visibility", quality, minimum, &success);
    }

    cb.depth_a = 50.0f / 49.9f; /* Finite forward Z, near=0.1 far=50. */
    cb.depth_b = -5.0f / 49.9f;
    cb.clear_depth = 1.0f;
    cb.jitter_x = 0.5f / WIDTH;
    cb.jitter_y = -0.5f / HEIGHT;
    generate_depth(raw, &cb, SLOPE);
    run_scene(test, &cb, raw, output);
    float minimum = min_red(output, 0, 0, WIDTH, HEIGHT);
    expect(minimum > 0.96f, "forward-Z jittered sloped plane remains neutral", 2, minimum, &success);

    cb.ao_mode = 7.0f;
    composite(test, &cb, output);
    float normal = value(output, WIDTH / 2, HEIGHT / 2, 2);
    expect(isfinite(normal) && fabsf(normal - 0.5f) > 0.2f,
           "normal diagnostic renders a reconstructed plane normal", 2, normal, &success);

    generate_depth(raw, &cb, CORNER);
    cb.ao_mode = 2.0f;
    run_scene(test, &cb, raw, output);
    float forward_corner = min_red(output, WIDTH / 4, HEIGHT / 2, WIDTH * 3 / 4, HEIGHT * 3 / 4);
    expect(forward_corner > 0.0f && forward_corner < 0.995f,
           "forward-Z jittered floor-wall contact produces occlusion", 2, forward_corner, &success);

    cb.depth_a = cb.clear_depth = cb.jitter_x = cb.jitter_y = 0.0f;
    cb.depth_b = 0.1f;
    generate_depth(raw, &cb, CORNER);
    cb.ao_mode = 1.0f;
    run_scene(test, &cb, raw, output);
    float tinted = min_red(output, WIDTH / 4, HEIGHT / 2, WIDTH * 3 / 4, HEIGHT * 3 / 4);
    cb.ao_mode = 0.0f;
    composite(test, &cb, output);
    float untinted = min_red(output, WIDTH / 4, HEIGHT / 2, WIDTH * 3 / 4, HEIGHT * 3 / 4);
    expect(fabsf(untinted - 0.5f) < 0.003f && tinted > 0.0f && tinted < untinted - 0.004f,
           "composite applies contact occlusion and disable restores input", 2, tinted, &success);

    free(output);
    free(raw);
    return success;
}

static int validate_snapshots(Test *test, pD3DCompile compile)
{
    char sample_writer[256];
    int length = snprintf(sample_writer, sizeof(sample_writer),
         "float WriteSamples(float4 p:SV_Position,uint s:SV_SampleIndex):SV_Depth {"
         "return s != 0 && p.x < %u.0 ? 0.0125 : 0.025; }", WIDTH / 2);
    if (length <= 0 || length >= (int)sizeof(sample_writer))
        return 0;
    ID3DBlob *blob = NULL, *messages = NULL;
    HRESULT hr = compile(sample_writer, (SIZE_T)length, "synthetic sample writer",
                         NULL, NULL, "WriteSamples", "ps_5_0", 0, 0, &blob, &messages);
    if (messages) {
        fprintf(stderr, "%s\n", (const char *)ID3D10Blob_GetBufferPointer(messages));
        ID3D10Blob_Release(messages);
    }
    require(hr, "Compile MSAA sample writer");

    ID3D11PixelShader *writer = NULL;
    require(ID3D11Device_CreatePixelShader(test->device, ID3D10Blob_GetBufferPointer(blob),
                                          ID3D10Blob_GetBufferSize(blob), NULL, &writer),
            "Create MSAA sample writer");
    ID3D10Blob_Release(blob);

    D3D11_DEPTH_STENCIL_DESC state_desc = {0};
    state_desc.DepthEnable = TRUE;
    state_desc.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ALL;
    state_desc.DepthFunc = D3D11_COMPARISON_ALWAYS;
    ID3D11DepthStencilState *state = NULL;
    require(ID3D11Device_CreateDepthStencilState(test->device, &state_desc, &state),
            "Create synthetic depth state");

    D3D11_RASTERIZER_DESC raster_desc = {0};
    raster_desc.FillMode = D3D11_FILL_SOLID;
    raster_desc.CullMode = D3D11_CULL_NONE;
    raster_desc.DepthClipEnable = TRUE;
    raster_desc.MultisampleEnable = TRUE;
    ID3D11RasterizerState *raster = NULL;
    require(ID3D11Device_CreateRasterizerState(test->device, &raster_desc, &raster),
            "Create synthetic rasterizer state");

    float *output = malloc(WIDTH * HEIGHT * CHANNELS * sizeof(float));
    if (!output)
        return 0;
    int success = 1;
    unsigned msaa_cases = 0;
    for (UINT samples = 1; samples <= 8; samples *= 2) {
        UINT levels = 0;
        require(ID3D11Device_CheckMultisampleQualityLevels(test->device, DXGI_FORMAT_D32_FLOAT_S8X24_UINT,
                                                           samples, &levels), "CheckMSAA");
        if (!levels)
            continue;
        if (samples > 1)
            ++msaa_cases;

        D3D11_TEXTURE2D_DESC desc = {0};
        desc.Width = WIDTH;
        desc.Height = HEIGHT;
        desc.MipLevels = 1;
        desc.ArraySize = 1;
        desc.Format = DXGI_FORMAT_R32G8X24_TYPELESS;
        desc.SampleDesc.Count = samples;
        desc.Usage = D3D11_USAGE_DEFAULT;
        desc.BindFlags = D3D11_BIND_DEPTH_STENCIL | D3D11_BIND_SHADER_RESOURCE;
        ID3D11Texture2D *source = NULL;
        require(ID3D11Device_CreateTexture2D(test->device, &desc, NULL, &source), "Create typed DSV input");

        D3D11_DEPTH_STENCIL_VIEW_DESC dsv_desc = {0};
        dsv_desc.Format = DXGI_FORMAT_D32_FLOAT_S8X24_UINT;
        dsv_desc.ViewDimension = samples == 1 ? D3D11_DSV_DIMENSION_TEXTURE2D : D3D11_DSV_DIMENSION_TEXTURE2DMS;
        ID3D11DepthStencilView *dsv = NULL;
        require(ID3D11Device_CreateDepthStencilView(test->device, (ID3D11Resource *)source, &dsv_desc, &dsv),
                "Create D32S8 DSV");

        ID3D11Texture2D *snapshots[2] = {0};
        ID3D11ShaderResourceView *views[2] = {0};
        desc.BindFlags = D3D11_BIND_SHADER_RESOURCE;
        D3D11_SHADER_RESOURCE_VIEW_DESC srv_desc = {0};
        srv_desc.Format = DXGI_FORMAT_R32_FLOAT_X8X24_TYPELESS;
        srv_desc.ViewDimension = samples == 1 ? D3D11_SRV_DIMENSION_TEXTURE2D : D3D11_SRV_DIMENSION_TEXTURE2DMS;
        if (samples == 1)
            srv_desc.Texture2D.MipLevels = 1;
        for (unsigned i = 0; i < 2; ++i) {
            require(ID3D11Device_CreateTexture2D(test->device, &desc, NULL, &snapshots[i]),
                    "Create matching depth snapshot");
            require(ID3D11Device_CreateShaderResourceView(test->device, (ID3D11Resource *)snapshots[i],
                                                          &srv_desc, &views[i]), "Create depth snapshot SRV");
        }

        D3D11_VIEWPORT viewport = {0, 0, (float)WIDTH, (float)HEIGHT, 0, 1};
        ID3D11DeviceContext_ClearDepthStencilView(test->context, dsv, D3D11_CLEAR_DEPTH, 0.0f, 0);
        ID3D11DeviceContext_RSSetState(test->context, raster);
        ID3D11DeviceContext_RSSetViewports(test->context, 1, &viewport);
        ID3D11DeviceContext_OMSetRenderTargets(test->context, 0, NULL, dsv);
        ID3D11DeviceContext_OMSetDepthStencilState(test->context, state, 0);
        ID3D11DeviceContext_PSSetShader(test->context, writer, NULL, 0);
        ID3D11DeviceContext_Draw(test->context, 3, 0);

        ID3D11DeviceContext_CopyResource(test->context, (ID3D11Resource *)snapshots[0], (ID3D11Resource *)source);
        ID3D11DeviceContext_OMSetRenderTargets(test->context, 0, NULL, NULL);
        ID3D11DeviceContext_CopyResource(test->context, (ID3D11Resource *)snapshots[1], (ID3D11Resource *)source);
        ID3D11DeviceContext_ClearDepthStencilView(test->context, dsv, D3D11_CLEAR_DEPTH, 0.0f, 0);
        ID3D11DeviceContext_RSSetState(test->context, NULL);
        ID3D11DeviceContext_OMSetDepthStencilState(test->context, NULL, 0);

        Constants cb = {0};
        cb.inv_w = 1.0f / WIDTH;
        cb.inv_h = 1.0f / HEIGHT;
        cb.ao_mode = 8.0f; /* Prepared depth MIP 0. */
        cb.radius = 14.0f;
        cb.quality = 2.0f;
        cb.depth_b = 0.1f;
        cb.inv_scale_y = 0.7002075f;
        cb.inv_scale_x = cb.inv_scale_y * WIDTH / HEIGHT;
        cb.samples = (float)samples;
        cb.width = WIDTH;
        cb.height = HEIGHT;
        cb.diagnostics_ready = 2.0f;
        for (unsigned i = 0; i < 2; ++i) {
            test->input_depth = views[i];
            render_depth(test, &cb, output);
            float coherent_depth = value(output, WIDTH * 3 / 4, HEIGHT / 2, 0);
            float left_depth = value(output, WIDTH / 4, HEIGHT / 2, 0);
            float expected = log2f(5.0f) / 11.0f; /* Reconstruct view Z=0.1/0.025=4. */
            int result = fabsf(coherent_depth - expected) < 0.002f;
            result = result && fabsf(left_depth - (samples == 1 ? expected : 0.0f)) < 0.002f;
            printf("%s D32S8 snapshot %ux %s DSV unbind (coherent %.6f, mixed %.6f)\n",
                   result ? "PASS" : "FAIL", samples, i == 0 ? "before" : "after", coherent_depth, left_depth);
            if (!result)
                success = 0;
        }
        for (unsigned i = 0; i < 2; ++i) {
            ID3D11ShaderResourceView_Release(views[i]);
            ID3D11Texture2D_Release(snapshots[i]);
        }
        ID3D11DepthStencilView_Release(dsv);
        ID3D11Texture2D_Release(source);
    }
    if (!msaa_cases)
        puts("SKIP MSAA depth snapshot because the adapter exposes no supported MSAA level");
    test->input_depth = NULL;
    free(output);
    ID3D11RasterizerState_Release(raster);
    ID3D11DepthStencilState_Release(state);
    ID3D11PixelShader_Release(writer);
    return success;
}

static void release_image(Image *image)
{
    if (image->rtv)
        ID3D11RenderTargetView_Release(image->rtv);
    if (image->srv)
        ID3D11ShaderResourceView_Release(image->srv);
    if (image->texture)
        ID3D11Texture2D_Release(image->texture);
}

static void cleanup(Test *test)
{
    ID3D11DeviceContext_ClearState(test->context);
    for (unsigned i = 0; i < MIPS; ++i) {
        ID3D11ShaderResourceView_Release(test->mip_srv[i]);
        ID3D11RenderTargetView_Release(test->mip_rtv[i]);
    }
    release_image(&test->raw_depth);
    release_image(&test->hierarchy);
    release_image(&test->visibility);
    release_image(&test->denoised);
    release_image(&test->color);
    release_image(&test->output);
    release_image(&test->readback);
    ID3D11SamplerState_Release(test->sampler);
    ID3D11Buffer_Release(test->constant_buffer);
    ID3D11VertexShader_Release(test->vs);
    for (unsigned i = COMPOSITE; i < SHADERS; ++i)
        ID3D11PixelShader_Release(test->ps[i]);
    ID3D11DeviceContext_Release(test->context);
    ID3D11Device_Release(test->device);
}

int main(int argc, char **argv)
{
    if (argc < 2 || argc > 3 ||
        (argc == 3 && strcmp(argv[2], "--render") != 0 && strcmp(argv[2], "--render-1440p") != 0)) {
        fprintf(stderr, "Usage: validate_d3d11 <SOURCE/src> [--render|--render-1440p]\n");
        return 2;
    }
    if (argc == 3 && strcmp(argv[2], "--render-1440p") == 0) {
        render_width = 2560;
        render_height = 1440;
    }
    HMODULE compiler = LoadLibraryW(L"d3dcompiler_47.dll");
    if (!compiler) {
        fprintf(stderr, "D3DCompiler 47 could not be loaded (%lu)\n", (unsigned long)GetLastError());
        return 1;
    }
    wchar_t compiler_path[MAX_PATH];
    if (GetModuleFileNameW(compiler, compiler_path, MAX_PATH))
        printf("D3DCompiler 47 module: %ls\n", compiler_path);
    pD3DCompile compile = (pD3DCompile)(void *)GetProcAddress(compiler, "D3DCompile");
    ID3DBlob *blobs[SHADERS] = {0};
    int success = compile && compile_shaders(compile, argv[1], blobs);
    if (success && argc == 3) {
        printf("Synthetic test resolution: %ux%u\n", WIDTH, HEIGHT);
        Test test = {0};
        setup(&test, blobs);
        success = validate_geometry(&test);
        success &= validate_snapshots(&test, compile);
        cleanup(&test);
    }
    for (unsigned i = 0; i < SHADERS; ++i)
        if (blobs[i])
            ID3D10Blob_Release(blobs[i]);
    FreeLibrary(compiler);
    return success ? 0 : 1;
}
