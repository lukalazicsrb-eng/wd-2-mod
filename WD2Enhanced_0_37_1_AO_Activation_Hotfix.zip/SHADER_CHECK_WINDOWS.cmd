@echo off
setlocal
REM DEVELOPER ONLY: fxc.exe with SM5 support is required, not needed by the player.
cd /d "%~dp0"
where fxc >NUL 2>NUL
if errorlevel 1 (echo FXC not found: install Microsoft DirectX SDK or Windows SDK with FXC. & exit /b 1)
if not exist build mkdir build
for %%E in (VSMain PSMain PSPrepare PSDownsample PSAO PSAODenoise) do (
 if "%%E"=="VSMain" (set "profile=vs_5_0") else (set "profile=ps_5_0")
 call :test %%E
 if errorlevel 1 exit /b 1
)
fxc /nologo /T ps_5_0 /E PSOverlay /Fo build\PSOverlay.cso SOURCE\src\overlay_hlsl.hlsl || exit /b 1
fxc /nologo /T ps_5_0 /E PSDepth /Fo build\PSDepth.cso SOURCE\src\depth_preview_hlsl.hlsl || exit /b 1
echo All eight Shader Model 5 shaders compiled.
exit /b 0
:test
fxc /nologo /T %profile% /E %1 /Fo build\%1.cso SOURCE\src\hlsl.hlsl
exit /b %errorlevel%
