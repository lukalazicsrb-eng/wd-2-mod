# Ispravka aktivacije AO-a u 0.37.1

Dostavljeni 0.37 log beleži čekanje na dubinu i pre promene fokusa i posle ponovnog hvatanja resursa. U oba prolaza pojavljuje se punorezolucijski 2560 × 1440 D32S8 kandidat bez MSAA. Meni 0.37 prikazuje REQUESTED i dok samo čeka na dubinu.

0.37.1 zadržava potvrđenu putanju, a prihvata i jedinstveni punorezolucijski D32S8 kandidat sa vidljivim upisom dubine u istom kadru. Kratki punorezolucijski draw pozivi koji upisuju dubinu sada ulaze u tu proveru. Snimak je privatan i zastareli kadar se odbacuje. Na promenu veličine prozora mod ponovo prikuplja dubinu i kameru.

Kada očitana projekcija za ovakav kandidat nije dostupna, mod može da proceni perspektivu sa 70° vertikalnog FOV-a i rasponom 0,1–1000, uz standardni ili obrnuti Z prema vrednosti brisanja bafera. Meni tada prikazuje **ACTIVE (EST.)**. Parametri kamere i izgled AO-a u igri čekaju proveru. HLSL i podešavanja efekata su zadržani.

## Provera

- Windows x64 DLL je izgrađen sa svih šest DirectInput izvoza. Prosleđivanje je provereno pod Wine-om.
- Prošlo je 56 provera izbora dubine, 2.844 provere projekcije i 15 referentnih matematičkih testova.
- Sintetički DX11 prozor pod Wine-om potvrdio je aktivaciju sa očitanom projekcijom i aktivaciju sa procenjenom projekcijom, pre i posle promene veličine. Dodatni režim testnog programa `validate_hook_d3d11 --wd2-compat` pokriva punorezolucijski Draw(3) upis dubine bez dostupne matrice kamere.
- Dnevnik 0.37.1 je `WD2Enhanced_0_37_1.log`.
