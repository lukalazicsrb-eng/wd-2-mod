# Izrada i provere

## Windows x64

- Pokrenite `BUILD_WINDOWS.cmd` uz x64 `clang-cl` i `lld-link` u `PATH`. Skripta generiše uvozne biblioteke iz `TOOLS/*.def` i pravi `build/dinput8.dll`.
- Posle izmene bilo kog `.hlsl` fajla pokrenite `py -3 TOOLS/embed_shaders.py`. Skripta čita ista tri fajla koja se proveravaju spoljnim kompajlerom. `--check` proverava da generisani `SOURCE/src/shaders.inc` odgovara izvoru.
- Pokrenite `SHADER_CHECK_WINDOWS.cmd` uz Microsoft FXC iz Windows SDK-a. Proverava svih osam ulaznih tačaka sa profilima Shader Model 5.
- Za instalaciju koristite `INSTALL` iz paketa ili kopirajte provereni lokalni DLL iz `build`. Igra koristi sistemski `d3dcompiler_47.dll` za kompilaciju ugrađenog HLSL-a pri inicijalizaciji.

## Dodatne provere

- `python TOOLS/verify_render_037.py` proverava matematički model renderera bez dodatnih Python paketa.
- `cc -std=c11 -Wall -Wextra -Werror -O2 TOOLS/test_projection.c -lm -o test_projection` i `./test_projection` proveravaju parser matrice koji koristi i DLL.
- `TOOLS/validate_d3d11.c` koristi Windows/D3D11 zaglavlja, `D3DCompile` i testni D3D11 uređaj. `TOOLS/validate_proxy.c` učitava spakovani DLL i proverava izvoz i DirectInput prosleđivanje. Detalji izvršene provere su u izveštaju.
- `TOOLS/validate_camera_d3d11.c` izvršava staging test. Na primer, uz MinGW-w64 koristite `x86_64-w64-mingw32-gcc -std=c11 -O2 TOOLS/validate_camera_d3d11.c -ld3d11 -o validate_camera_d3d11.exe`.
- `cc -O2 -fno-builtin -ffunction-sections -fdata-sections -Wl,--gc-sections TOOLS/test_depth_capture.c -o test_depth_capture` i `./test_depth_capture` proveravaju politiku izbora dubine i upravljanje referencama na sintetičkim COM objektima.
- `RENDER_CHECK_WINDOWS.cmd` izvršava sintetički render i proverava prosleđivanje sa isključenim grafičkim hook-om. Za 1440p pokrenite `build/validate_d3d11.exe SOURCE/src --render-1440p`.
- Iz x64 Windows SDK komandne linije `cl /nologo /O2 TOOLS\validate_hook_d3d11.c d3d11.lib user32.lib` pravi test stvarnog hook-a. Pokrenite EXE sa apsolutnom putanjom do izolovane kopije DLL-a i stavite pored nje INI opisan na početku testnog izvora. Zadržite fokus na testnom prozoru. Dnevnik beleži `AO ACTIVE` pre i posle `ResizeBuffers`.
