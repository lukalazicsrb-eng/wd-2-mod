# Izveštaj o testiranju WD2 Enhanced 0.37

| Provera | Rezultat |
| --- | --- |
| Kompilacija C koda i povezivanje DLL-a | Windows x64 PE32+ pomoću Clang/LLD 19 iz Linux okruženja. Statički importi su KERNEL32 i USER32. Pregled izvoznih tabela potvrdio je svih šest DirectInput izvoza. |
| Provera prosleđivanja | Pod Wine-om proveren je pristup svim izvozima 0.37 i uspešno dobijanje DirectInput interfejsa preko sistemskog DLL-a uz `HookEnabled=0`. Wine sistemski DLL nema `GetdfDIJoystick`, pa je u tom okruženju proveren bezbedan povratak za taj izvoz. |
| Sintetički DX11 swapchain sa završnim DLL-om | U Wine softverskom okruženju stvarni mod je presreo Present i Draw, snimio dubinu na granici odvezivanja, potvrdio projekciju i prijavio AO ACTIVE. Posle ResizeBuffers sa 640 × 360 na 800 × 450 ponovo je izabrao dubinu i prijavio AO ACTIVE. |
| Microsoft Shader Model 5 | `VSMain`, `PSMain`, `PSPrepare`, `PSDownsample`, `PSAO`, `PSAODenoise`, `PSOverlay` i `PSDepth` kompajlirani su bez dijagnostike. Korišćen je originalni Microsoft D3DCompiler 47, verzija 6.3.9600.16384, preko Wine-a. |
| Sintetičko D3D11 renderovanje i kopiranje | Proverena su 26 uslova, uključujući sva tri kvaliteta, neutralne ravne i nagnute površine, kontakt poda i zida, izolovanu siluetu, MIP nivoe, standardni i obrnuti Z, subpikselni pomeraj projekcije, AO uključen/isključen i snimke D32S8 dubine 1× i 4× pre i posle odvezivanja DSV-a. Izvršeno pri 321 × 181 i 2560 × 1440 u Wine D3D11 softverskom okruženju, feature level 11.0. |
| Rekonstrukcija projekcije | 2.798 provera C parsera, uključujući UBSan. Pokrivene su transpozicija, orijentacija, bliske/daleke tačke, standardni i obrnuti Z, beskonačna daleka ravan, različiti FOV i TAA pomeraj. |
| D3D11 kamera | Test stvarnog staging prenosa VS constant buffera i D3D11.1 opsega uspeo je u Wine softverskom okruženju. Provereni su očuvanje ranijeg prenosa posle izmene bafera, odbijanje drugog intervala brisanja i neusaglašenog pomeraja, kao i čišćenje snimaka. |
| Izbor snimka dubine | 41 provera stvarnog C selektora sa sintetičkim COM objektima. Uključuje viewport, scissor, ista i zastarela stanja, dvosmislenost, ručni izbor i reference. Dodatno je kompajlirano 38 provera D3D11 vtable i struktura uz Windows zaglavlja. |
| Referentni CPU model renderovanja | 15 sintetičkih provera pokrivaju ravne i nagnute površine, zidove, točkove, tanke objekte, vegetaciju, razdvajanje slojeva dubine, MSAA, MIP prelaze, prostorni filter i prenos u punu rezoluciju. Model računa u dvostrukoj preciznosti. |
| Watch Dogs 2, Windows 10/11 i RX 6700 XT | Igra i ciljni računar nisu bili raspoloživi. Izbor stvarnog DSV-a, projekcija igre, AO ON/OFF u igri, vožnja, promene kamere, Alt+Tab, uticaj na FPS i izgled stakla čekaju proveru na ciljnoj konfiguraciji. |

U priloženom 0.36 logu bilo je 130 prelaza na obradu bez AO. Njih 128 neposredno sledi isključenje i ponovno uključivanje AO iz F8 putanje. Kod 0.36 preskače praćenje dubine dok je zahtev isključen, pa ponovno uključivanje može zateći isti kadar bez tekućih podataka. Dve preostale poruke neposredno slede zabeleženo brisanje posle poslednjeg praćenog draw poziva. Log ne pokazuje nameru iza unosa u meniju.

Bela u AO maski 0.36 označava i izostanak zatamnjenja i određena odbijanja. Dostavljeni kadar igre nema identičan kadar sa isključenim AO za poređenje, pa uzrok tamnih delova kolovoza ostaje nepotvrđen. U 0.37 su pokrivenost, validnost, razlozi odbijanja i konačna maska zasebni prikazi.
