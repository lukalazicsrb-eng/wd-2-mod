# Mafia 3 GTAO referenca koju je korisnik dostavio

- `REFERENCE_MAFIA3/gtao_user_supplied.hlsl` je korisnikov dostavljeni shader radi poređenja, **nije učitan ili uključen u WD2 DLL**.
- Preuzimanje tuđeg DLL-a nije potrebno: ključna razlika je što Mafia 3 HBAO+ hook dobija `gP00`, `gP11`, `gZA`, `gZB`, pravi viewport i dubinu iz igre. Naš WD2 DX11 Present mod i dalje procenjuje FOV 70°, near 0.1 i far 1000.
- Korisnički HLSL u `GtaoPS` eksplicitno ograničava horizon lukove `a0`, `a1` oko projektovane normale. Sličan guard dodat je u 0.36 WD2 shader.
- U Mafia 3 pristupu GTAO pass radi nad dubinom koju je engine predao HBAO+ pipeline-u; naš WD2 `Present` obrađuje već komponovanu sliku i ne može bez dodatne integracije ispravno razdvojiti staklo i sadržaj iza njega.
- Originalni Mafia 3 `dinput8(6).dll` nije kopiran niti linkovan: njegova vtable logika i memory offsets za taj engine ne bi bili validni u Watch Dogs 2.
- Intelov XeGTAO inspirisani kod zadržava MIT licencu u `DOCS/INTEL_XEGTAO_MIT_LICENSE.txt`.
