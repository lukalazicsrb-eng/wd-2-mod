@echo off
setlocal
REM Developer script; player copies INSTALL\dinput8.dll and WD2Enhanced.ini only.
REM Requires clang-cl, lld-link in PATH. No Windows SDK import libraries needed.
cd /d "%~dp0"
if not exist build mkdir build
where py >NUL 2>NUL
if not errorlevel 1 (
 py -3 TOOLS\embed_shaders.py --check
 if errorlevel 1 exit /b 1
)
lld-link /nologo /DLL /NOENTRY /MACHINE:X64 /DEF:TOOLS\kernel32.def /OUT:build\kernel32_import_stub.dll /IMPLIB:build\kernel32.lib
if errorlevel 1 exit /b 1
lld-link /nologo /DLL /NOENTRY /MACHINE:X64 /DEF:TOOLS\user32.def /OUT:build\user32_import_stub.dll /IMPLIB:build\user32.lib
if errorlevel 1 exit /b 1
clang-cl /nologo /c /O2 /GS- /Zl /Fo:build\native.obj SOURCE\src\native.c
if errorlevel 1 exit /b 1
lld-link /nologo /DLL /MACHINE:X64 /ENTRY:DllMain /NODEFAULTLIB /OPT:REF /OPT:ICF /OUT:build\dinput8.dll build\native.obj build\kernel32.lib build\user32.lib
if errorlevel 1 exit /b 1
echo Built build\dinput8.dll. Run SHADER_CHECK_WINDOWS.cmd for independent shader verification.
