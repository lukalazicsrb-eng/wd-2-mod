# WD2 Enhanced 0.39

Za postojeću instalaciju 0.38, zatvori igru i zameni `dinput8.dll` iz `INSTALL`. Zadrži svoj `WD2Enhanced.ini` radi podešavanja. Na vrhu F8 menija treba da piše **0.39**.

0.39 dodaje proveru WD2 `cbViewport` projekcije uz postojeći XeGTAO. FSR upscaling u igri ostaje nedostupan u ovom DLL-u. ZIP sadrži samostalni AMD FSR 1.0 DX11 alat za slike i dokumentuje odvojenu Luma FSR 3.1.2 opciju. Pogledaj `DOCS/FSR_BACKENDS_SR.md` i `DOCS/FSR1_LAB_SR.md`.

Samostalni DirectX 11 grafički mod za Watch Dogs 2 na Windowsu 10/11 x64. Paket je namenjen igranju van mreže u režimu za jednog igrača. Testiranje u samoj igri i na Radeon RX 6700 XT ostaje otvoreno.

## Instalacija

1. Potpuno zatvorite igru. U Epic Games biblioteci pronađite instalacioni direktorijum igre i otvorite poddirektorijum `bin` u kome se nalazi `WatchDogs2.exe`.
2. Ako u `bin` već postoje `dinput8.dll` ili `WD2Enhanced.ini`, sačuvajte ih izvan direktorijuma igre. Zatim kopirajte oba fajla iz `INSTALL` pored `WatchDogs2.exe`.
3. Pokrenite igru u DX11 režimu za jednog igrača van mreže. Nakon početnog odlaganja i prvih prezentovanih kadrova, pritisnite **F8** za meni. **Tab** otvara **Developer Options**. **F9** menja status oštrenja i korekcije boje nezavisno od AO.
4. U meniju **XeGTAO** uključuje zahtev za AO, a status pri dnu pokazuje da li je efekat aktivan. Profil Balanced je početni, sa kvalitetom High. Kompatibilni snimak dubine iz tekućeg kadra može da koristi procenjenu kameru kada očitavanje projekcije iz igre nije uspelo. Meni tada prikazuje **ACTIVE (EST.)**. Bez odgovarajuće dubine i dalje rade oštrenje i boje.

Za povratak uklonite kopirane fajlove dok je igra zatvorena i vratite prethodno sačuvane fajlove. `BACKUP_0_38` sadrži prethodni DLL i INI. `BACKUP_0_37_1` sadrži starije izdanje. `BACKUP_0_36` sadrži DLL i INI verzije iz dostavljenog projekta 0.36.

## Dijagnostika

**AO visualization** koristi podatke aktivnog renderera. Konačna AO maska prikazuje belu gde nema zatamnjenja. Ako AO čeka, Developer Options prikazuje utvrđenu prepreku ispod stanja. Dostupni su sirovi uzorak dubine, rekonstruisana Z dubina u prostoru kamere, validnost, pokrivenost, normale, pet pripremljenih MIP nivoa, sirova i filtrirana vidljivost i mapa odbijanja. **F10** prikazuje zaseban probni prikaz kandidata, **F11** menja kandidata, a **F12** režim probnog prikaza. Njegove procenjene vrednosti služe za pregled. **AO projection** razlikuje potvrđen raspored CBVIEWPORT, očitavanje standardne matrice i procenu. Zatvaranje F8 menija i prelazak u Player Settings gase dijagnostičke prikaze.

| Boja u mapi odbijanja | Značenje |
| --- | --- |
| Zelena | Uzorak je prihvaćen |
| Magenta | Dubina je na vrednosti brisanja, na primer na nebu |
| Crvena | Sirovi uzorak je nevažeći |
| Narandžasta | MSAA uzorci se ne slažu |
| Ljubičasta | Projekcija daje nevažeću Z dubinu |
| Žuta | Otisak jednog polurezolucijskog piksela prelazi između površina |
| Cijan | Nema pouzdane normale |
| Losos | Nema odgovarajućeg uzorka za punu rezoluciju |
| Plava | Nema potvrđene projekcije |
| Siva | AO prolazi nisu raspoloživi |
| Tamnoplava | Nema snimljene dubine |

Dnevnik `WD2Enhanced_0_39.log` nastaje pored DLL-a. Prikazuje trajne promene AO stanja i odabranu granicu snimanja dubine. Za isključivanje celog grafičkog hook-a postavite `HookEnabled=0` u sekciji `Diagnostics` pre pokretanja igre. Prosleđivanje DirectInput poziva ostaje dostupno.

## Izvorni kod

`SOURCE/src` sadrži freestanding C kod, HLSL i generisani C sadržaj shadera. `DOCS` sadrži beleške o izradi, proverama, ograničenjima i Intel MIT licencu.
