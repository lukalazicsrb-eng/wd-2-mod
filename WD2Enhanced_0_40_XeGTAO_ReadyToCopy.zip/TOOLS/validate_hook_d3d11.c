/* Synthetic swap chain for exercising the real proxy and DX11 hooks.
   Use a copy of INSTALL/dinput8.dll in an isolated directory, and place
   WD2Enhanced.ini there with the values below. Run while the test window
   has focus. The game is not used.

   [Graphics]
   EffectEnabled=1
   [AOPrototype]
   Enabled=1
   [Diagnostics]
   HookEnabled=1
   StartupDelayMs=10000
   PassthroughFrames=30
*/
#define COBJMACROS
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <d3d11.h>
#include <d3d11_1.h>
#include <d3dcompiler.h>
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>

#define CHECK(call) do { \
    HRESULT result = (call); \
    if (FAILED(result)) { \
        fprintf(stderr, "%s failed (0x%08lx)\n", #call, (unsigned long)result); \
        exit(1); \
    } \
} while (0)

static const char shader[] =
    "cbuffer Camera:register(b0){row_major float4x4 proj;}"
    "float4 VSMain(uint id:SV_VertexID):SV_Position{"
    "float2 points[6]={float2(-1,-1),float2(-1,1),float2(1,1),"
    "float2(-1,-1),float2(1,1),float2(1,-1)};"
    "float z=4;return mul(float4(points[id]*z/float2(proj[0][0],proj[1][1]),z,1),proj);}"
    "float4 VSCompat(uint id:SV_VertexID):SV_Position{"
    "float2 p=float2((id<<1)&2,id&2);"
    "return float4(p*float2(2,-2)+float2(-1,1),.025,1);}"
    "float4 PSMain():SV_Target{return float4(.5,.5,.5,1);}";

typedef struct {
    ID3D11Texture2D *depth, *back;
    ID3D11RenderTargetView *rtv;
    ID3D11DepthStencilView *dsv;
} Targets;

static void create_targets(ID3D11Device *device, IDXGISwapChain *swapchain,
                           UINT width, UINT height, Targets *targets, int compatibility)
{
    const GUID texture_id = {0x6f15aaf2,0xd208,0x4e89,{0x9a,0xb4,0x48,0x95,0x35,0xd3,0x4f,0x9c}};
    CHECK(IDXGISwapChain_GetBuffer(swapchain, 0, &texture_id, (void **)&targets->back));
    CHECK(ID3D11Device_CreateRenderTargetView(device, (ID3D11Resource *)targets->back,
                                              NULL, &targets->rtv));
    D3D11_TEXTURE2D_DESC desc = {0};
    desc.Width = width;
    desc.Height = height;
    desc.MipLevels = desc.ArraySize = 1;
    desc.SampleDesc.Count = 1;
    desc.Format = DXGI_FORMAT_R32G8X24_TYPELESS;
    desc.BindFlags = D3D11_BIND_DEPTH_STENCIL;
    if (compatibility)
        desc.BindFlags |= D3D11_BIND_SHADER_RESOURCE;
    CHECK(ID3D11Device_CreateTexture2D(device, &desc, NULL, &targets->depth));
    D3D11_DEPTH_STENCIL_VIEW_DESC view = {0};
    view.Format = DXGI_FORMAT_D32_FLOAT_S8X24_UINT;
    view.ViewDimension = D3D11_DSV_DIMENSION_TEXTURE2D;
    CHECK(ID3D11Device_CreateDepthStencilView(device, (ID3D11Resource *)targets->depth,
                                              &view, &targets->dsv));
}

static void release_targets(Targets *targets)
{
    ID3D11RenderTargetView_Release(targets->rtv);
    ID3D11DepthStencilView_Release(targets->dsv);
    ID3D11Texture2D_Release(targets->back);
    ID3D11Texture2D_Release(targets->depth);
}

static ID3DBlob *compile_entry(pD3DCompile compile, const char *entry, const char *profile)
{
    ID3DBlob *bytecode = NULL, *messages = NULL;
    HRESULT hr = compile(shader, sizeof(shader) - 1, "synthetic geometry", NULL, NULL,
                         entry, profile, 0, 0, &bytecode, &messages);
    if (messages) {
        fputs((const char *)ID3D10Blob_GetBufferPointer(messages), stderr);
        ID3D10Blob_Release(messages);
    }
    CHECK(hr);
    return bytecode;
}

static int wait_for_draws(ID3D11DeviceContext *context, ID3D11Query *query)
{
    ID3D11DeviceContext_End(context, (ID3D11Asynchronous *)query);
    ID3D11DeviceContext_Flush(context);
    ULONGLONG start = GetTickCount64();
    for (;;) {
        HRESULT hr = ID3D11DeviceContext_GetData(context, (ID3D11Asynchronous *)query, NULL, 0, 0);
        CHECK(hr);
        if (hr != S_FALSE)
            return 1;
        if (GetTickCount64() - start > 5000)
            return 0;
        Sleep(1);
    }
}

static void write_viewport_constants(float data[272], UINT width, UINT height)
{
    const float sx=1.5f*(float)height/(float)width, sy=1.5f, near_z=0.1f;
    float *matrix=data+24*4, *inverse=data+9*4;
    data[0]=2*near_z/sx; data[1]=2*near_z/sy;
    data[66*4]=(float)width; data[66*4+1]=(float)height;
    data[66*4+2]=1.0f/(float)width; data[66*4+3]=1.0f/(float)height;
    data[67*4]=near_z;
    matrix[0]=sx; matrix[5]=sy; matrix[11]=near_z; matrix[14]=1.0f;
    inverse[0]=1.0f/sx; inverse[5]=1.0f/sy; inverse[11]=1.0f; inverse[14]=1.0f/near_z;
}

int wmain(int argc, wchar_t **argv)
{
    int compatibility = 0, mutation = 0, viewport_camera = 0, resize = 1;
    int valid = argc >= 2;
    for (int i = 2; i < argc; ++i) {
        if (wcscmp(argv[i], L"--wd2-compat") == 0 && !compatibility) {
            compatibility = 1;
        } else if (wcscmp(argv[i], L"--wd2-mutation") == 0 && !compatibility) {
            compatibility = mutation = 1;
        } else if (wcscmp(argv[i], L"--wd2-viewport") == 0 && !compatibility) {
            compatibility = viewport_camera = 1;
        } else if (wcscmp(argv[i], L"--no-resize") == 0 && resize) {
            resize = 0;
        } else {
            valid = 0;
        }
    }
    if (!valid) {
        fprintf(stderr, "Usage: validate_hook_d3d11 <DLL path> [--wd2-compat|--wd2-mutation|--wd2-viewport] [--no-resize]\n");
        return 2;
    }
    HWND window = CreateWindowExW(0, L"STATIC", L"WD2 synthetic DX11 smoke",
        WS_OVERLAPPEDWINDOW | WS_VISIBLE, 30, 30, 800, 480, NULL, NULL, NULL, NULL);
    if (!window)
        return 1;
    SetForegroundWindow(window);

    UINT width = 640, height = 360;
    DXGI_SWAP_CHAIN_DESC desc = {0};
    desc.BufferDesc.Width = width;
    desc.BufferDesc.Height = height;
    desc.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    desc.SampleDesc.Count = 1;
    desc.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    desc.BufferCount = 1;
    desc.OutputWindow = window;
    desc.Windowed = TRUE;
    IDXGISwapChain *swapchain = NULL;
    ID3D11Device *device = NULL;
    ID3D11DeviceContext *context = NULL;
    CHECK(D3D11CreateDeviceAndSwapChain(NULL, D3D_DRIVER_TYPE_HARDWARE, NULL, 0, NULL, 0,
                                       D3D11_SDK_VERSION, &desc, &swapchain, &device, NULL, &context));
    ID3D11DeviceContext1 *context1 = NULL;
    if (mutation) {
        const GUID context1_id = {0xbb2c6faa,0xb5fb,0x4082,{0x8e,0x6b,0x38,0x8b,0x8c,0xfa,0x90,0xe1}};
        CHECK(ID3D11DeviceContext_QueryInterface(context, &context1_id, (void **)&context1));
        if ((void *)context1 != (void *)context) {
            fprintf(stderr, "DiscardView test needs the hooked immediate-context vtable\n");
            return 1;
        }
    }

    HMODULE proxy = LoadLibraryW(argv[1]);
    HMODULE compiler = LoadLibraryW(L"d3dcompiler_47.dll");
    if (!proxy || !compiler)
        return 1;
    typedef HRESULT (WINAPI *StartProxy)(void);
    StartProxy start_proxy = (StartProxy)(void *)GetProcAddress(proxy, "DllCanUnloadNow");
    pD3DCompile compile = (pD3DCompile)(void *)GetProcAddress(compiler, "D3DCompile");
    if (!start_proxy || !compile)
        return 1;
    CHECK(start_proxy());

    ID3D11VertexShader *vs = NULL;
    ID3D11PixelShader *ps = NULL;
    ID3DBlob *blob = compile_entry(compile, compatibility ? "VSCompat" : "VSMain", "vs_5_0");
    CHECK(ID3D11Device_CreateVertexShader(device, ID3D10Blob_GetBufferPointer(blob),
                                          ID3D10Blob_GetBufferSize(blob), NULL, &vs));
    ID3D10Blob_Release(blob);
    blob = compile_entry(compile, "PSMain", "ps_5_0");
    CHECK(ID3D11Device_CreatePixelShader(device, ID3D10Blob_GetBufferPointer(blob),
                                         ID3D10Blob_GetBufferSize(blob), NULL, &ps));
    ID3D10Blob_Release(blob);

    /* A 70 degree, 16:9, infinite-far, reverse-Z scene projection. */
    float projection[16] = {0};
    projection[0] = 1.428148f * 9 / 16;
    projection[5] = 1.428148f;
    projection[11] = 1.0f;
    projection[14] = 0.1f;
    D3D11_BUFFER_DESC cb_desc = {0};
    cb_desc.ByteWidth = sizeof(projection);
    cb_desc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
    D3D11_SUBRESOURCE_DATA cb_data = {projection, 0, 0};
    ID3D11Buffer *cb = NULL;
    CHECK(ID3D11Device_CreateBuffer(device, &cb_desc, &cb_data, &cb));

    ID3D11Buffer *viewport_buffer = NULL;
    if (viewport_camera) {
        cb_desc.ByteWidth=272*sizeof(float);
        CHECK(ID3D11Device_CreateBuffer(device,&cb_desc,NULL,&viewport_buffer));
    }
    D3D11_DEPTH_STENCIL_DESC depth_desc = {0};
    depth_desc.DepthEnable = TRUE;
    depth_desc.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ALL;
    depth_desc.DepthFunc = compatibility ? D3D11_COMPARISON_ALWAYS : D3D11_COMPARISON_GREATER_EQUAL;
    ID3D11DepthStencilState *depth_state = NULL;
    CHECK(ID3D11Device_CreateDepthStencilState(device, &depth_desc, &depth_state));

    D3D11_RASTERIZER_DESC raster_desc = {0};
    raster_desc.FillMode = D3D11_FILL_SOLID;
    raster_desc.CullMode = D3D11_CULL_NONE;
    raster_desc.DepthClipEnable = TRUE;
    ID3D11RasterizerState *raster = NULL;
    CHECK(ID3D11Device_CreateRasterizerState(device, &raster_desc, &raster));
    D3D11_QUERY_DESC query_desc = {D3D11_QUERY_EVENT, 0};
    ID3D11Query *query = NULL;
    CHECK(ID3D11Device_CreateQuery(device, &query_desc, &query));
    Targets targets;
    create_targets(device, swapchain, width, height, &targets, compatibility);

    Sleep(11000); /* Give the configured 10-second delayed hook time to install. */
    puts("Starting synthetic Present sequence");
    for (unsigned frame = 0; frame < 100; ++frame) {
        MSG message;
        while (PeekMessageW(&message, NULL, 0, 0, PM_REMOVE)) {
            TranslateMessage(&message);
            DispatchMessageW(&message);
        }
        if (resize && frame == 60) {
            ID3D11DeviceContext_OMSetRenderTargets(context, 0, NULL, NULL);
            release_targets(&targets);
            width = 800;
            height = 450;
            CHECK(IDXGISwapChain_ResizeBuffers(swapchain, 0, width, height, DXGI_FORMAT_UNKNOWN, 0));
            create_targets(device, swapchain, width, height, &targets, compatibility);
        }
        D3D11_VIEWPORT viewport = {0, 0, (float)width, (float)height, 0, 1};
        ID3D11DeviceContext_RSSetViewports(context, 1, &viewport);
        ID3D11DeviceContext_RSSetState(context, raster);
        ID3D11DeviceContext_OMSetDepthStencilState(context, depth_state, 0);
        ID3D11DeviceContext_OMSetRenderTargets(context, 1, &targets.rtv, targets.dsv);
        ID3D11DeviceContext_ClearDepthStencilView(context, targets.dsv, D3D11_CLEAR_DEPTH,
                                                    mutation ? 0.00001f : 0.0f, 0);
        ID3D11DeviceContext_IASetPrimitiveTopology(context, D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
        if (!compatibility)
            ID3D11DeviceContext_VSSetConstantBuffers(context, 0, 1, &cb);
        ID3D11DeviceContext_VSSetShader(context, vs, NULL, 0);
        ID3D11DeviceContext_PSSetShader(context, ps, NULL, 0);
        if (viewport_camera) {
            float data[272]={0};
            write_viewport_constants(data,width,height);
            ID3D11DeviceContext_UpdateSubresource(context,(ID3D11Resource *)viewport_buffer,0,NULL,data,0,0);
            ID3D11DeviceContext_PSSetConstantBuffers(context,0,1,&viewport_buffer);
        }
        if (compatibility) {
            if (mutation)
                ID3D11DeviceContext1_DiscardView(context1, (ID3D11View *)targets.dsv);
            ID3D11DeviceContext_Draw(context, 3, 0);
            if (mutation)
                ID3D11DeviceContext1_DiscardView(context1, (ID3D11View *)targets.dsv);
        } else {
            for (unsigned draw = 0; draw < 8; ++draw)
                ID3D11DeviceContext_DrawInstanced(context, 6, 1, 0, 0);
        }

        ID3D11DeviceContext_OMSetRenderTargets(context, 0, NULL, NULL);
        if (!wait_for_draws(context, query)) {
            fprintf(stderr, "Synthetic draws did not finish\n");
            return 1;
        }
        CHECK(IDXGISwapChain_Present(swapchain, 0, 0));
        Sleep(25); /* Observe the mod's debounced AO state in the log. */
    }
    puts(resize ? "Synthetic render with resize returned successfully" :
                  "Synthetic render without resize returned successfully");
    ID3D11DeviceContext_ClearState(context);
    release_targets(&targets);
    ID3D11Query_Release(query);
    ID3D11RasterizerState_Release(raster);
    ID3D11DepthStencilState_Release(depth_state);
    if (viewport_buffer) ID3D11Buffer_Release(viewport_buffer);
    ID3D11Buffer_Release(cb);
    ID3D11VertexShader_Release(vs);
    ID3D11PixelShader_Release(ps);
    IDXGISwapChain_Release(swapchain);
    if (context1)
        ID3D11DeviceContext1_Release(context1);
    ID3D11DeviceContext_Release(context);
    ID3D11Device_Release(device);
    FreeLibrary(compiler);
    DestroyWindow(window);
    return 0;
}
