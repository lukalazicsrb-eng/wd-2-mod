/* Standalone proof of the AMD FSR 1.0 EASU and RCAS passes on D3D11/SM5.
   The tool reads a display-referred 24-bit BMP. It does not attach to a game. */
#define COBJMACROS
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <d3d11.h>
#include <d3dcompiler.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>

typedef struct { UINT width, height; unsigned char *rgba; } Image;
typedef struct {
    ID3D11Device *device;
    ID3D11DeviceContext *context;
    ID3D11VertexShader *vertex;
    ID3D11PixelShader *easu, *rcas;
    ID3D11Buffer *constants;
    ID3D11SamplerState *sampler;
} Renderer;

#define CHECK(call) do { \
    HRESULT result = (call); \
    if (FAILED(result)) { fprintf(stderr, "%s failed (0x%08lx)\n", #call, (unsigned long)result); exit(1); } \
} while (0)

static int image_allocate(Image *image, UINT width, UINT height)
{
    if (!width || !height || width > 8192 || height > 8192) return 0;
    image->rgba = malloc((size_t)width * height * 4);
    image->width = width;
    image->height = height;
    return image->rgba != NULL;
}

static int bmp_read(const wchar_t *name, Image *image)
{
    FILE *file = _wfopen(name, L"rb");
    if (!file) return 0;
    BITMAPFILEHEADER header;
    BITMAPINFOHEADER info;
    int success = fread(&header, sizeof(header), 1, file) == 1 &&
        fread(&info, sizeof(info), 1, file) == 1 && header.bfType == 0x4d42 &&
        info.biSize >= sizeof(info) && header.bfOffBits >= sizeof(header) + sizeof(info) &&
        info.biSize <= header.bfOffBits - sizeof(header) &&
        header.bfOffBits <= INT32_MAX && info.biPlanes == 1 &&
        info.biBitCount == 24 && info.biCompression == BI_RGB &&
        info.biWidth > 0 && info.biHeight && info.biHeight >= -8192 &&
        image_allocate(image, (UINT)info.biWidth, (UINT)abs(info.biHeight));
    unsigned char *line = NULL;
    if (success) {
        UINT stride = (image->width * 3 + 3) & ~3u;
        line = malloc(stride);
        success = line && fseek(file, (long)header.bfOffBits, SEEK_SET) == 0;
        for (UINT y = 0; y < image->height && success; ++y) {
            success = fread(line, stride, 1, file) == 1;
            if (!success) break;
            UINT iy = info.biHeight > 0 ? image->height - 1 - y : y;
            for (UINT x = 0; x < image->width; ++x) {
                unsigned char *pixel = image->rgba + ((size_t)iy * image->width + x) * 4;
                pixel[0]=line[3*x+2]; pixel[1]=line[3*x+1]; pixel[2]=line[3*x]; pixel[3]=255;
            }
        }
    }
    free(line);
    fclose(file);
    return success;
}

static int bmp_write(const wchar_t *name, const Image *image)
{
    FILE *file = _wfopen(name, L"wb");
    if (!file) return 0;
    UINT stride = (image->width * 3 + 3) & ~3u;
    UINT offset = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);
    BITMAPFILEHEADER header = {0x4d42,offset+stride*image->height,0,0,offset};
    BITMAPINFOHEADER info = {0};
    info.biSize=sizeof(info); info.biWidth=image->width; info.biHeight=-(LONG)image->height;
    info.biPlanes=1; info.biBitCount=24; info.biCompression=BI_RGB;
    unsigned char *line = calloc(stride, 1);
    int success = line && fwrite(&header, sizeof(header), 1, file) == 1 &&
        fwrite(&info, sizeof(info), 1, file) == 1;
    for (UINT y = 0; y < image->height && success; ++y) {
        for (UINT x = 0; x < image->width; ++x) {
            const unsigned char *pixel = image->rgba + ((size_t)y * image->width+x)*4;
            line[3*x]=pixel[2]; line[3*x+1]=pixel[1]; line[3*x+2]=pixel[0];
        }
        success = fwrite(line, stride, 1, file) == 1;
    }
    free(line);
    return fclose(file) == 0 && success;
}

typedef HRESULT (WINAPI *CompileFile)(LPCWSTR, const D3D_SHADER_MACRO *, ID3DInclude *,
                                      LPCSTR, LPCSTR, UINT, UINT, ID3DBlob **, ID3DBlob **);
static ID3DBlob *compile(CompileFile compiler, const wchar_t *shader,
                         const char *entry, const char *profile)
{
    ID3DBlob *code = NULL, *messages = NULL;
    HRESULT hr = compiler(shader,NULL,D3D_COMPILE_STANDARD_FILE_INCLUDE,entry,profile,
                           D3DCOMPILE_ENABLE_STRICTNESS,0,&code,&messages);
    if (messages) {
        fputs((const char *)ID3D10Blob_GetBufferPointer(messages),stderr);
        ID3D10Blob_Release(messages);
    }
    CHECK(hr);
    return code;
}

static void renderer_init(Renderer *r, const wchar_t *shader, int software)
{
    HMODULE module = LoadLibraryW(L"d3dcompiler_47.dll");
    CompileFile compiler=module?(CompileFile)(void *)GetProcAddress(module,"D3DCompileFromFile"):NULL;
    if(!compiler){fputs("D3DCompiler 47 is unavailable\n",stderr);exit(1);}
    D3D_FEATURE_LEVEL level = D3D_FEATURE_LEVEL_11_0;
    CHECK(D3D11CreateDevice(NULL,software?D3D_DRIVER_TYPE_WARP:D3D_DRIVER_TYPE_HARDWARE,
                           NULL,0,&level,1,D3D11_SDK_VERSION,&r->device,NULL,&r->context));
    ID3DBlob *code=compile(compiler,shader,"VSMain","vs_5_0");
    CHECK(ID3D11Device_CreateVertexShader(r->device,ID3D10Blob_GetBufferPointer(code),
        ID3D10Blob_GetBufferSize(code),NULL,&r->vertex));
    ID3D10Blob_Release(code);
    code=compile(compiler,shader,"PSEasu","ps_5_0");
    CHECK(ID3D11Device_CreatePixelShader(r->device,ID3D10Blob_GetBufferPointer(code),
        ID3D10Blob_GetBufferSize(code),NULL,&r->easu));
    ID3D10Blob_Release(code);
    code=compile(compiler,shader,"PSRcas","ps_5_0");
    CHECK(ID3D11Device_CreatePixelShader(r->device,ID3D10Blob_GetBufferPointer(code),
        ID3D10Blob_GetBufferSize(code),NULL,&r->rcas));
    ID3D10Blob_Release(code);
    D3D11_BUFFER_DESC buffer = {0};
    buffer.ByteWidth=32; buffer.BindFlags=D3D11_BIND_CONSTANT_BUFFER;
    CHECK(ID3D11Device_CreateBuffer(r->device,&buffer,NULL,&r->constants));
    D3D11_SAMPLER_DESC sampler={0};
    sampler.Filter=D3D11_FILTER_MIN_MAG_LINEAR_MIP_POINT;
    sampler.AddressU=sampler.AddressV=sampler.AddressW=D3D11_TEXTURE_ADDRESS_CLAMP;
    sampler.ComparisonFunc=D3D11_COMPARISON_NEVER;
    sampler.MaxLOD=D3D11_FLOAT32_MAX;
    CHECK(ID3D11Device_CreateSamplerState(r->device,&sampler,&r->sampler));
    FreeLibrary(module);
}

static void renderer_destroy(Renderer *r)
{
    ID3D11DeviceContext_ClearState(r->context);
    ID3D11SamplerState_Release(r->sampler);
    ID3D11Buffer_Release(r->constants);
    ID3D11PixelShader_Release(r->rcas);
    ID3D11PixelShader_Release(r->easu);
    ID3D11VertexShader_Release(r->vertex);
    ID3D11DeviceContext_Release(r->context);
    ID3D11Device_Release(r->device);
}

static D3D11_TEXTURE2D_DESC describe(UINT width, UINT height, UINT bind)
{
    D3D11_TEXTURE2D_DESC desc={0};
    desc.Width=width;desc.Height=height;desc.MipLevels=desc.ArraySize=1;
    desc.Format=DXGI_FORMAT_R8G8B8A8_UNORM;desc.SampleDesc.Count=1;desc.BindFlags=bind;
    return desc;
}

static void draw(Renderer *r, ID3D11PixelShader *shader, ID3D11Texture2D *source,
                 ID3D11Texture2D *target, const float constants[8])
{
    ID3D11ShaderResourceView *srv = NULL, *unbound = NULL;
    ID3D11RenderTargetView *rtv = NULL;
    CHECK(ID3D11Device_CreateShaderResourceView(r->device,(ID3D11Resource *)source,NULL,&srv));
    CHECK(ID3D11Device_CreateRenderTargetView(r->device,(ID3D11Resource *)target,NULL,&rtv));
    D3D11_VIEWPORT viewport={0,0,constants[4],constants[5],0,1};
    ID3D11DeviceContext_UpdateSubresource(r->context,(ID3D11Resource *)r->constants,0,NULL,constants,0,0);
    ID3D11DeviceContext_IASetPrimitiveTopology(r->context,D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
    ID3D11DeviceContext_VSSetShader(r->context,r->vertex,NULL,0);
    ID3D11DeviceContext_RSSetViewports(r->context,1,&viewport);
    ID3D11DeviceContext_OMSetRenderTargets(r->context,1,&rtv,NULL);
    ID3D11DeviceContext_PSSetShader(r->context,shader,NULL,0);
    ID3D11DeviceContext_PSSetConstantBuffers(r->context,0,1,&r->constants);
    ID3D11DeviceContext_PSSetSamplers(r->context,0,1,&r->sampler);
    ID3D11DeviceContext_PSSetShaderResources(r->context,0,1,&srv);
    ID3D11DeviceContext_Draw(r->context,3,0);
    ID3D11DeviceContext_PSSetShaderResources(r->context,0,1,&unbound);
    ID3D11DeviceContext_OMSetRenderTargets(r->context,0,NULL,NULL);
    ID3D11RenderTargetView_Release(rtv);
    ID3D11ShaderResourceView_Release(srv);
}

static void upscale(Renderer *r, const Image *source, Image *output, float sharpness)
{
    ID3D11Texture2D *input=NULL,*scaled=NULL,*sharpened=NULL,*staging=NULL;
    D3D11_TEXTURE2D_DESC desc=describe(source->width,source->height,D3D11_BIND_SHADER_RESOURCE);
    D3D11_SUBRESOURCE_DATA data={source->rgba,4*source->width,0};
    CHECK(ID3D11Device_CreateTexture2D(r->device,&desc,&data,&input));
    desc=describe(output->width,output->height,D3D11_BIND_RENDER_TARGET|D3D11_BIND_SHADER_RESOURCE);
    CHECK(ID3D11Device_CreateTexture2D(r->device,&desc,NULL,&scaled));
    float settings[8]={(float)source->width,(float)source->height,
        (float)source->width,(float)source->height,(float)output->width,(float)output->height,sharpness,0};
    draw(r,r->easu,input,scaled,settings);
    if(sharpness>=0){
        CHECK(ID3D11Device_CreateTexture2D(r->device,&desc,NULL,&sharpened));
        draw(r,r->rcas,scaled,sharpened,settings);
    }
    desc=describe(output->width,output->height,0);
    desc.Usage=D3D11_USAGE_STAGING; desc.CPUAccessFlags=D3D11_CPU_ACCESS_READ;
    CHECK(ID3D11Device_CreateTexture2D(r->device,&desc,NULL,&staging));
    ID3D11DeviceContext_CopyResource(r->context,(ID3D11Resource *)staging,
                                     (ID3D11Resource *)(sharpened?sharpened:scaled));
    D3D11_MAPPED_SUBRESOURCE mapping;
    CHECK(ID3D11DeviceContext_Map(r->context,(ID3D11Resource *)staging,0,D3D11_MAP_READ,0,&mapping));
    for(UINT y=0;y<output->height;++y)
        memcpy(output->rgba+(size_t)y*4*output->width,(const char *)mapping.pData+(size_t)y*mapping.RowPitch,
               4*output->width);
    ID3D11DeviceContext_Unmap(r->context,(ID3D11Resource *)staging,0);
    ID3D11Texture2D_Release(staging);
    if(sharpened)ID3D11Texture2D_Release(sharpened);
    ID3D11Texture2D_Release(scaled);
    ID3D11Texture2D_Release(input);
}

static int self_test(Renderer *r)
{
    Image source={0},easu={0},rcas={0};
    int pass=0;
    if(!image_allocate(&source,29,17)||!image_allocate(&easu,57,33)||!image_allocate(&rcas,57,33))
        goto done;
    memset(source.rgba,117,(size_t)source.width*source.height*4);
    upscale(r,&source,&rcas,0.75f);
    for(size_t i=0;i<(size_t)rcas.width*rcas.height;++i)
        if(abs(rcas.rgba[i*4]-117)>1||abs(rcas.rgba[i*4+1]-117)>1||abs(rcas.rgba[i*4+2]-117)>1)
            goto done;
    puts("PASS flat RGB is preserved with odd input and output dimensions");
    for(UINT y=0;y<source.height;++y)
        for(UINT x=0;x<source.width;++x){
            unsigned char value=x*2+3>y?(unsigned char)(160+2*x):(unsigned char)(30+2*y);
            unsigned char *pixel=source.rgba+((size_t)y*source.width+x)*4;
            pixel[0]=value;pixel[1]=value/2+31;pixel[2]=255-value;pixel[3]=255;
        }
    upscale(r,&source,&easu,-1.0f);
    upscale(r,&source,&rcas,0.75f);
    unsigned different=0,compared=0;
    for(UINT y=2;y+2<easu.height;++y)
        for(UINT x=2;x+2<easu.width;++x){
            size_t i=((size_t)y*easu.width+x)*4;
            different += abs(easu.rgba[i]-rcas.rgba[i])>=2;
            double sx=((x+0.5)*source.width/easu.width)-0.5;
            double sy=((y+0.5)*source.height/easu.height)-0.5;
            UINT ix=(UINT)sx,iy=(UINT)sy;
            double a=sx-ix,b=sy-iy;
            const unsigned char *p=source.rgba+((size_t)iy*source.width+ix)*4;
            double bilinear=(1-b)*((1-a)*p[0]+a*p[4])+b*((1-a)*p[4*source.width]+a*p[4*source.width+4]);
            compared += abs((int)(bilinear+0.5)-easu.rgba[i])>=3;
        }
    if(!different||!compared)goto done;
    printf("PASS EASU differs from bilinear at %u pixels; RCAS modifies %u pixels\n",compared,different);
    pass=1;
done:
    free(source.rgba);free(easu.rgba);free(rcas.rgba);
    return pass;
}

static UINT dimension(const wchar_t *text)
{
    wchar_t *end = NULL;
    unsigned long result=wcstoul(text,&end,10);
    return end!=text&&!*end&&result>=1&&result<=8192?(UINT)result:0;
}

int wmain(int argc, wchar_t **argv)
{
    int test=argc==3&&wcscmp(argv[2],L"--self-test")==0;
    if(!test && (argc!=6 && argc!=7)){
        fprintf(stderr,"Usage: FSR1_D3D11 <shader.hlsl> <input.bmp> <output.bmp> <width> <height> [--no-rcas]\n"
                       "       FSR1_D3D11 <shader.hlsl> --self-test\n");
        return 2;
    }
    if(argc==7&&wcscmp(argv[6],L"--no-rcas")!=0)return 2;
    Image source={0},output={0};
    if(!test){
        UINT width=dimension(argv[4]),height=dimension(argv[5]);
        if(!bmp_read(argv[2],&source)||source.width<4||source.height<4||
           width<source.width||height<source.height||(width==source.width&&height==source.height)||
           width>source.width*4||height>source.height*4||
           !image_allocate(&output,width,height)){
            fputs("Use an uncompressed 24-bit BMP and an output size above input, at most 4x per axis\n",stderr);
            free(source.rgba); return 1;
        }
    }
    Renderer renderer={0};
    renderer_init(&renderer,argv[1],test);
    int success;
    if(test){
        success=self_test(&renderer);
    }else{
        upscale(&renderer,&source,&output,argc==7?-1.0f:0.75f);
        success=bmp_write(argv[3],&output);
        if(success)printf("AMD FSR 1.0 EASU%s on D3D11: %ux%u -> %ux%u\n",
                          argc==7?"":" + RCAS",source.width,source.height,output.width,output.height);
    }
    renderer_destroy(&renderer);
    free(source.rgba);free(output.rgba);
    return success?0:1;
}
