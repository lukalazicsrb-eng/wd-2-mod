@echo off
setlocal
cd /d "%~dp0"
if not exist build mkdir build
cl /nologo /std:c11 /W4 /O2 /Fo:build\fsr1_d3d11.obj /Fe:build\FSR1_D3D11.exe TOOLS\fsr1_d3d11.c d3d11.lib
if errorlevel 1 exit /b 1
build\FSR1_D3D11.exe SOURCE\fsr1\FSR1_D3D11.hlsl --self-test
exit /b %ERRORLEVEL%
