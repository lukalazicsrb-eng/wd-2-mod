@echo off
setlocal
rem Developer-only. Run in an x64 Developer Command Prompt with the Windows SDK.
cd /d "%~dp0"
if not exist build mkdir build
cl /nologo /W4 /O2 /Fo:build\validate_d3d11.obj /Fe:build\validate_d3d11.exe TOOLS\validate_d3d11.c d3d11.lib
if errorlevel 1 exit /b 1
build\validate_d3d11.exe SOURCE\src --render
if errorlevel 1 exit /b 1
cl /nologo /W4 /O2 /Fo:build\validate_proxy.obj /Fe:build\validate_proxy.exe TOOLS\validate_proxy.c
if errorlevel 1 exit /b 1
if not exist build\proxy-check mkdir build\proxy-check
copy /Y INSTALL\dinput8.dll build\proxy-check\dinput8.dll >NUL
if errorlevel 1 exit /b 1
>build\proxy-check\WD2Enhanced.ini echo [Diagnostics]
>>build\proxy-check\WD2Enhanced.ini echo HookEnabled=0
if exist build\proxy-check\WD2Enhanced_0_40.log del build\proxy-check\WD2Enhanced_0_40.log
build\validate_proxy.exe "%CD%\build\proxy-check\dinput8.dll"
if errorlevel 1 exit /b 1
findstr /C:"HOOK DISABLED BY CONFIG" build\proxy-check\WD2Enhanced_0_40.log
if errorlevel 1 exit /b 1
