# AMD FidelityFX Super Resolution 1.0

`ffx_a.h` and `ffx_fsr1.h` are unmodified from the AMD GPUOpen FidelityFX-FSR repository at commit `a21ffb8f6c13233ba336352bdff293894c706575`. [Pinned source](https://github.com/GPUOpen-Effects/FidelityFX-FSR/tree/a21ffb8f6c13233ba336352bdff293894c706575/ffx-fsr)

The upstream AMD MIT license is in `LICENSE-AMD-FSR1.txt`. `FSR1_D3D11.hlsl` adapts the full-precision EASU and RCAS functions to Shader Model 5 fullscreen pixel passes. EASU consumes a smaller tone-mapped SDR RGB image in a non-sRGB view. Optional RCAS consumes the output-resolution EASU image. The standalone test path has its own device and has no connection to the Watch Dogs 2 renderer.
