// FSR 1.0 pixel shader adapter for Direct3D 11. The filter math and
// constant generation come from the unmodified AMD FidelityFX headers.
// This standalone path accepts tone-mapped SDR RGB in a non-sRGB SRV.

#define A_GPU 1
#define A_HLSL 1
#include "ffx_a.h"
#define FSR_EASU_F 1
#define FSR_RCAS_F 1
#include "ffx_fsr1.h"

Texture2D<float4> InputColor : register(t0);
SamplerState InputClamp : register(s0);

cbuffer UpscaleConstants : register(b0)
{
    // Active image size and resource size in pixels, at mip zero.
    float4 InputSize;
    // Output width, output height, RCAS sharpness stops, reserved.
    float4 OutputSize;
};

float4 VSMain(uint vertex : SV_VertexID) : SV_Position
{
    float2 uv = float2((vertex << 1u) & 2u, vertex & 2u);
    return float4(uv * float2(2.0, -2.0) + float2(-1.0, 1.0), 0.0, 1.0);
}

// Gather's components are bottom-left, bottom-right, top-right, top-left.
// A resource larger than the active viewport needs explicit clamping to
// the active image; the hardware clamp still handles the common full view.
float4 GatherViewport(float2 uv, uint channel)
{
    int2 topLeft = int2(floor(uv * InputSize.zw - 0.5));
    int2 limit = int2(InputSize.xy) - 1;
    int2 tl = clamp(topLeft, int2(0, 0), limit);
    int2 tr = clamp(topLeft + int2(1, 0), int2(0, 0), limit);
    int2 bl = clamp(topLeft + int2(0, 1), int2(0, 0), limit);
    int2 br = clamp(topLeft + int2(1, 1), int2(0, 0), limit);
    return float4(InputColor.Load(int3(bl, 0))[channel],
                  InputColor.Load(int3(br, 0))[channel],
                  InputColor.Load(int3(tr, 0))[channel],
                  InputColor.Load(int3(tl, 0))[channel]);
}

AF4 FsrEasuRF(AF2 uv)
{
    [branch] if (all(InputSize.xy == InputSize.zw)) {
        return InputColor.GatherRed(InputClamp, uv);
    } else {
        return GatherViewport(uv, 0);
    }
}

AF4 FsrEasuGF(AF2 uv)
{
    [branch] if (all(InputSize.xy == InputSize.zw)) {
        return InputColor.GatherGreen(InputClamp, uv);
    } else {
        return GatherViewport(uv, 1);
    }
}

AF4 FsrEasuBF(AF2 uv)
{
    [branch] if (all(InputSize.xy == InputSize.zw)) {
        return InputColor.GatherBlue(InputClamp, uv);
    } else {
        return GatherViewport(uv, 2);
    }
}

AF4 FsrRcasLoadF(ASU2 pixel)
{
    int2 limit = int2(OutputSize.xy) - 1;
    return InputColor.Load(int3(clamp(pixel, int2(0, 0), limit), 0));
}

void FsrRcasInputF(inout AF1 r, inout AF1 g, inout AF1 b)
{
    // The input contract already uses the SDR domain expected by RCAS.
}

float4 PSEasu(float4 position : SV_Position) : SV_Target
{
    uint4 con0, con1, con2, con3;
    FsrEasuCon(con0, con1, con2, con3, InputSize.x, InputSize.y,
               InputSize.z, InputSize.w, OutputSize.x, OutputSize.y);
    float3 rgb;
    FsrEasuF(rgb, uint2(position.xy), con0, con1, con2, con3);
    return float4(saturate(rgb), 1.0);
}

float4 PSRcas(float4 position : SV_Position) : SV_Target
{
    uint4 con;
    FsrRcasCon(con, OutputSize.z);
    float3 rgb;
    FsrRcasF(rgb.r, rgb.g, rgb.b, uint2(position.xy), con);
    return float4(saturate(rgb), 1.0);
}
