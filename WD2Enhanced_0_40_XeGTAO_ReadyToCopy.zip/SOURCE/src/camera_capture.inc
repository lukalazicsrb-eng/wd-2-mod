/* Observe shader constants only on depth-qualified immediate-context draws.
   Staging copies preserve the bytes at those draws even if the game later
   updates or renames the buffer. Do not flush, stall, or change game state. */
#include "projection_math.h"

#define CAMERA_VS_SLOTS 14
#define CAMERA_MAX_BATCH 6
#define CAMERA_COPY_BUDGET 32
#define CAMERA_COPY_SLOTS 64
#define CAMERA_EPOCH_SLOTS 24
#define CAMERA_MAX_AGE 3
#define CAMERA_STILL_DRAWING 0x887a000au

typedef enum {
 CAMERA_NO_EVIDENCE,
 CAMERA_READBACK_PENDING,
 CAMERA_INSUFFICIENT_SAMPLES,
 CAMERA_AMBIGUOUS_PROJECTION,
 CAMERA_WAITING_FOR_AGREEMENT,
 CAMERA_PROJECTION_AVAILABLE
} CameraStatus_;

typedef struct {
 Projection_ projection;
 U32 confirmed, ambiguous;
} CameraSample_;

typedef struct {
 P depthKey; /* The capture records hold the reference. */
 U64 frame, epoch;
 U32 width, height;
 float clearDepth;
 U32 samples, pending, readFailed, viewportDraws;
 CameraSample_ legacy, viewport;
} CameraEvidence_;

typedef struct {
 P staging;
 U32 bytes, offset, length;
 U32 evidenceIndex, batchBit, scanMode;
} CameraCopy_;

enum { CAMERA_SCAN_LEGACY, CAMERA_SCAN_VS_B0, CAMERA_SCAN_VIEWPORT_ONLY };
typedef struct { P data; U32 rowPitch, depthPitch; } CameraMapped_;
typedef void (CALL *CameraGetConstants_)(P,U32,U32,P*,U32*,U32*);

static const GUID_ IID_CAMERA_CONTEXT1 =
 {0xbb2c6faa,0xb5fb,0x4082,{0x8e,0x6b,0x38,0x8b,0x8c,0xfa,0x90,0xe1}};
static CameraEvidence_ g_cameraEvidence[CAMERA_EPOCH_SLOTS];
static CameraCopy_ g_cameraCopies[CAMERA_COPY_SLOTS];
static U64 g_cameraDrawFrame = (U64)-1;
static U32 g_cameraCopyCount;
static CameraStatus_ g_cameraStatus;
static U32 g_cameraViewportUsed;

static void camera_reset(void)
{
 for (U32 i = 0; i < CAMERA_COPY_SLOTS; ++i)
  REL(g_cameraCopies[i].staging);
 memset(g_cameraEvidence,0,sizeof(g_cameraEvidence));
 memset(g_cameraCopies,0,sizeof(g_cameraCopies));
 g_cameraDrawFrame = (U64)-1;
 g_cameraCopyCount = 0;
 g_cameraStatus = CAMERA_NO_EVIDENCE;
 g_cameraViewportUsed = 0;
}

static void camera_record_sample(CameraSample_ *target, const CameraEvidence_ *evidence,
                                  const Projection_ *projection, U32 batchBit)
{
 if (target->confirmed &&
     !projection_matches(projection,&target->projection,
                         evidence->width,evidence->height,1)) {
  target->ambiguous = 1;
  return;
 }
 if (!target->confirmed) target->projection = *projection;
 target->confirmed |= batchBit;
}

static void camera_scan_constants(CameraEvidence_ *evidence, const float *data,
                                  U32 count, U32 batchBit, U32 scanMode)
{
 Projection_ projection;
 if (scanMode != CAMERA_SCAN_LEGACY &&
     projection_decode_wd2_viewport(data,count,evidence->width,evidence->height,
                                    evidence->clearDepth,&projection)) {
  camera_record_sample(&evidence->viewport,evidence,&projection,batchBit);
  return;
 }
 if (scanMode == CAMERA_SCAN_VIEWPORT_ONLY) return;
 for (U32 offset = 0; offset + 16 <= count && !evidence->legacy.ambiguous; offset += 4) {
  for (int transposed = 0; transposed <= 1; ++transposed) {
   if (projection_decode(data+offset,transposed,evidence->width,evidence->height,
                         evidence->clearDepth,&projection))
    camera_record_sample(&evidence->legacy,evidence,&projection,batchBit);
  }
 }
}

static void camera_poll(P ctx, U64 frame)
{
 for (U32 i = 0; i < CAMERA_COPY_SLOTS; ++i) {
  CameraCopy_* copy = &g_cameraCopies[i];
  if (!copy->batchBit) continue;

  CameraEvidence_* evidence = &g_cameraEvidence[copy->evidenceIndex];
  if (evidence->frame <= frame && frame - evidence->frame > CAMERA_MAX_AGE) {
   /* The driver owns queued references. Avoid reusing an unfinished copy. */
   REL(copy->staging);
   copy->batchBit = 0;
   --evidence->pending;
   continue;
  }

  CameraMapped_ mapped = {0};
  /* D3D11_MAP_READ + D3D11_MAP_FLAG_DO_NOT_WAIT. */
  HRESULT_ hr = V(ctx,14,HRESULT_(CALL*)(P,P,U32,U32,U32,CameraMapped_*))
   (ctx,copy->staging,0,1,0x100000u,&mapped);
  if ((U32)hr == CAMERA_STILL_DRAWING) continue;

  if (SUCCEEDED_(hr)) {
   if (mapped.data) {
    const float* constants = (const float*)((const U8*)mapped.data + copy->offset);
    camera_scan_constants(evidence,constants,copy->length / sizeof(float),
                          copy->batchBit,copy->scanMode);
   } else {
    evidence->readFailed = 1;
   }
   V(ctx,15,void(CALL*)(P,P,U32))(ctx,copy->staging,0);
  } else {
   evidence->readFailed = 1;
   REL(copy->staging);
  }
  copy->batchBit = 0;
  --evidence->pending;
 }

 for (U32 i = 0; i < CAMERA_EPOCH_SLOTS; ++i) {
  CameraEvidence_* evidence = &g_cameraEvidence[i];
  if (evidence->depthKey && evidence->frame <= frame &&
      frame - evidence->frame > CAMERA_MAX_AGE)
   memset(evidence,0,sizeof(*evidence));
 }
}

static int camera_get_constants(P ctx, U32 pixel, U32 slots,
                                P* buffers, U32* first, U32* counts)
{
 P ctx1 = 0;
 if (SUCCEEDED_(V(ctx,0,HRESULT_(CALL*)(P,const GUID_*,P*))
                (ctx,&IID_CAMERA_CONTEXT1,&ctx1)) && ctx1) {
  /* A versioned interface can alias the privately hooked base pointer.
     The original table is guaranteed to expose slot 125 for that alias. */
  P* table = ctx1 == g_depthPatchedContext ? g_sharedContextVtable : *(P**)ctx1;
  U32 get = pixel ? 129 : 125; /* PS/VSGetConstantBuffers1 */
  if (table && table[get])
   ((CameraGetConstants_)table[get])(ctx1,0,slots,buffers,first,counts);
  else {
   REL(ctx1);
   return 0;
  }
  REL(ctx1);
 } else {
  U32 get = pixel ? 77 : 72; /* PS/VSGetConstantBuffers */
  V(ctx,get,void(CALL*)(P,U32,U32,P*))(ctx,0,slots,buffers);
  for (U32 i = 0; i < slots; ++i) counts[i] = 4096;
 }
 return 1;
}

static CameraCopy_* camera_find_copy_slot(U32 size)
{
 CameraCopy_* empty = 0;
 CameraCopy_* replace = 0;
 for (U32 i = 0; i < CAMERA_COPY_SLOTS; ++i) {
  CameraCopy_* copy = &g_cameraCopies[i];
  if (copy->batchBit) continue;
  if (copy->staging && copy->bytes == size) return copy;
  if (!copy->staging && !empty) empty = copy;
  if (!replace) replace = copy;
 }
 return empty ? empty : replace;
}

static U32 camera_bound_size(P buffer,U32 first,U32 count,U32 minimum)
{
 if (!buffer || first >= 4096 || count < minimum || count > 4096)return 0;
 BUFFER_DESC desc;
 V(buffer,10,void(CALL*)(P,BUFFER_DESC*))(buffer,&desc);
 return first * 16 + minimum * 16 <= desc.ByteWidth ? desc.ByteWidth : 0;
}

static void camera_submit_copy(P ctx,U32 evidenceIndex,U32 batchBit,U32 scanMode,
                               P buffer,U32 first,U32 count,U32 bytes)
{
 if (g_cameraCopyCount >= CAMERA_COPY_BUDGET)return;
 CameraCopy_ *copy = camera_find_copy_slot(bytes);
 if (!copy)return;
 CameraEvidence_ *evidence = &g_cameraEvidence[evidenceIndex];
 if (copy->bytes != bytes) REL(copy->staging);
 if (!copy->staging) {
  const BUFFER_DESC desc = {bytes,3,0,0x20000u,0,0};
  if (!SUCCEEDED_(dev_buf(g_device,&desc,&copy->staging))) {
   evidence->readFailed = 1;
   return;
  }
  copy->bytes = bytes;
 }
 copy->evidenceIndex = evidenceIndex;
 copy->batchBit = batchBit;
 copy->scanMode = scanMode;
 copy->offset = first * 16;
 copy->length = count * 16;
 if (copy->length > bytes - copy->offset)
  copy->length = bytes - copy->offset;
 /* Bypass the internal color-lineage observer for our own buffer copy. */
 P* table = ctx == g_depthPatchedContext ? g_sharedContextVtable : *(P**)ctx;
 ((void(CALL*)(P,P,P))table[47])(ctx,copy->staging,buffer);
 ++evidence->pending;
 ++g_cameraCopyCount;
}

static void camera_schedule_copies(P ctx,U32 evidenceIndex,U32 batchBit,U32 viewportOnly)
{
 P vs[CAMERA_VS_SLOTS] = {0};
 U32 first[CAMERA_VS_SLOTS] = {0}, counts[CAMERA_VS_SLOTS] = {0};
 U32 vsSlots = viewportOnly ? 1 : CAMERA_VS_SLOTS;
 if (!camera_get_constants(ctx,0,vsSlots,vs,first,counts))return;

 U32 chosen[CAMERA_MAX_BATCH], sizes[CAMERA_MAX_BATCH], number = 0;
 if (!viewportOnly) {
  for (U32 i = 0; i < vsSlots; ++i) {
   U32 bytes = camera_bound_size(vs[i],first[i],counts[i],4);
   if (!bytes)continue;
   if (bytes > 65536 || number == CAMERA_MAX_BATCH) {
    /* An incomplete generic binding set could hide a second projection. */
    number = 0;
    break;
   }
   chosen[number] = i;
   sizes[number++] = bytes;
  }
 }
 U32 freeSlots = 0;
 for (U32 j = 0; j < CAMERA_COPY_SLOTS; ++j)
  if (!g_cameraCopies[j].batchBit)++freeSlots;
 if (g_cameraCopyCount + number > CAMERA_COPY_BUDGET || number > freeSlots)number = 0;

 U32 vsB0Bytes = camera_bound_size(vs[0],first[0],counts[0],WD2_VIEWPORT_CONSTANTS);
 if (vsB0Bytes > 65536)vsB0Bytes = 0;
 if (!number && vsB0Bytes)
  camera_submit_copy(ctx,evidenceIndex,batchBit,CAMERA_SCAN_VIEWPORT_ONLY,
                     vs[0],first[0],counts[0],vsB0Bytes);
 for (U32 k = 0; k < number; ++k) {
  U32 i = chosen[k];
  camera_submit_copy(ctx,evidenceIndex,batchBit,
                     i == 0 && vsB0Bytes ? CAMERA_SCAN_VS_B0 : CAMERA_SCAN_LEGACY,
                     vs[i],first[i],counts[i],sizes[k]);
 }

 P psB0 = 0;
 U32 psFirst = 0, psCount = 0;
 /* A geometry pass already has direct vertex-camera evidence. Do not
    promote unrelated PS state left bound by a previous pass. */
 if (viewportOnly && camera_get_constants(ctx,1,1,&psB0,&psFirst,&psCount)) {
  U32 psBytes = camera_bound_size(psB0,psFirst,psCount,WD2_VIEWPORT_CONSTANTS);
  if (psBytes && psBytes <= 65536 && (!vsB0Bytes || psB0 != vs[0] || psFirst != first[0] || psCount != counts[0]))
   camera_submit_copy(ctx,evidenceIndex,batchBit,CAMERA_SCAN_VIEWPORT_ONLY,
                      psB0,psFirst,psCount,psBytes);
 }
 REL(psB0);
 for (U32 i = 0; i < vsSlots; ++i) REL(vs[i]);
}

static void camera_observe(P ctx,P depthKey,U64 frame,U64 epoch,
                           U32 width,U32 height,float clearDepth,
                           U32 writeDrawCount,U32 viewportOnly)
{
 if (!depthKey || !epoch || !width || !height)return;
 if (!viewportOnly && writeDrawCount != 1 && writeDrawCount != 3 && writeDrawCount != 7)return;
 if (g_cameraDrawFrame != frame) {
  g_cameraDrawFrame = frame;
  g_cameraCopyCount = 0;
  camera_poll(ctx,frame);
 }

 U32 index = CAMERA_EPOCH_SLOTS, freeIndex = CAMERA_EPOCH_SLOTS;
 for (U32 i = 0; i < CAMERA_EPOCH_SLOTS; ++i) {
  const CameraEvidence_* evidence = &g_cameraEvidence[i];
  if (evidence->depthKey == depthKey && evidence->frame == frame &&
      evidence->epoch == epoch) {
   index = i;
   break;
  }
  if (!evidence->depthKey && freeIndex == CAMERA_EPOCH_SLOTS) freeIndex = i;
 }

 if (index == CAMERA_EPOCH_SLOTS) {
  if (freeIndex == CAMERA_EPOCH_SLOTS) return;
  index = freeIndex;
  CameraEvidence_* evidence = &g_cameraEvidence[index];
  evidence->depthKey = depthKey;
  evidence->frame = frame;
  evidence->epoch = epoch;
  evidence->width = width;
  evidence->height = height;
  evidence->clearDepth = clearDepth;
 }

 CameraEvidence_* evidence = &g_cameraEvidence[index];
 U32 draw = viewportOnly ? ++evidence->viewportDraws : writeDrawCount;
 U32 bit = draw == 1 ? 1u : draw == 3 ? 2u : draw == 7 ? 4u : 0u;
 if (viewportOnly)bit <<= 3;
 if (!bit || (evidence->samples & bit))return;
 evidence->samples |= bit;
 camera_schedule_copies(ctx,index,bit,viewportOnly);
}

static void camera_observe_draw(P ctx,P depthKey,U64 frame,U64 epoch,
                                U32 width,U32 height,float clearDepth,U32 writeDrawCount)
{
 camera_observe(ctx,depthKey,frame,epoch,width,height,clearDepth,writeDrawCount,0);
}

static void camera_observe_wd2_draw(P ctx,P depthKey,U64 frame,U64 epoch,
                                   U32 width,U32 height,float clearDepth)
{
 camera_observe(ctx,depthKey,frame,epoch,width,height,clearDepth,0,1);
}

static int camera_has_agreement(const CameraSample_ *sample,U32 viewport)
{
 /* A cbViewport candidate has coherent viewport, lens and inverse data
    before this point. One draw per frame is enough for this path, and the
    caller still requires agreement across consecutive frames. The generic
    matrix scan continues to need two independent draws within each frame. */
 return !sample->ambiguous && sample->confirmed &&
        (viewport || (sample->confirmed & (sample->confirmed - 1u)) != 0);
}

static int camera_resolve_projection(P ctx, P depthKey, U64 frame, U64 epoch,
                                     Projection_* out)
{
 camera_poll(ctx,g_frame);
 g_cameraViewportUsed=0;
 g_cameraStatus = CAMERA_NO_EVIDENCE;
 const CameraEvidence_* current = 0;
 for (U32 i = 0; i < CAMERA_EPOCH_SLOTS; ++i) {
  const CameraEvidence_* evidence = &g_cameraEvidence[i];
  if (evidence->depthKey == depthKey && evidence->frame == frame &&
      evidence->epoch == epoch) {
   current = evidence;
   break;
  }
 }
 if (!current || !depthKey) return 0;
 U32 viewport = current->viewport.confirmed != 0;
 const CameraSample_ *sample = viewport ? &current->viewport : &current->legacy;
 if (current->readFailed || sample->ambiguous ||
     (viewport && !current->legacy.ambiguous && current->legacy.confirmed &&
      !projection_matches(&sample->projection,&current->legacy.projection,
                          current->width,current->height,1))) {
  g_cameraStatus = CAMERA_AMBIGUOUS_PROJECTION;
  return 0;
 }
 if (current->pending) {
  g_cameraStatus = CAMERA_READBACK_PENDING;
  return 0;
 }
 if (!camera_has_agreement(sample,viewport)) {
  g_cameraStatus = CAMERA_INSUFFICIENT_SAMPLES;
  return 0;
 }

 /* Require corroboration for stable lens/depth parameters on the
    previous frame. Current-frame jitter is never taken from history. */
 U32 corroborated = 0;
 for (U32 i = 0; i < CAMERA_EPOCH_SLOTS; ++i) {
  const CameraEvidence_* previous = &g_cameraEvidence[i];
  if (previous->depthKey != depthKey || previous->frame + 1 != frame ||
      previous->width != current->width || previous->height != current->height ||
      previous->pending || previous->readFailed) continue;
  const CameraSample_ *prior = viewport ? &previous->viewport : &previous->legacy;
  if (!camera_has_agreement(prior,viewport)) continue;
  if (!projection_matches(&sample->projection,&prior->projection,
                          current->width,current->height,0)) {
   g_cameraStatus = CAMERA_WAITING_FOR_AGREEMENT;
   return 0;
  }
  corroborated = 1;
 }
 if (!corroborated) {
  g_cameraStatus = CAMERA_WAITING_FOR_AGREEMENT;
  return 0;
 }
 *out = sample->projection;
 g_cameraViewportUsed=viewport;
 g_cameraStatus = CAMERA_PROJECTION_AVAILABLE;
 return 1;
}

static int camera_get_projection(P ctx, P depthKey, U64 frame, U64 epoch,
                                 Projection_* out)
{
 if (__sync_lock_test_and_set(&g_depthGuard,1)) {
  g_cameraViewportUsed=0;
  g_cameraStatus = CAMERA_NO_EVIDENCE;
  return 0;
 }
 int ready = camera_resolve_projection(ctx,depthKey,frame,epoch,out);
 __sync_lock_release(&g_depthGuard);
 return ready;
}
