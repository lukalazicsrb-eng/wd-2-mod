# AMD FSR 1.0 na DirectX 11

`LAB/FSR1_D3D11.exe` pokreće originalne AMD EASU i opcioni RCAS na DX11 kroz HLSL Shader Model 5. Program prima nekompresovanu 24-bitnu SDR BMP sliku i pravi BMP u izabranoj izlaznoj rezoluciji. Radi iz direktorijuma u koji je raspakovan ceo ZIP i koristi sistemski D3DCompiler 47.

```cmd
LAB\FSR1_D3D11.exe SOURCE\fsr1\FSR1_D3D11.hlsl input.bmp output.bmp 2560 1440
```

Ulaz mora biti manji od izlaza uz povećanje do 4× po osi. Dodatak `--no-rcas` koristi samo EASU. Podrazumevani RCAS prolazi jednom. Alat ne koristi motion vektore, prethodne kadrove, jitter ili podatke iz igre. Odvojen je od `INSTALL` i ne treba ga kopirati u direktorijum igre.

```cmd
LAB\FSR1_D3D11.exe SOURCE\fsr1\FSR1_D3D11.hlsl --self-test
```

Provera kompajlira tri SM5 ulazne tačke, izvršava oba AMD prolaza i čita izlaz sa uređaja. Proverava ujednačenu boju i neparne dimenzije, zatim meri da se EASU razlikuje od bilinearnog skaliranja i da RCAS ima zaseban efekat. Izvor i MIT obaveštenje nalaze se u `SOURCE/fsr1`.
