# Izveštaj o proveri 0.39

Polazni izvor je objavljeni 0.38. U logu korisnika iz Watch Dogs 2, 0.38 nalazi kompatibilni D32S8 snimak pri 2560 × 1440, izvršava glavni prolaz, denoise i kompoziciju i prelazi u stanje `AO ACTIVE - ESTIMATED CAMERA`. Taj log pripada prethodnom izdanju.

| Provera | Rezultat |
| --- | --- |
| Windows x64 DLL | PE32+ Clang/LLD. Šest DirectInput izvoza, stvarno prosleđivanje i čitanje `HookEnabled=0` provereni pod Wine-om. |
| Projekcija | 2.899 C provera. D3D11 i D3D11.1 provere prenosa VS/PS konstanti, pomeraja opsega i jittera tekućeg kadra prošle. |
| Aktivacija izvršnog DLL-a | Sintetički swapchain prijavljuje `AO ACTIVE` sa PS b0 viewport kamerom i sa generičkom VS projekcijom, pre i posle ResizeBuffers. Regresija odbacivanja dubine sa procenjenom kamerom takođe prolazi. |
| Dubina i AO | 62 C i 16 referentnih CPU provera. Svih osam postojeći SM5 XeGTAO shadera se kompajlira Microsoft D3DCompiler-om. 26 sintetičkih DX11 provera pri 2560 × 1440, sa sve tri ocene kvaliteta i AO uključeno/isključeno. |
| Samostalni AMD FSR 1.0 alat | Tri SM5 ulazne tačke kompajlirane Microsoft D3DCompiler-om. DX11 provera čuva ravnomernu boju, prolazi sa neparnim dimenzijama, razlikuje EASU od bilinearnog izlaza i razlikuje opcioni RCAS od samog EASU. Obrada BMP 1280 × 720 u 2560 × 1440 izvršena i proverena čitanjem izlaznog BMP-a. |

GPU testovi su izvršeni kroz softverski D3D11 uređaj pod Wine-om. Shaderi za AO su identični onima iz objavljenog 0.38. Prilozi uz zahtev sadržali su log i tekst zahteva. Luma paket je istražen preko javnog izvora i zvaničnog izdanja, bez ugrađivanja njegovih binarnih fajlova.

Watch Dogs 2 na Windowsu i Radeon RX 6700 XT nisu pokrenuti. Tačna kompatibilnost `cbViewport` u igri, pre-TAA boja, motion vektori, vremenska istorija, Pixel Density integracija, izgled vozila i performanse ostaju otvoreni. FSR 1.0 test radi nad slikom i ne menja renderovanje igre.
