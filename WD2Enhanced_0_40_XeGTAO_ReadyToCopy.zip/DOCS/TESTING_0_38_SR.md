# Izveštaj o testiranju 0.38

Polazni izvor je javno objavljen 0.37.1 paket sa šest DirectInput izvoza. Dostavljeni 0.37.1 log i priloženi snimak korišćeni su za dijagnozu. Prilozi u razgovoru sadržali su log, zahtev i sliku. Binarni fajl i INI prethodnog izdanja uzeti su iz proverenog 0.37.1 paketa.

- Windows x64 PE32+ DLL je izgrađen pomoću Clang/LLD. Izvoz i prosleđivanje u sistemski DirectInput provereni su pod Wine-om.
- Microsoft D3DCompiler 47 kompajlirao je svih osam Shader Model 5 ulaznih tačaka. Jedan shader izvršava sva tri nivoa prema konstantama, uz isti format bafera.
- Pri 2560 × 1440 prošlo je 26 sintetičkih provera D3D11 renderovanja na softverskom uređaju pod Wine-om. Pokriveni su ravna i nagnuta površina, kontakt poda i zida, z-razdvojena silueta, očišćena dubina, standardni i obrnuti Z, AO OFF/ON i snimci D32S8 za 1× i 4× MSAA.
- Prošle su 62 C provere izbora dubine, 2.847 provera projekcije i 16 referentnih CPU testova AO-a.
- Sintetički režim `validate_hook_d3d11 --wd2-mutation` upisuje dubinu posle `DiscardView`, a zatim odbacuje izvor pre odvezivanja DSV-a. Uz mali pomak vrednosti brisanja, 0.37.1 ostaje na čekanju. 0.38 koristi snimak pre odbacivanja i izvršava AO sa procenjenom kamerom pre i posle `ResizeBuffers`. Osnovni test posebno proverava aktivaciju sa očitanom projekcijom.
- Watch Dogs 2 i ciljni Radeon RX 6700 XT nisu bili dostupni. Aktivacija u igri, tačna operacija koja je proizvela zastavicu u logu 0.37.1, izgled kroz staklo i performanse čekaju proveru na ciljnoj konfiguraciji.
