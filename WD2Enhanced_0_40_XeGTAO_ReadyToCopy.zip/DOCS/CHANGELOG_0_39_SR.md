# WD2 Enhanced 0.39

- Poznato dobro izdanje 0.38 sačuvano je u paketu. Dostavljeni log iz Watch Dogs 2 beleži izvršavanje AO prolaza pri 2560 × 1440 i status `AO ACTIVE - ESTIMATED CAMERA`.
- Dodato je očitavanje WD2 rasporeda `cbViewport` iz b0. Kandidat mora da prođe proveru dimenzija i recipročnih vrednosti viewporta, bliske ravni, projekcije i njene inverzne matrice, smera Z i slaganja između uzastopnih kadrova. PS b0 se uzorkuje na kompatibilnom punom upisu, a postojeći VS put ostaje dostupan. Za AO se koristi projekcija tekućeg kadra. F8 i log označavaju prihvaćeni CBVIEWPORT; kada potrebne provere ne uspeju primenjuje se postojeća procena.
- Zadržani su XeGTAO HLSL, kvaliteti Low/Medium/High, AO kompozicija, oštrenje, boje i podešavanja. Prebacivanje kompozicije pre TAA i HUD-a u okviru WD2 Enhanced ostaje otvoreno.
- Dodat je nezavisni izvršni alat koji na DX11 pokreće AMD FSR 1.0 EASU i opcioni RCAS. Ugradnja vremenskog FSR-a u WD2 Enhanced ostaje otvorena.
