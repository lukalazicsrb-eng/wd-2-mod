# WD2 Enhanced 0.38

## Izbor dubine i aktivacija

Dostavljeni log 0.37.1 potvrđuje da su DX11 hook-ovi i probni prikaz radili. Jedini puni 2560 × 1440 D32S8 kandidat bez MSAA imao je upis u tekućem kadru i zastavicu poništenog intervala dubine. Broj kandidata promenio se posle ponovne pretrage, ali je isti tip punorezolucijskog kandidata ostao blokiran. Zajednička zastavica 0.37.1 ne otkriva tačnu API operaciju iz stvarne igre.

0.38 pravi nezavisan snimak pre praćenog kopiranja, brisanja ili odbacivanja izvornog resursa. Poništenje izvora i upotrebljivost već sačuvanog snimka sada se proveravaju odvojeno. Snimak pripada tekućem kadru, a promena veličine i ponovna inicijalizacija brišu reference i kameru. Za kompatibilnu putanju i dalje su potrebni jedinstven punorezolucijski D32S8 kandidat, praćeno brisanje, odgovarajući upis i podržan opseg brisanja. Prvobitna putanja koja prati vezu dubine i završne slike zadržava prioritet. MSAA se i dalje priprema u shaderu po pojedinačnim uzorcima.

Projekcija se i dalje traži u vertex constant buffer-ima i poredi između kadrova. Ako je očitavanje neuspešno uz kompatibilan snimak, ograničena procena koristi vertikalni FOV od 70°, proporciju dubine, raspon 0,1–1000 i standardni ili obrnuti Z prema vrednosti brisanja. Procena podnosi mala odstupanja krajnjih vrednosti do 0,0001. U shaderu se za maskiranje prazne dubine koristi stvarna vrednost brisanja. Meni prikazuje **ACTIVE (EST.)** kada primenjuje AO sa tom procenom.

Dnevnik beleži razlog čekanja, format, dimenzije, kadar, interval pisanja, bitove vrednosti brisanja, granicu pravljenja snimka, neuspešnu alokaciju i slanje glavnog, denoise i završnog prolaza. Probni prikaz koristi isti snimak kada je odabran isti jednousorački kandidat. Inače prikazuje neposredni dijagnostički resurs. Podešavanja odlaganja pri pokretanju zadržana su radi kompatibilnosti. Aktivacija posle uspešnog snimanja se procenjuje po kadru.

## Slika i kvalitet

- Nakon rekonstrukcije pune rezolucije, doprinos AO-a prati stvarnu težinu uzoraka koji se slažu sa dubinom. Uzorak na granici tolerancije ima slabiji doprinos. To ograničava haloe oko silueta uz očuvanje potvrđenog kontakta.
- Low zadržava 3 × 2, Medium 4 × 3, a High 6 × 4 uzoraka. Svaki nivo koristi poboljšan raspored radijalnog šuma i zadržava svoju težinu prostornog filtera. Promena kvaliteta ne menja dimenzije niti ponovo pravi bafer.
- Procena kamere koristi strožu zaštitu ivica i umanjuje domet AO-a faktorom 0,85. Intenzitet ostaje pod kontrolom igrača. Početni Balanced koristi High, intenzitet 38% i uključen HUD Guard.
- Zadržani su priprema dubine, FP32 hijerarhija, XeGTAO integral horizonta, obostrani prostorni filter i SDR sastavljanje. AO se i dalje sastavlja pri Present-u; faza pre stakla ili HUD-a u Watch Dogs 2 ostaje nepotvrđena.
