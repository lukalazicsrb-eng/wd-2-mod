# FSR u WD2 Enhanced

WD2 Enhanced 0.40 koristi DirectX 11 i završni kadar igre u izlaznoj rezoluciji. Grafički mod ne izvršava FSR upscaling u igri. Priloženi alat za BMP slike izvršava AMD FSR 1.0 EASU i opcioni RCAS u zasebnom programu. Upotreba alata opisana je u `FSR1_LAB_SR.md`. [AMD FidelityFX Super Resolution 1](https://gpuopen.com/fidelityfx-superresolution/)

Za FSR 1.0 u igri treba potvrditi prolaz koji prima antialiasovanu SDR boju u nižoj rezoluciji i upisuje u veću ciljnu teksturu pre HUD-a. Dimenzije treba proveriti pri 100% i smanjenom Pixel Density. DX11 log verzije 0.39 potvrđuje završnu boju na 2560 × 1440. Kandidat od 1280 × 720 u tom logu je dubina.

Javni Luma izvor služi kao referenca za raspored prolaza. `SwapchainCopy` uzima boju iz `t0` posle postprocesiranja i pre HUD-a. `0x35B62AAF` je raniji prolaz povezan sa opcijom Temporal Filtering. Izvor ne utvrđuje da li je `t0` na završnoj kopiji pri smanjenom Pixel Density još u nižoj rezoluciji. [Referentni SwapchainCopy shader](https://github.com/Filoppi/Luma-Framework/blob/30c4045a47edc1a175646bd8a0e18b89778f91e5/Shaders/Watch%20Dogs%202/SwapchainCopy_0x57A47ED1_0x5E003A74.ps_5_0.hlsl)
