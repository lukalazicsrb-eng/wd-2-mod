# Provere za WD2 Enhanced 0.40

Windows x64 DLL je izgrađen kroz Clang i LLD. Provereni su PE32+ format, svih šest DirectInput izvoza i podudaranje ugrađenog HLSL-a sa izvornim kodom.

Microsoft D3DCompiler 47 kompajlirao je svih osam SM5 ulaznih tačaka. Ponovo izgrađeni FSR 1.0 alat prošao je samo-test sa neparnim dimenzijama, EASU i RCAS.

Prošlo je 2.899 provera projekcije, 62 provere snimanja dubine i 17 CPU provera renderera. Nova provera prikazuje slabljenje okluzije na izolovanim uzorcima i očuvanje senke sa tri povezana susedna uzorka.

Sintetički D3D11 render pri 2560 × 1440 prošao je svih 28 provera pod Wine-om. U novim proverama izolovani uzorak postao je neutralan, a povezani uzorak zadržao je okluziju. Konačna AO dijagnostika i kompozicija dale su istu vrednost maske. D3D11 i D3D11.1 provere kamere prošle su uz provere DirectInput prosleđivanja i čitanja `HookEnabled=0` iz INI-ja.

Spakovani DLL pokrenut je na sintetičkom swapchain-u. Log je potvrdio aktivan AO i `CBVIEWPORT` projekciju pre i posle `ResizeBuffers`.

Watch Dogs 2 i konkretna scena sa autobusom nisu pokrenuti u ovom okruženju. Upotreba FSR 1.0 u ovom izdanju ograničena je na priloženi alat za BMP slike.
