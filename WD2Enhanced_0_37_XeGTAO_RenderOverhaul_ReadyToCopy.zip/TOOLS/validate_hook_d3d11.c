/* Synthetic swap chain for exercising the real proxy and DX11 hooks.
   Use a copy of INSTALL/dinput8.dll in an isolated directory, and place
   WD2Enhanced.ini there with the values below. Run while the test window
   has focus. The game is not used.

   [Graphics]
   EffectEnabled=1
   [AOPrototype]
   Enabled=1
   [Diagnostics]
   HookEnabled=1
   StartupDelayMs=10000
   PassthroughFrames=30
*/
#define COBJMACROS
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <d3d11.h>
#include <d3dcompiler.h>
#include <stdio.h>
#include <stdlib.h>

#define CHECK(call) do { \
    HRESULT result = (call); \
    if (FAILED(result)) { \
        fprintf(stderr, "%s failed (0x%08lx)\n", #call, (unsigned long)result); \
        exit(1); \
    } \
} while (0)

static const char shader[] =
    "cbuffer Camera:register(b0){row_major float4x4 proj;}"
    "float4 VSMain(uint id:SV_VertexID):SV_Position{"
    "float2 points[6]={float2(-1,-1),float2(-1,1),float2(1,1),"
    "float2(-1,-1),float2(1,1),float2(1,-1)};"
    "float z=4;return mul(float4(points[id]*z/float2(proj[0][0],proj[1][1]),z,1),proj);}"
    "float4 PSMain():SV_Target{return float4(.5,.5,.5,1);}";

typedef struct {
    ID3D11Texture2D *depth, *back;
    ID3D11RenderTargetView *rtv;
    ID3D11DepthStencilView *dsv;
} Targets;

static void create_targets(ID3D11Device *device, IDXGISwapChain *swapchain,
                           UINT width, UINT height, Targets *targets)
{
    const GUID texture_id = {0x6f15aaf2,0xd208,0x4e89,{0x9a,0xb4,0x48,0x95,0x35,0xd3,0x4f,0x9c}};
    CHECK(IDXGISwapChain_GetBuffer(swapchain, 0, &texture_id, (void **)&targets->back));
    CHECK(ID3D11Device_CreateRenderTargetView(device, (ID3D11Resource *)targets->back,
                                              NULL, &targets->rtv));
    D3D11_TEXTURE2D_DESC desc = {0};
    desc.Width = width;
    desc.Height = height;
    desc.MipLevels = desc.ArraySize = 1;
    desc.SampleDesc.Count = 1;
    desc.Format = DXGI_FORMAT_R32G8X24_TYPELESS;
    desc.BindFlags = D3D11_BIND_DEPTH_STENCIL;
    CHECK(ID3D11Device_CreateTexture2D(device, &desc, NULL, &targets->depth));
    D3D11_DEPTH_STENCIL_VIEW_DESC view = {0};
    view.Format = DXGI_FORMAT_D32_FLOAT_S8X24_UINT;
    view.ViewDimension = D3D11_DSV_DIMENSION_TEXTURE2D;
    CHECK(ID3D11Device_CreateDepthStencilView(device, (ID3D11Resource *)targets->depth,
                                              &view, &targets->dsv));
}

static void release_targets(Targets *targets)
{
    ID3D11RenderTargetView_Release(targets->rtv);
    ID3D11DepthStencilView_Release(targets->dsv);
    ID3D11Texture2D_Release(targets->back);
    ID3D11Texture2D_Release(targets->depth);
}

static ID3DBlob *compile_entry(pD3DCompile compile, const char *entry, const char *profile)
{
    ID3DBlob *bytecode = NULL, *messages = NULL;
    HRESULT hr = compile(shader, sizeof(shader) - 1, "synthetic geometry", NULL, NULL,
                         entry, profile, 0, 0, &bytecode, &messages);
    if (messages) {
        fputs((const char *)ID3D10Blob_GetBufferPointer(messages), stderr);
        ID3D10Blob_Release(messages);
    }
    CHECK(hr);
    return bytecode;
}

static int wait_for_draws(ID3D11DeviceContext *context, ID3D11Query *query)
{
    ID3D11DeviceContext_End(context, (ID3D11Asynchronous *)query);
    ID3D11DeviceContext_Flush(context);
    ULONGLONG start = GetTickCount64();
    for (;;) {
        HRESULT hr = ID3D11DeviceContext_GetData(context, (ID3D11Asynchronous *)query, NULL, 0, 0);
        CHECK(hr);
        if (hr != S_FALSE)
            return 1;
        if (GetTickCount64() - start > 5000)
            return 0;
        Sleep(1);
    }
}

int wmain(int argc, wchar_t **argv)
{
    if (argc != 2) {
        fprintf(stderr, "Usage: validate_hook_d3d11 <absolute path to isolated dinput8.dll>\n");
        return 2;
    }
    HWND window = CreateWindowExW(0, L"STATIC", L"WD2 synthetic DX11 smoke",
        WS_OVERLAPPEDWINDOW | WS_VISIBLE, 30, 30, 800, 480, NULL, NULL, NULL, NULL);
    if (!window)
        return 1;
    SetForegroundWindow(window);

    UINT width = 640, height = 360;
    DXGI_SWAP_CHAIN_DESC desc = {0};
    desc.BufferDesc.Width = width;
    desc.BufferDesc.Height = height;
    desc.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    desc.SampleDesc.Count = 1;
    desc.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    desc.BufferCount = 1;
    desc.OutputWindow = window;
    desc.Windowed = TRUE;
    IDXGISwapChain *swapchain = NULL;
    ID3D11Device *device = NULL;
    ID3D11DeviceContext *context = NULL;
    CHECK(D3D11CreateDeviceAndSwapChain(NULL, D3D_DRIVER_TYPE_HARDWARE, NULL, 0, NULL, 0,
                                       D3D11_SDK_VERSION, &desc, &swapchain, &device, NULL, &context));

    HMODULE proxy = LoadLibraryW(argv[1]);
    HMODULE compiler = LoadLibraryW(L"d3dcompiler_47.dll");
    if (!proxy || !compiler)
        return 1;
    typedef HRESULT (WINAPI *StartProxy)(void);
    StartProxy start_proxy = (StartProxy)(void *)GetProcAddress(proxy, "DllCanUnloadNow");
    pD3DCompile compile = (pD3DCompile)(void *)GetProcAddress(compiler, "D3DCompile");
    if (!start_proxy || !compile)
        return 1;
    CHECK(start_proxy());

    ID3D11VertexShader *vs = NULL;
    ID3D11PixelShader *ps = NULL;
    ID3DBlob *blob = compile_entry(compile, "VSMain", "vs_5_0");
    CHECK(ID3D11Device_CreateVertexShader(device, ID3D10Blob_GetBufferPointer(blob),
                                          ID3D10Blob_GetBufferSize(blob), NULL, &vs));
    ID3D10Blob_Release(blob);
    blob = compile_entry(compile, "PSMain", "ps_5_0");
    CHECK(ID3D11Device_CreatePixelShader(device, ID3D10Blob_GetBufferPointer(blob),
                                         ID3D10Blob_GetBufferSize(blob), NULL, &ps));
    ID3D10Blob_Release(blob);

    /* A 70 degree, 16:9, infinite-far, reverse-Z scene projection. */
    float projection[16] = {0};
    projection[0] = 1.428148f * 9 / 16;
    projection[5] = 1.428148f;
    projection[11] = 1.0f;
    projection[14] = 0.1f;
    D3D11_BUFFER_DESC cb_desc = {0};
    cb_desc.ByteWidth = sizeof(projection);
    cb_desc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
    D3D11_SUBRESOURCE_DATA cb_data = {projection, 0, 0};
    ID3D11Buffer *cb = NULL;
    CHECK(ID3D11Device_CreateBuffer(device, &cb_desc, &cb_data, &cb));

    D3D11_DEPTH_STENCIL_DESC depth_desc = {0};
    depth_desc.DepthEnable = TRUE;
    depth_desc.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ALL;
    depth_desc.DepthFunc = D3D11_COMPARISON_GREATER_EQUAL;
    ID3D11DepthStencilState *depth_state = NULL;
    CHECK(ID3D11Device_CreateDepthStencilState(device, &depth_desc, &depth_state));

    D3D11_RASTERIZER_DESC raster_desc = {0};
    raster_desc.FillMode = D3D11_FILL_SOLID;
    raster_desc.CullMode = D3D11_CULL_NONE;
    raster_desc.DepthClipEnable = TRUE;
    ID3D11RasterizerState *raster = NULL;
    CHECK(ID3D11Device_CreateRasterizerState(device, &raster_desc, &raster));
    D3D11_QUERY_DESC query_desc = {D3D11_QUERY_EVENT, 0};
    ID3D11Query *query = NULL;
    CHECK(ID3D11Device_CreateQuery(device, &query_desc, &query));
    Targets targets;
    create_targets(device, swapchain, width, height, &targets);

    Sleep(11000); /* Give the configured 10-second delayed hook time to install. */
    puts("Starting synthetic Present sequence");
    for (unsigned frame = 0; frame < 100; ++frame) {
        MSG message;
        while (PeekMessageW(&message, NULL, 0, 0, PM_REMOVE)) {
            TranslateMessage(&message);
            DispatchMessageW(&message);
        }
        if (frame == 60) {
            ID3D11DeviceContext_OMSetRenderTargets(context, 0, NULL, NULL);
            release_targets(&targets);
            width = 800;
            height = 450;
            CHECK(IDXGISwapChain_ResizeBuffers(swapchain, 0, width, height, DXGI_FORMAT_UNKNOWN, 0));
            create_targets(device, swapchain, width, height, &targets);
        }
        D3D11_VIEWPORT viewport = {0, 0, (float)width, (float)height, 0, 1};
        ID3D11DeviceContext_RSSetViewports(context, 1, &viewport);
        ID3D11DeviceContext_RSSetState(context, raster);
        ID3D11DeviceContext_OMSetDepthStencilState(context, depth_state, 0);
        ID3D11DeviceContext_OMSetRenderTargets(context, 1, &targets.rtv, targets.dsv);
        ID3D11DeviceContext_ClearDepthStencilView(context, targets.dsv, D3D11_CLEAR_DEPTH, 0, 0);
        ID3D11DeviceContext_IASetPrimitiveTopology(context, D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
        ID3D11DeviceContext_VSSetConstantBuffers(context, 0, 1, &cb);
        ID3D11DeviceContext_VSSetShader(context, vs, NULL, 0);
        ID3D11DeviceContext_PSSetShader(context, ps, NULL, 0);
        for (unsigned draw = 0; draw < 8; ++draw)
            ID3D11DeviceContext_DrawInstanced(context, 6, 1, 0, 0);

        ID3D11DeviceContext_OMSetRenderTargets(context, 0, NULL, NULL);
        if (!wait_for_draws(context, query)) {
            fprintf(stderr, "Synthetic draws did not finish\n");
            return 1;
        }
        CHECK(IDXGISwapChain_Present(swapchain, 0, 0));
        Sleep(25); /* Observe the mod's debounced AO state in the log. */
    }
    puts("Synthetic render with resize returned successfully");
    ID3D11DeviceContext_ClearState(context);
    release_targets(&targets);
    ID3D11Query_Release(query);
    ID3D11RasterizerState_Release(raster);
    ID3D11DepthStencilState_Release(depth_state);
    ID3D11Buffer_Release(cb);
    ID3D11VertexShader_Release(vs);
    ID3D11PixelShader_Release(ps);
    IDXGISwapChain_Release(swapchain);
    ID3D11DeviceContext_Release(context);
    ID3D11Device_Release(device);
    FreeLibrary(compiler);
    DestroyWindow(window);
    return 0;
}
