/* Builds with: cc -std=c11 -O2 TOOLS/test_projection.c -lm -o test_projection */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../SOURCE/src/projection_math.h"

#define WIDTH 2560u
#define HEIGHT 1440u

typedef struct { double x, y, z; } Vec3;
typedef struct { double x, y, d; } ScreenPoint;

static unsigned int checks;

static void check(int condition, const char* name)
{
 ++checks;
 if (!condition) {
  fprintf(stderr, "Projection test failed: %s\n", name);
  exit(EXIT_FAILURE);
 }
}

static void close_to(double value, double expected, double limit, const char* name)
{
 if (fabs(value - expected) > limit)
  fprintf(stderr, "%s: %.12g vs %.12g (limit %.3g)\n",name,value,expected,limit);
 check(fabs(value - expected) <= limit, name);
}

static void build_projection(float matrix[16], int transposed, int rightHanded,
                             int reverseZ, double fov, double nearZ, double farZ,
                             double jitterX, double jitterY)
{
 double c = rightHanded ? -1.0 : 1.0;
 double sy = 1.0 / tan(fov * acos(-1.0) / 360.0);
 double sx = sy * HEIGHT / WIDTH;
 double depthA = isinf(farZ) ? 0.0 : -nearZ / (farZ - nearZ);
 double depthB = nearZ * (1.0 - depthA);
 if (!reverseZ) {
  depthA = 1.0 - depthA;
  depthB = -depthB;
 }
 float rows[16] = {
  (float)sx, 0, (float)(c * jitterX), 0,
  0, (float)sy, (float)(c * jitterY), 0,
  0, 0, (float)(c * depthA), (float)depthB,
  0, 0, (float)c, 0
 };
 for (unsigned int row = 0; row < 4; ++row) {
  for (unsigned int col = 0; col < 4; ++col)
   matrix[transposed ? 4 * col + row : 4 * row + col] = rows[4 * row + col];
 }
}

static ScreenPoint project_with_matrix(Vec3 v, const float matrix[16],
                                       int transposed, int rightHanded)
{
 double input[4] = {v.x, v.y, rightHanded ? -v.z : v.z, 1};
 double clip[4] = {0};
 for (unsigned int row = 0; row < 4; ++row) {
  for (unsigned int col = 0; col < 4; ++col)
   clip[row] += input[col] * matrix[transposed ? 4 * col + row : 4 * row + col];
 }
 ScreenPoint output = {
  0.5 + 0.5 * clip[0] / clip[3],
  0.5 - 0.5 * clip[1] / clip[3],
  clip[2] / clip[3]
 };
 return output;
}

/* Same arithmetic and coordinates as the shader's depth/view conversion. */
static Vec3 reconstruct(ScreenPoint p, const Projection_* projection)
{
 float z = projection->depthB / ((float)p.d - projection->depthA);
 float x = (2.0f * (float)p.x - 1.0f - projection->offsetX) * z / projection->scaleX;
 float y = (1.0f - 2.0f * (float)p.y - projection->offsetY) * z / projection->scaleY;
 Vec3 v = {x,y,z};
 return v;
}

static Vec3 subtract(Vec3 a, Vec3 b)
{
 Vec3 d = {a.x-b.x,a.y-b.y,a.z-b.z};
 return d;
}

static Vec3 normal(Vec3 a, Vec3 b, Vec3 c)
{
 Vec3 u = subtract(b,a), v = subtract(c,a);
 Vec3 n = {u.y*v.z-u.z*v.y,u.z*v.x-u.x*v.z,u.x*v.y-u.y*v.x};
 double len = sqrt(n.x*n.x + n.y*n.y + n.z*n.z);
 Vec3 result = {n.x/len,n.y/len,n.z/len};
 return result;
}

static Vec3 translated_and_rotated(Vec3 world, Vec3 position, double angle)
{
 Vec3 v = subtract(world,position);
 Vec3 result = {v.x*cos(angle)-v.z*sin(angle),v.y,v.x*sin(angle)+v.z*cos(angle)};
 return result;
}

static void test_plane(const float matrix[16], const Projection_* p, int transposed,
                       int rightHanded, const Vec3 points[3], Vec3 eye,
                       double yaw, const char* name)
{
 Vec3 before[3], after[3];
 for (unsigned int i = 0; i < 3; ++i) {
  before[i] = translated_and_rotated(points[i],eye,yaw);
  ScreenPoint raster = project_with_matrix(before[i],matrix,transposed,rightHanded);
  check(raster.d > 0.0 && raster.d < 1.0, "synthetic plane lies in depth range");
  after[i] = reconstruct(raster,p);
  close_to(after[i].x,before[i].x,0.006,name);
  close_to(after[i].y,before[i].y,0.006,name);
  close_to(after[i].z,before[i].z,0.006,name);
 }
 Vec3 n0 = normal(before[0],before[1],before[2]);
 Vec3 n1 = normal(after[0],after[1],after[2]);
 close_to(n1.x,n0.x,0.001,name);
 close_to(n1.y,n0.y,0.001,name);
 close_to(n1.z,n0.z,0.001,name);
}

static void test_reconstruction(void)
{
 const Vec3 road[3] = {{-2,-1.7,4},{3,-1.7,4},{2,-1.7,12}};
 const Vec3 slope[3] = {{-2,-1,4},{3,0,4},{2,1,12}};
 const Vec3 wall[3] = {{-1,-1,6},{3,-1,6},{1,2,6}};
 const double fovs[] = {45,70,104};
 const double farPlanes[] = {1000,INFINITY};
 for (int right = 0; right <= 1; ++right) {
  for (int transpose = 0; transpose <= 1; ++transpose) {
   for (int reverse = 0; reverse <= 1; ++reverse) {
    for (unsigned int f = 0; f < 3; ++f) {
     for (unsigned int far = 0; far < 2; ++far) {
      float matrix[16];
      const double nearZ = 0.1;
      double jitterX = (f * 0.4 - 0.3) / WIDTH;
      double jitterY = (0.5 - f * 0.3) / HEIGHT;
      build_projection(matrix,transpose,right,reverse,fovs[f],nearZ,farPlanes[far],
                       jitterX,jitterY);
      Projection_ p;
      check(projection_decode(matrix,transpose,WIDTH,HEIGHT,reverse ? 0.0f : 1.0f,&p),
            "decode finite/infinite direct/transposed projection");
      check((int)p.reverseZ == reverse, "depth convention");
      check(!projection_decode(matrix,!transpose,WIDTH,HEIGHT,reverse ? 0.0f : 1.0f,&p),
            "opposite orientation is rejected");
      close_to(p.offsetX,jitterX,1e-9,"horizontal jitter extraction");
      close_to(p.offsetY,jitterY,1e-9,"vertical jitter extraction");
      close_to(2 * atan(1.0 / p.scaleY) * 180 / acos(-1.0),fovs[f],1e-5,"vertical FOV");
      close_to(p.depthB / ((reverse ? 1.0 : 0.0) - p.depthA),nearZ,2e-8,"near plane");
      double invFar = ((reverse ? 0.0 : 1.0) - p.depthA) / p.depthB;
      close_to(invFar,1.0/farPlanes[far],4e-7,"reciprocal far plane");

      Vec3 eye = {0.2 * f,0.3 * f,0.35 * f};
      double yaw = 0.12 * f;
      test_plane(matrix,&p,transpose,right,road,eye,yaw,"flat road after camera motion");
      test_plane(matrix,&p,transpose,right,slope,eye,yaw,"sloped surface after camera motion");
      test_plane(matrix,&p,transpose,right,wall,eye,yaw,"vertical wall after camera motion");

      ScreenPoint nearObject = project_with_matrix((Vec3){0,0,0.18}, matrix,transpose,right);
      ScreenPoint farObject = project_with_matrix((Vec3){0,0,465}, matrix,transpose,right);
      close_to(nearObject.x,farObject.x,1e-9,"silhouette shared ray x");
      close_to(nearObject.y,farObject.y,1e-9,"silhouette shared ray y");
      close_to(reconstruct(nearObject,&p).z,0.18,1e-6,"foreground depth");
      close_to(reconstruct(farObject,&p).z,465,0.15,"background depth");
      check(reverse ? nearObject.d > farObject.d : nearObject.d < farObject.d,
            "silhouette discontinuity keeps the nearer sample identifiable");
     }
    }
   }
  }
 }
}

static void test_rejections(void)
{
 float m[16], other[16];
 Projection_ p, q;
 build_projection(m,0,0,1,70,0.1,1000,0.25/WIDTH,0);
 check(projection_decode(m,0,WIDTH,HEIGHT,0,&p),"reference projection");
 check(!projection_decode(m,0,WIDTH,HEIGHT,1,&q),"wrong clear convention");
 check(!projection_decode(m,0,WIDTH,HEIGHT,0.25f,&q),"unknown clear convention");
 check(!projection_decode(m,0,1920,1200,0,&q),"wrong viewport aspect");
 check(!projection_decode(m,0,0,HEIGHT,0,&q),"empty viewport");

 memcpy(other,m,sizeof(m));
 other[0] = NAN;
 check(!projection_decode(other,0,WIDTH,HEIGHT,0,&q),"nonfinite projection");
 memcpy(other,m,sizeof(m));
 other[8] = 0.02f;
 check(!projection_decode(other,0,WIDTH,HEIGHT,0,&q),"oblique near clip");
 memcpy(other,m,sizeof(m));
 other[15] = 1.0f;
 check(!projection_decode(other,0,WIDTH,HEIGHT,0,&q),"orthographic/translated matrix");
 memcpy(other,m,sizeof(m));
 other[2] = 14.0f/WIDTH;
 check(!projection_decode(other,0,WIDTH,HEIGHT,0,&q),"unsupported large offset");

 build_projection(other,0,0,1,70,0.1,1000,-0.3/WIDTH,0);
 check(projection_decode(other,0,WIDTH,HEIGHT,0,&q),"second jitter sample");
 check(!projection_matches(&p,&q,WIDTH,HEIGHT,1),"same-frame jitter mismatch rejected");
 check(projection_matches(&p,&q,WIDTH,HEIGHT,0),"successive frame jitter supported");
 build_projection(other,0,0,1,75,0.1,1000,0.25/WIDTH,0);
 check(projection_decode(other,0,WIDTH,HEIGHT,0,&q),"different camera FOV");
 check(!projection_matches(&p,&q,WIDTH,HEIGHT,0),"changed lens waits for corroboration");
}

int main(void)
{
 test_reconstruction();
 test_rejections();
 printf("Projection validation passed (%u checks).\n",checks);
 return EXIT_SUCCESS;
}
